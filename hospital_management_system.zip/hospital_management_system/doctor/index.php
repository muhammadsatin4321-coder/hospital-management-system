<?php
session_start();
include("../includes/conn.php");

// Activating internal error reporting for mysqli
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// 1. Force doctor authentication session
if (!isset($_SESSION['doctor_id'])) {
    header("Location: login.php");
    exit();
}

$doctor_id = $_SESSION['doctor_id'];
$doctor_name = isset($_SESSION['doctor_name']) ? $_SESSION['doctor_name'] : "Specialist";

// --- FETCH AVAILABLE YEARS FOR FILTER ---
$years_query = "SELECT DISTINCT YEAR(appointment_date) as yr FROM appointment WHERE doctor_id = ? ORDER BY yr DESC";
$stmt_yr = $conn->prepare($years_query);
$stmt_yr->bind_param("s", $doctor_id);
$stmt_yr->execute();
$res_yr = $stmt_yr->get_result();
$available_years = [];
while($y_row = $res_yr->fetch_assoc()) {
    if ($y_row['yr']) {
        $available_years[] = intval($y_row['yr']);
    }
}
$stmt_yr->close();

if (empty($available_years)) {
    $available_years[] = intval(date('Y'));
}

// --- FEATURE: Get Selected Month and Year (Separated UI) ---
$filter_year = isset($_GET['filter_year']) ? intval($_GET['filter_year']) : intval(date('Y'));

if (isset($_GET['month_filter'])) {
    if (strpos($_GET['month_filter'], '-') !== false) {
        // Fallback or compatibility handler for old layout string formats
        $parts = explode('-', $_GET['month_filter']);
        $filter_year = intval($parts[0]);
        $selected_month = sprintf("%02d", intval($parts[1]));
    } else {
        $selected_month = sprintf("%02d", intval($_GET['month_filter']));
    }
} else {
    $selected_month = date('m');
}

$selected_year = $filter_year;
$selected_month_year = $selected_year . '-' . $selected_month;

// Define all SQL queries out here so they are always defined
$pending_query   = "SELECT COUNT(*) as total FROM appointment WHERE doctor_id = ? AND status = 'Pending'";
$completed_query = "SELECT COUNT(*) as total FROM appointment WHERE doctor_id = ? AND status = 'Completed'";
$queue_query     = "SELECT COUNT(*) as total FROM appointment WHERE doctor_id = ? AND appointment_date = ?";
$archive_query   = "SELECT COUNT(*) as total FROM medical_records WHERE doctor_id = ?";

// Adjust column selection if name column varies
$list_query      = "SELECT id, user_email, symptom, appointment_date, `timing` FROM appointment WHERE doctor_id = ? AND status = 'Pending' ORDER BY appointment_date ASC, `timing` ASC";

// Filter by selected year and month to show specific month's pending appointments
$calendar_query  = "SELECT id, user_email, patient_name, symptom, gender, age, `timing`, blood_group, appointment_date 
                    FROM appointment 
                    WHERE doctor_id = ? AND status = 'Pending' 
                    AND YEAR(appointment_date) = ? AND MONTH(appointment_date) = ?";

try {
    // --- 2. Analytics Metric Queries ---
    $stmt1 = $conn->prepare($pending_query);
    $stmt1->bind_param("s", $doctor_id);
    $stmt1->execute();
    $pending_count = $stmt1->get_result()->fetch_assoc()['total'];
    $stmt1->close();

    $stmt2 = $conn->prepare($completed_query);
    $stmt2->bind_param("s", $doctor_id);
    $stmt2->execute();
    $completed_count = $stmt2->get_result()->fetch_assoc()['total'];
    $stmt2->close();

    $today_date = date('Y-m-d');
    $stmt3 = $conn->prepare($queue_query);
    $stmt3->bind_param("ss", $doctor_id, $today_date);
    $stmt3->execute();
    $queue_count = $stmt3->get_result()->fetch_assoc()['total'];
    $stmt3->close();

    $stmt4 = $conn->prepare($archive_query);
    $stmt4->bind_param("s", $doctor_id);
    $stmt4->execute();
    $archive_count = $stmt4->get_result()->fetch_assoc()['total'];
    $stmt4->close();

    // --- 3. Gather Live Queue Datasets ---
    $stmt5 = $conn->prepare($list_query);
    $stmt5->bind_param("s", $doctor_id);
    $stmt5->execute();
    $result_set = $stmt5->get_result();
    $appointments = [];
    while ($row = $result_set->fetch_assoc()) {
        $appointments[] = $row;
    }
    $stmt5->close();

    // --- 4. Gather Calendar Dataset ---
    $stmt6 = $conn->prepare($calendar_query);
    $stmt6->bind_param("sii", $doctor_id, $selected_year, $selected_month);
    $stmt6->execute();
    $cal_result = $stmt6->get_result();
    $appointments_by_date = [];
    
    while ($row = $cal_result->fetch_assoc()) {
        $date = $row['appointment_date'];
        if (!isset($appointments_by_date[$date])) {
            $appointments_by_date[$date] = [];
        }
        $appointments_by_date[$date][] = $row;
    }
    $stmt6->close();

} catch (mysqli_sql_exception $e) {
    die("Database Error occurred: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Systems Control Registry - MEDCORE</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        lightBg: '#F8FAFC',
                        cardWhite: '#FFFFFF',
                        brandBlue: '#2563EB',
                        brandSky: '#0EA5E9',
                        brandTeal: '#14B8A6',
                        successGreen: '#22C55E',
                        warningAmber: '#F59E0B',
                        dangerRed: '#EF4444',
                        slateText: '#1E293B',
                        borderGray: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'Plus Jakarta Sans', 'sans-serif']
                    }
                }
            }
        }
    </script>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght=300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght=400;600;700&display=swap');

        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: #F1F5F9;
        }

        ::-webkit-scrollbar-thumb {
            background: #CBD5E1;
            border-radius: 4px;
        }

        .medical-canvas-underlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 450px;
            background: radial-gradient(circle at 15% 15%, rgba(37,99,237,0.04) 0%, transparent 65%);
            z-index: 0;
            pointer-events: none;
        }

        .hover-lift {
            transition: transform .25s cubic-bezier(.34,1.56,.64,1), box-shadow .25s ease;
        }

        .hover-lift:hover {
            transform: translateY(-4px);
            box-shadow: 0 16px 24px -8px rgba(37,99,237,.08);
        }

        .gradient-border-glow {
            position: relative;
            border-radius: 1rem;
        }

        .gradient-border-glow::before {
            content: '';
            position: absolute;
            inset: -1px;
            border-radius: 1rem;
            background: linear-gradient(135deg, #2563EB10, #0EA5E910, transparent);
            z-index: -1;
            pointer-events: none;
        }

        @media print {
            aside,
            header,
            form,
            .quick-actions-grid,
            .no-print {
                display: none !important;
            }

            main {
                margin-left: 0 !important;
                width: 100 !important;
                padding: 0 !important;
            }

            .print-full-card {
                border: none !important;
                shadow: none !important;
            }
        }
        
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    </style>
</head>
<body class="min-h-full antialiased flex bg-[#F8FAFC] text-[#1E293B] overflow-x-hidden relative select-none">

    <div class="medical-canvas-underlay"></div>

    <aside id="sidebar-panel" class="fixed inset-y-0 left-0 w-66 bg-white border-r border-[#E2E8F0] p-6 flex flex-col justify-between z-50 -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out shadow-sm">
        <div class="space-y-8">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center shadow-sm shrink-0">
                        <i class="fa-solid fa-heart-pulse text-[#2563EB] text-xl"></i>
                    </div>
                    <h2 class="text-xl font-bold tracking-tight text-[#1E293B] font-sans">
                        MED<span class="text-[#2563EB]">CORE</span>
                    </h2>
                </div>
                <button onclick="toggleSidebarMenu()" class="lg:hidden text-slate-400 hover:text-slate-600 transition-colors">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <nav class="space-y-1">
                <a href="index.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold bg-[#2563EB] text-white shadow-md shadow-blue-500/10 transition-all">
                    <i class="fa-solid fa-chart-pie w-5 text-white text-base"></i>
                    <span>Dashboard Hub</span>
                </a>
                <a href="lab_reports.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-[#1E293B] transition-all">
                    <i class="fa-solid fa-flask w-5 text-slate-400 text-base"></i>
                    <span>Lab Reports</span>
                </a>
                <a href="medical_records.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-[#1E293B] transition-all">
                    <i class="fa-solid fa-user-injured w-5 text-slate-400 text-base"></i>
                    <span>Patients Record</span>
                </a>
                <a href="appointments.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-[#1E293B] transition-all">
                    <i class="fa-solid fa-calendar-check w-5 text-slate-400 text-base"></i>
                    <span>Appointments</span>
                </a>
                <a href="Profile.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-[#1E293B] transition-all">
                    <i class="fa-solid fa-user-md w-5 text-slate-400 text-base"></i>
                    <span>Profile</span>
                </a>
            </nav>
        </div>

        <div class="border-t border-[#E2E8F0] pt-4">
            <a href="logout.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-[#EF4444] hover:bg-red-50/50 transition-all">
                <i class="fa-solid fa-right-from-bracket w-5 text-base"></i>
                <span>Sign Out</span>
            </a>
        </div>
    </aside>

    <div id="sidebar-backdrop" onclick="toggleSidebarMenu()" class="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 hidden lg:hidden transition-all"></div>

    <div class="flex-1 min-w-0 lg:pl-64 flex flex-col transition-all duration-300 z-10">
        
        <header class="bg-white/80 px-8 py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between sticky top-0 z-30 gap-4 border-b border-[#E2E8F0] backdrop-blur-md">
            <div class="flex items-center gap-3">
                <button onclick="toggleSidebarMenu()" class="lg:hidden p-2.5 border border-[#E2E8F0] bg-white rounded-xl text-slate-600 hover:bg-slate-50 transition-colors">
                    <i class="fa-solid fa-bars-staggered text-sm"></i>
                </button>
                <div>
                    <div class="flex items-center gap-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        <span>MEDCORE</span>
                        <i class="fa-solid fa-chevron-right text-[9px] text-slate-300"></i>
                        <span>CLINICAL ANALYTICS</span>
                    </div>
                    <h1 class="text-2xl font-bold text-[#1E293B] tracking-tight mt-0.5 font-sans">Systems Control Registry</h1>
                </div>
            </div>
            
            <div class="flex items-center flex-wrap sm:flex-nowrap gap-3 w-full sm:w-auto justify-end">
                <div class="relative w-full sm:w-64">
                    <span class="absolute inset-y-0 left-3.5 flex items-center text-slate-400 pointer-events-none">
                        <i class="fa-solid fa-magnifying-glass text-xs"></i>
                    </span>
                    <input type="text" placeholder="Global system lookup..." class="w-full bg-white border border-[#E2E8F0] focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/5 rounded-xl pl-9 pr-4 py-2 text-xs font-medium text-slate-700 outline-none transition-all shadow-sm">
                </div>
                <div class="bg-white border border-[#E2E8F0] px-3.5 py-2 rounded-xl flex items-center gap-3 text-sm font-medium text-slate-700 shadow-sm">
                    <span class="flex items-center gap-1.5 text-[#2563EB] font-bold tabular-nums">
                        <i class="fa-regular fa-clock text-slate-400 font-normal"></i>
                        <span id="live-clock-timestamp">00:00:00</span>
                    </span>
                    <span class="w-px h-4 bg-[#E2E8F0]"></span>
                    <span class="text-slate-500 font-medium flex items-center gap-1.5">
                        <i class="fa-regular fa-calendar text-slate-400"></i>
                        <?php echo date("M d, Y"); ?>
                    </span>
                </div>
                <div class="w-10 h-10 rounded-xl bg-[#2563EB] text-white font-bold flex items-center justify-center text-sm shadow-md shadow-blue-500/10 select-none">
                    <?php echo strtoupper(substr($doctor_name, 0, 1)); ?>
                </div>
            </div>
        </header>

        <main class="px-8 py-8 space-y-6 flex-grow">
            
            <section class="bg-gradient-to-r from-blue-50/70 via-sky-50/40 to-white border border-[#E2E8F0] rounded-2xl p-6 relative overflow-hidden shadow-sm transition-all duration-300">
                <div class="space-y-3 max-w-3xl relative z-10">
                    <div>
                        <p class="text-[11px] font-bold uppercase tracking-wider text-[#2563EB]">System Analytics Infrastructure</p>
                        <h2 class="text-xl font-bold tracking-tight text-[#1E293B] mt-0.5">Clinical Infrastructure Node Overview</h2>
                    </div>
                    <p class="text-xs text-slate-500 leading-relaxed font-medium">
                        Welcome back, <span class="font-bold text-slate-700">Dr. <?php echo htmlspecialchars($doctor_name); ?></span>. Track dynamic operational metrics, audit registry data vectors, and trace real-time appointment pipelines instantaneously.
                    </p>
                    <div class="flex flex-wrap gap-2.5 pt-1.5 no-print">
                        <button onclick="window.print()" class="px-4 py-2 bg-[#1E293B] hover:bg-slate-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-sm">
                            <i class="fa-solid fa-print mr-1.5"></i> Print Dashboard
                        </button>
                        <a href="appointments.php" class="px-4 py-2 bg-white text-slate-700 border border-[#E2E8F0] hover:bg-slate-50 font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-sm inline-flex items-center">
                            <i class="fa-solid fa-list-check mr-1.5 text-[#2563EB]"></i> Appointments Registry Matrix
                        </a>
                    </div>
                </div>
            </section>

            <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                <div class="bg-white border border-[#E2E8F0] p-5 rounded-2xl shadow-sm flex items-center justify-between transition-all duration-300 hover-lift border-b-4 border-b-[#2563EB]">
                    <div>
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Pending Actions</p>
                        <h3 class="text-3xl font-bold text-[#1E293B] mt-1 counter-item tracking-tight" data-target="<?php echo $pending_count; ?>">0</h3>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-blue-50 text-[#2563EB] flex items-center justify-center shrink-0 shadow-inner">
                        <i class="fa-solid fa-clock-rotate-left text-lg"></i>
                    </div>
                </div>
                <div class="bg-white border border-[#E2E8F0] p-5 rounded-2xl shadow-sm flex items-center justify-between transition-all duration-300 hover-lift border-b-4 border-b-[#0EA5E9]">
                    <div>
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Completed Sessions</p>
                        <h3 class="text-3xl font-bold text-[#1E293B] mt-1 counter-item tracking-tight" data-target="<?php echo $completed_count; ?>">0</h3>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-sky-50 text-[#0EA5E9] flex items-center justify-center shrink-0 shadow-inner">
                        <i class="fa-solid fa-circle-check text-lg"></i>
                    </div>
                </div>
                <div class="bg-white border border-[#E2E8F0] p-5 rounded-2xl shadow-sm flex items-center justify-between transition-all duration-300 hover-lift border-b-4 border-b-[#14B8A6]">
                    <div>
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Today's Inflow</p>
                        <h3 class="text-3xl font-bold text-[#1E293B] mt-1 counter-item tracking-tight" data-target="<?php echo $queue_count; ?>">0</h3>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-teal-50 text-[#14B8A6] flex items-center justify-center shrink-0 shadow-inner">
                        <i class="fa-solid fa-hospital-user text-lg"></i>
                    </div>
                </div>
                <div class="bg-white border border-[#E2E8F0] p-5 rounded-2xl shadow-sm flex items-center justify-between transition-all duration-300 hover-lift border-b-4 border-b-indigo-500">
                    <div>
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Stored Records</p>
                        <h3 class="text-3xl font-bold text-[#1E293B] mt-1 counter-item tracking-tight" data-target="<?php echo $archive_count; ?>">0</h3>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-indigo-50/60 text-indigo-500 flex items-center justify-center shrink-0 shadow-inner">
                        <i class="fa-solid fa-folder-tree text-lg"></i>
                    </div>
                </div>
            </section>

            <section class="bg-white border border-[#E2E8F0] rounded-2xl p-6 shadow-sm gradient-border-glow hover-lift">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-[#E2E8F0] pb-5 mb-5 gap-4">
                    <div class="flex items-start gap-3">
                        <div class="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0">
                            <i class="fa-regular fa-calendar-days text-[#2563EB]"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-[#1E293B] tracking-tight font-sans flex items-center gap-2">
                                Appointments Schedule Calendar
                            </h3>
                            <p class="text-xs text-slate-400 mt-0.5 font-medium">Select a dynamic year and month vector configuration grid to view metrics.</p>
                        </div>
                    </div>
                    
                    <div class="no-print">
                        <form method="GET" action="index.php" id="monthFilterForm" class="flex items-center flex-wrap gap-2 bg-slate-50 border border-[#E2E8F0] px-3 py-2 rounded-xl">
                            
                            <div class="relative flex items-center">
                                <span class="text-[10px] font-bold text-[#2563EB] uppercase tracking-wider mr-1.5 select-none">Year:</span>
                                <select name="filter_year" onchange="document.getElementById('monthFilterForm').submit();" class="pl-2 pr-6 py-1 bg-white border border-[#E2E8F0] rounded-lg text-xs font-bold text-slate-700 outline-none appearance-none cursor-pointer">
                                    <?php foreach ($available_years as $yr): ?>
                                        <option value="<?php echo $yr; ?>" <?php if($filter_year == $yr) echo 'selected'; ?>><?php echo $yr; ?> Fiscal</option>
                                    <?php endforeach; ?>
                                </select>
                                <span class="absolute right-1.5 pointer-events-none text-slate-400 text-[9px]"><i class="fa-solid fa-chevron-down"></i></span>
                            </div>

                            <span class="w-px h-4 bg-[#E2E8F0] mx-1"></span>

                            <div class="relative flex items-center">
                                <span class="text-[10px] font-bold text-[#2563EB] uppercase tracking-wider mr-1.5 select-none">Month:</span>
                                <select name="month_filter" id="month_filter" onchange="document.getElementById('monthFilterForm').submit();" class="pl-2 pr-6 py-1 bg-white border border-[#E2E8F0] rounded-lg text-xs font-bold text-slate-700 outline-none appearance-none cursor-pointer">
                                    <?php
                                    for ($m = 1; $m <= 12; $m++) {
                                        $m_padded = sprintf("%02d", $m);
                                        $m_label = date('F', strtotime("2026-$m_padded-01"));
                                        $selected = ($m_padded == $selected_month) ? 'selected' : '';
                                        echo "<option value='{$m_padded}' {$selected}>{$m_label}</option>";
                                    }
                                    ?>
                                </select>
                                <span class="absolute right-1.5 pointer-events-none text-slate-400 text-[9px]"><i class="fa-solid fa-chevron-down"></i></span>
                            </div>

                        </form>
                    </div>
                </div>

                <div class="grid grid-cols-7 gap-3 text-center text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-3">
                    <div class="py-1">Sun</div><div class="py-1">Mon</div><div class="py-1">Tue</div><div class="py-1">Wed</div><div class="py-1">Thu</div><div class="py-1">Fri</div><div class="py-1">Sat</div>
                </div>

                <div class="grid grid-cols-7 gap-3">
                    <?php
                    $first_day_of_month = date('w', strtotime($selected_month_year . '-01'));
                    $days_in_month = date('t', strtotime($selected_month_year . '-01'));
                    
                    for ($i = 0; $i < $first_day_of_month; $i++) {
                        echo '<div class="h-16 bg-slate-50/40 border border-slate-100/50 rounded-xl"></div>';
                    }
                    
                    for ($day = 1; $day <= $days_in_month; $day++) {
                        $current_loop_date = $selected_month_year . '-' . sprintf("%02d", $day);
                        $has_appointments = isset($appointments_by_date[$current_loop_date]);
                        $count_app = $has_appointments ? count($appointments_by_date[$current_loop_date]) : 0;
                        
                        $cell_style = "bg-white border border-[#E2E8F0] text-slate-700 hover:border-slate-300 transition-all duration-200 ease-out shadow-sm";
                        
                        if ($has_appointments) {
                            $cell_style = "bg-blue-50/40 border border-blue-100 cursor-pointer hover:scale-[1.03] hover:bg-blue-50/70 transition-all duration-200 ease-out";
                        }
                        
                        if ($current_loop_date == date('Y-m-d')) {
                            $cell_style .= " ring-4 ring-blue-500/10 border-[#2563EB] font-bold bg-blue-50/20";
                        }

                        echo '<div onclick="openCalendarModal(\''.$current_loop_date.'\')" class="h-16 rounded-xl p-2 flex flex-col justify-between items-end relative overflow-hidden group '.$cell_style.'">';
                        
                        if ($has_appointments) {
                            echo '<span class="absolute left-0 top-0 bottom-0 w-1 bg-[#2563EB]/70 group-hover:bg-[#2563EB] transition-all"></span>';
                        }
                        
                        echo '<span class="text-xs font-semibold text-slate-400 group-hover:text-[#1E293B] transition-colors">'.$day.'</span>';
                        
                        if ($has_appointments) {
                            echo '<span class="bg-[#2563EB] text-white font-bold text-[9px] px-1.5 py-0.5 rounded-md min-w-[18px] text-center shadow-sm shadow-blue-500/10">'.$count_app.'</span>';
                        }
                        
                        echo '</div>';
                    }
                    ?>
                </div>
            </section>

            <section class="space-y-4">
                <div class="flex justify-between items-center border-b border-[#E2E8F0] pb-3">
                    <div class="flex items-center gap-2">
                        <span class="w-2 h-2 rounded-full bg-[#22C55E]"></span>
                        <h3 class="text-xs font-bold uppercase text-slate-400 tracking-wider">
                            System Booking Velocity & Pending Channels
                        </h3>
                    </div>
                    <div class="flex gap-1.5 no-print">
                        <button onclick="scrollSlider('left')" class="w-8 h-8 rounded-lg border border-[#E2E8F0] bg-white hover:bg-slate-50 flex items-center justify-center text-slate-600 transition-all shadow-sm active:scale-95">
                            <i class="fa-solid fa-chevron-left text-xs"></i>
                        </button>
                        <button onclick="scrollSlider('right')" class="w-8 h-8 rounded-lg border border-[#E2E8F0] bg-white hover:bg-slate-50 flex items-center justify-center text-slate-600 transition-all shadow-sm active:scale-95">
                            <i class="fa-solid fa-chevron-right text-xs"></i>
                        </button>
                    </div>
                </div>

                <div id="appointmentSlider" class="flex gap-6 overflow-x-auto no-scrollbar scroll-smooth pt-2 pb-6 snap-x">
                    <?php if (empty($appointments)): ?>
                        <div class="w-full bg-white border border-[#E2E8F0] border-dashed rounded-2xl p-10 text-center text-xs font-semibold text-slate-400 italic shadow-sm">
                            <i class="fa-solid fa-circle-nodes block text-2xl text-slate-300 mb-2 font-normal"></i>
                            There are currently no patient admissions waiting in your active consultation queue.
                        </div>
                    <?php else: foreach ($appointments as $app): ?>
                        <div class="w-[300px] sm:w-[340px] flex-shrink-0 bg-white border border-[#E2E8F0] rounded-2xl p-5 shadow-sm flex flex-col justify-between gap-4 snap-start border-t-4 border-t-[#2563EB] relative overflow-hidden transition-all hover:shadow-md group">
                            
                            <div class="space-y-3 relative z-10">
                                <div class="flex justify-between items-start gap-2">
                                    <div class="min-w-0">
                                        <h4 class="font-bold text-[#1E293B] text-xs tracking-tight truncate group-hover:text-[#2563EB] transition-colors"><?php echo htmlspecialchars($app['user_email'], ENT_QUOTES, 'UTF-8'); ?></h4>
                                        <p class="text-[10px] text-slate-400 font-semibold tracking-wider uppercase mt-0.5">Patient Channel ID</p>
                                    </div>
                                    <span class="px-2 py-0.5 bg-blue-50 border border-blue-100 text-[#2563EB] text-[9px] font-bold rounded-md shrink-0 flex items-center gap-1">
                                        <span class="w-1 h-1 rounded-full bg-[#2563EB] animate-pulse"></span>
                                        Awaiting
                                    </span>
                                </div>
                                
                                <div class="bg-slate-50/80 border border-slate-100 rounded-xl p-3 text-xs text-slate-500 leading-relaxed italic border-l-2 border-l-[#2563EB]/40">
                                    "<?php echo htmlspecialchars($app['symptom'] ? $app['symptom'] : 'No structural details provided.', ENT_QUOTES, 'UTF-8'); ?>"
                                </div>
                            </div>
                            
                            <div class="flex items-center justify-between pt-3 border-t border-[#E2E8F0] text-xs relative z-10">
                                <span class="font-semibold text-slate-600 flex items-center gap-1.5 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-100">
                                    <i class="fa-regular fa-clock text-[#2563EB]"></i>
                                    <?php echo htmlspecialchars($app['timing'], ENT_QUOTES, 'UTF-8'); ?>
                                </span>
                                <a href="appointments.php" class="text-[#2563EB] font-bold hover:text-blue-700 flex items-center gap-1 text-[11px] bg-blue-50/40 hover:bg-blue-50 px-2.5 py-1 rounded-lg border border-transparent hover:border-blue-100 transition-all">
                                    Manage Entry 
                                    <i class="fa-solid fa-arrow-right text-[10px] transition-transform group-hover:translate-x-0.5"></i>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </section>
        </main>
    </div>

    <div id="calendarModal" class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100] hidden flex items-center justify-center p-4 transition-all duration-300 opacity-0">
        <div class="bg-white border border-[#E2E8F0] w-full max-w-2xl rounded-2xl shadow-xl flex flex-col max-h-[85vh] transform scale-95 transition-all duration-300 ease-out overflow-hidden">
            <div class="p-5 border-b border-[#E2E8F0] flex justify-between items-center bg-slate-50">
                <div class="flex items-center gap-2.5">
                    <div class="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center text-[#2563EB] text-sm shadow-inner"><i class="fa-solid fa-network-wired"></i></div>
                    <div>
                        <h3 class="text-base font-bold text-[#1E293B] tracking-tight">Day Matrix Appointments</h3>
                        <p class="text-xs text-[#2563EB] font-semibold tracking-wider mt-0.5" id="modalTargetDate">Date Vector</p>
                    </div>
                </div>
                <button onclick="closeCalendarModal()" class="text-slate-400 hover:text-slate-600 bg-white p-2 border border-[#E2E8F0] rounded-xl transition-all shadow-sm">
                    <i class="fa-solid fa-xmark text-sm"></i>
                </button>
            </div>
            <div class="p-6 overflow-y-auto space-y-4 no-scrollbar bg-[#F8FAFC]" id="modalContentWrapper"></div>
        </div>
    </div>

    <script>
        const appointmentsDatabase = <?php echo json_encode($appointments_by_date); ?>;

        function openCalendarModal(dateString) {
            const modal = document.getElementById('calendarModal');
            const targetDateHeader = document.getElementById('modalTargetDate');
            const wrapper = document.getElementById('modalContentWrapper');
            
            targetDateHeader.innerText = "Schedule Registry (Pending): " + dateString;
            wrapper.innerHTML = "";

            const dayRecords = appointmentsDatabase[dateString];

            if (!dayRecords || dayRecords.length === 0) {
                wrapper.innerHTML = `
                    <div class="text-center py-8 text-xs italic font-semibold text-slate-400 border border-dashed border-[#E2E8F0] rounded-xl bg-white shadow-sm">
                        <i class="fa-regular fa-folder-open text-xl block text-slate-300 mb-1.5 font-normal"></i>
                        No pending appointments logged for this date sector.
                    </div>`;
            } else {
                dayRecords.forEach(record => {
                    const block = document.createElement('div');
                    block.className = "bg-white border border-[#E2E8F0] p-5 rounded-xl shadow-sm space-y-3 border-l-4 border-l-[#2563EB] transition-all";
                    block.innerHTML = `
                        <div class="flex justify-between items-start border-b border-slate-100 pb-2 flex-wrap gap-2">
                            <div>
                                <h4 class="font-bold text-[#1E293B] text-sm">${record.patient_name ? record.patient_name : 'N/A'}</h4>
                                <span class="text-xs text-slate-400 font-medium">${record.user_email}</span>
                            </div>
                            <div class="flex items-center gap-1.5 bg-blue-50 border border-blue-100 text-[#2563EB] px-2.5 py-1 rounded-lg text-xs font-bold shadow-inner">
                                <i class="fa-regular fa-clock text-[11px]"></i>
                                ${record.timing}
                            </div>
                        </div>
                        <div class="grid grid-cols-3 gap-3 bg-slate-50/60 p-3 rounded-lg border border-slate-100 text-xs font-semibold text-slate-500">
                            <div><p class="text-[10px] text-slate-400 uppercase tracking-wider">Gender</p><span class="text-[#1E293B] font-bold">${record.gender ? record.gender : 'N/A'}</span></div>
                            <div><p class="text-[10px] text-slate-400 uppercase tracking-wider">Age Factor</p><span class="text-[#1E293B] font-bold">${record.age ? record.age : 'N/A'} Yrs</span></div>
                            <div><p class="text-[10px] text-slate-400 uppercase tracking-wider">Blood Group</p><span class="text-[#EF4444] font-bold">${record.blood_group ? record.blood_group : 'N/A'}</span></div>
                        </div>
                        <div class="text-xs text-slate-500 bg-slate-50/40 p-3 border border-slate-100 rounded-lg leading-relaxed">
                            <span class="font-bold text-[#1E293B] block text-[10px] uppercase tracking-wider mb-1">Symptom Vector Analysis</span>
                            <span class="italic">"${record.symptom ? record.symptom : 'No explicit structural details allocated.'}"</span>
                        </div>
                    `;
                    wrapper.appendChild(block);
                });
            }

            modal.classList.remove('hidden');
            setTimeout(() => {
                modal.classList.remove('opacity-0');
                modal.querySelector('.transform').classList.remove('scale-95');
            }, 10);
        }

        function closeCalendarModal() {
            const modal = document.getElementById('calendarModal');
            modal.classList.add('opacity-0');
            modal.querySelector('.transform').classList.add('scale-95');
            setTimeout(() => modal.classList.add('hidden'), 300);
        }

        function toggleSidebarMenu() {
            const panel = document.getElementById('sidebar-panel');
            const backdrop = document.getElementById('sidebar-backdrop');
            if(panel.classList.contains('-translate-x-full')) {
                panel.classList.remove('-translate-x-full');
                backdrop.classList.remove('hidden');
            } else {
                panel.classList.add('-translate-x-full');
                backdrop.classList.add('hidden');
            }
        }

        function runLiveClock() {
            const el = document.getElementById('live-clock-timestamp');
            if(el) {
                const now = new Date();
                el.innerText = now.toTimeString().split(' ')[0];
            }
        }
        setInterval(runLiveClock, 1000); runLiveClock();

        document.addEventListener("DOMContentLoaded", () => {
            document.querySelectorAll('.counter-item').forEach(c => {
                const tgt = +c.getAttribute('data-target');
                if (tgt === 0) { c.innerText = '0'; return; }
                let curr = 0; const step = tgt / 20;
                const up = () => { curr += step; if(curr < tgt) { c.innerText = Math.floor(curr); requestAnimationFrame(up); } else { c.innerText = tgt; } };
                up();
            });
        });

        function scrollSlider(direction) {
            const container = document.getElementById('appointmentSlider');
            const scrollAmount = 340; 
            if (direction === 'left') {
                container.scrollLeft -= scrollAmount;
            } else {
                container.scrollLeft += scrollAmount;
            }
        }
    </script>
</body>
</html>