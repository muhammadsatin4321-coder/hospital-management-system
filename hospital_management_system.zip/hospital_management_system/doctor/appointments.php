<?php
session_start();
include("../includes/conn.php");

if (!isset($_SESSION['doctor_id'])) {
    header("Location: login.php");
    exit();
}

$doctor_id = $_SESSION['doctor_id'];
$doctor_name = isset($_SESSION['doctor_name']) ? $_SESSION['doctor_name'] : "Specialist";
$filter_status = isset($_GET['filter_status']) ? trim($_GET['filter_status']) : '';
$msg = "";

if (isset($_GET['complete'])) {
    $id = intval($_GET['complete']);
    
    $update_query = "UPDATE appointment SET status='Completed' WHERE id=? AND doctor_id=?";
    if ($stmt = $conn->prepare($update_query)) {
        $stmt->bind_param("is", $id, $doctor_id);
        if ($stmt->execute()) {
            $stmt->close();
            header("Location: appointments.php?success=1");
            exit();
        } else {
            $msg = "Error updating database ledger: " . $conn->error;
        }
        $stmt->close();
    }
}

$conditions = ["doctor_id = ?"];
$types = "s";
$params = [$doctor_id];

if (isset($_GET['search']) && !empty(trim($_GET['search']))) {
    $search = trim($_GET['search']);
    $conditions[] = "(patient_name LIKE ? OR user_email LIKE ?)";
    $types .= "ss";
    $search_param = "%" . $search . "%";
    $params[] = $search_param;
    $params[] = $search_param;
}

if (!empty($filter_status)) {
    $conditions[] = "status = ?";
    $types .= "s";
    $params[] = $filter_status;
}

$query = "SELECT id, patient_name, user_email, symptom, appointment_date, `timing`, status FROM appointment WHERE " . implode(" AND ", $conditions) . " ORDER BY appointment_date DESC, `timing` ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth h-full bg-[#F8FAFC]">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments Desk - MEDCORE</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    
    <script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    lightBg: '#F8FAFC',
                    cardWhite: '#FFFFFF',
                    brandBlue: '#2563EB',
                    brandSky: '#0EA5E9',
                    brandTeal: '#14B8A6',
                    successGreen: '#22C55E',
                    warningAmber: '#F59E0B',
                    dangerRed: '#EF4444',
                    slateText: '#1E293B',
                    borderGray: '#E2E8F0'
                },
                fontFamily: {
                    sans: ['Inter', 'Plus Jakarta Sans', 'sans-serif']
                }
            }
        }
    }
    </script>
    
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;600;700&display=swap');

    ::-webkit-scrollbar {
        width: 6px;
        height: 6px;
    }

    ::-webkit-scrollbar-track {
        background: #F1F5F9;
    }

    ::-webkit-scrollbar-thumb {
        background: #CBD5E1;
        border-radius: 4px;
    }

    .medical-canvas-underlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 450px;
        background: radial-gradient(circle at 15% 15%, rgba(37,99,237,0.04) 0%, transparent 65%);
        z-index: 0;
        pointer-events: none;
    }

    .hover-lift {
        transition: transform .25s cubic-bezier(.34,1.56,.64,1), box-shadow .25s ease;
    }

    .hover-lift:hover {
        transform: translateY(-4px);
        box-shadow: 0 16px 24px -8px rgba(37,99,237,.08);
    }

    .gradient-border-glow {
        position: relative;
        border-radius: 1rem;
    }

    .gradient-border-glow::before {
        content: '';
        position: absolute;
        inset: -1px;
        border-radius: 1rem;
        background: linear-gradient(135deg, #2563EB10, #0EA5E910, transparent);
        z-index: -1;
        pointer-events: none;
    }

    @media print {
        aside, header, form, .quick-actions-grid, .no-print {
            display: none !important;
        }

        main {
            margin-left: 0 !important;
            width: 100 !important;
            padding: 0 !important;
        }

        .print-full-card {
            border: none !important;
            box-shadow: none !important;
        }
    }
    </style>
</head>
<body class="min-h-full antialiased flex text-slateText bg-lightBg font-sans relative overflow-x-hidden selection:bg-brandBlue/10">

    <div class="medical-canvas-underlay"></div>

    <aside id="sidebar-panel" class="fixed inset-y-0 left-0 w-64 bg-cardWhite border-r border-borderGray p-6 flex flex-col justify-between z-50 -translate-x-full lg:translate-x-0 transition-all duration-300 ease-in-out shadow-sm no-print">
        <div class="space-y-8">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3 group cursor-pointer">
                    <div class="w-10 h-10 rounded-xl bg-brandBlue/10 flex items-center justify-center shadow-sm shrink-0 transition-transform duration-500 group-hover:rotate-[360deg]">
                        <i class="fa-solid fa-heart-pulse text-brandBlue text-lg"></i>
                    </div>
                    <h2 class="text-xl font-extrabold tracking-tight text-slateText uppercase">MED<span class="text-brandSky">CORE</span></h2>
                </div>
                <button onclick="toggleSidebarMenu()" class="lg:hidden text-slate-400 hover:text-slate-600 p-1.5 hover:bg-lightBg rounded-xl transition-colors">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <nav class="space-y-1">
                <a href="index.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-chart-pie text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Dashboard Hub
                </a>
                <a href="lab_reports.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-flask text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Lab Reports
                </a>
                <a href="medical_records.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-stethoscope text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Patients Record
                </a>
                <a href="appointments.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold bg-brandBlue text-white shadow-md shadow-brandBlue/20 transition-all duration-300">
                    <i class="fa-solid fa-calendar-check w-5 text-center text-white"></i> Appointments
                </a>
                <a href="Profile.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-user text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Profile
                </a>
            </nav>
        </div>

        <div class="border-t border-borderGray pt-4">
            <a href="logout.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-dangerRed hover:bg-dangerRed/5 transition-all duration-200 group">
                <i class="fa-solid fa-arrow-right-from-bracket group-hover:translate-x-1 transition-transform duration-200"></i> Sign Out
            </a>
        </div>
    </aside>

    <div id="sidebar-backdrop" onclick="toggleSidebarMenu()" class="fixed inset-0 bg-slateText/20 backdrop-blur-sm z-40 hidden lg:hidden transition-all duration-300 no-print"></div>

    <div class="flex-1 min-w-0 lg:pl-64 flex flex-col transition-all duration-300 z-10 relative">
        
        <header class="bg-cardWhite/90 px-8 py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between sticky top-0 z-30 gap-4 border-b border-b-borderGray backdrop-blur-md transition-all duration-300 no-print">
            <div class="flex items-center gap-3">
                <button onclick="toggleSidebarMenu()" class="lg:hidden p-2.5 border border-borderGray bg-cardWhite rounded-xl text-slateText hover:bg-lightBg transition-colors">
                    <i class="fa-solid fa-bars-staggered"></i>
                </button>
                <div>
                    <p class="text-[10px] font-bold text-brandBlue uppercase tracking-widest bg-brandBlue/10 px-2 py-0.5 rounded inline-block">MEDCORE · SCHEDULING TERMINAL</p>
                    <h1 class="text-xl font-bold text-slateText tracking-tight mt-0.5">Manage Appointments</h1>
                </div>
            </div>
            <div class="flex items-center gap-3 w-full sm:w-auto justify-end">
                <div class="bg-cardWhite border border-borderGray px-3 py-2 rounded-xl flex items-center gap-2 text-xs font-bold text-slate-600 shadow-sm border-l-4 border-l-brandBlue transition-all duration-300">
                    <i class="fa-regular fa-clock text-brandBlue"></i>
                    <span id="live-clock-timestamp" class="text-slateText tabular-nums font-extrabold tracking-wide">00:00:00</span>
                    <span class="text-borderGray">|</span>
                    <span class="text-slate-400 font-medium"><?php echo date("M d, Y"); ?></span>
                </div>
                <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-brandBlue to-brandSky text-white font-bold flex items-center justify-center text-sm shadow-md shadow-brandBlue/10 transform hover:scale-105 transition-all duration-300">
                    <?php echo strtoupper(substr($doctor_name, 0, 1)); ?>
                </div>
            </div>
        </header>

        <main class="px-8 py-6 space-y-6 flex-grow">
            
            <?php if (!empty($msg) || isset($_GET['success'])): ?>
                <div id="alert-toast" class="bg-successGreen/10 border border-successGreen text-successGreen rounded-xl px-5 py-4 text-xs font-bold flex items-center justify-between shadow-sm transition-all duration-500 transform no-print">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid fa-circle-check text-base"></i>
                        <span><?php echo !empty($msg) ? htmlspecialchars($msg) : "Appointment updated successfully in the live database matrix."; ?></span>
                    </div>
                    <button onclick="document.getElementById('alert-toast').style.display='none'" class="text-slate-400 hover:text-slate-600 cursor-pointer"><i class="fa-solid fa-xmark"></i></button>
                </div>
            <?php endif; ?>

            <section class="bg-cardWhite border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col xl:flex-row items-center justify-between gap-4 hover-lift no-print">
                <div class="flex flex-wrap items-center gap-2 w-full xl:w-auto">
                    <a href="appointments.php" class="px-4 py-2.5 text-xs font-bold rounded-xl border transition-all duration-200 <?php echo empty($filter_status) ? 'bg-brandBlue text-white shadow-md shadow-brandBlue/20 border-transparent' : 'bg-lightBg text-slate-600 border-borderGray hover:bg-slate-100'; ?>">
                        <i class="fa-solid fa-list-ul mr-1.5"></i> All Records
                    </a>
                    <a href="appointments.php?filter_status=Pending" class="px-4 py-2.5 text-xs font-bold rounded-xl border transition-all duration-200 <?php echo $filter_status == 'Pending' ? 'bg-brandBlue text-white shadow-md shadow-brandBlue/20 border-transparent' : 'bg-lightBg text-slate-600 border-borderGray hover:bg-slate-100'; ?>">
                        <i class="fa-solid fa-clock text-xs mr-1.5"></i> Pending Only
                    </a>
                    <a href="appointments.php?filter_status=Completed" class="px-4 py-2.5 text-xs font-bold rounded-xl border transition-all duration-200 <?php echo $filter_status == 'Completed' ? 'bg-brandBlue text-white shadow-md shadow-brandBlue/20 border-transparent' : 'bg-lightBg text-slate-600 border-borderGray hover:bg-slate-100'; ?>">
                        <i class="fa-solid fa-circle-check mr-1.5"></i> Completed Nodes
                    </a>
                </div>
                
                <form method="GET" action="appointments.php" class="flex items-center gap-2 w-full xl:w-80 relative">
                    <?php if(!empty($filter_status)): ?>
                        <input type="hidden" name="filter_status" value="<?php echo htmlspecialchars($filter_status); ?>">
                    <?php endif; ?>
                    <div class="relative w-full group">
                        <span class="absolute inset-y-0 left-3.5 flex items-center text-slate-400 group-focus-within:text-brandBlue transition-colors"><i class="fa-solid fa-magnifying-glass text-xs"></i></span>
                        <input type="text" name="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>" placeholder="Search by name or email..." class="w-full bg-lightBg border border-borderGray focus:border-brandBlue focus:bg-cardWhite rounded-xl pl-9 pr-4 py-2 text-xs font-semibold text-slateText outline-none transition-all duration-200 shadow-inner">
                    </div>
                    <button type="submit" class="px-5 py-2 bg-slateText hover:bg-slateText/90 text-white font-bold text-xs uppercase rounded-xl transition-all tracking-wider shrink-0 cursor-pointer">Find</button>
                </form>
            </section>

            <section class="bg-cardWhite border border-borderGray rounded-2xl shadow-sm overflow-hidden print-full-card">
                <div class="overflow-x-auto">
                    <table class="w-full border-collapse text-left">
                        <thead>
                            <tr class="bg-slateText border-b border-slateText text-white text-[10px] font-bold uppercase tracking-wider">
                                <th class="px-6 py-4"><i class="fa-solid fa-hashtag mr-1"></i> Channel ID</th>
                                <th class="px-6 py-4"><i class="fa-regular fa-user mr-1"></i> Patient Profile Context</th>
                                <th class="px-6 py-4"><i class="fa-solid fa-notes-medical mr-1"></i> Reported Symptoms</th>
                                <th class="px-6 py-4"><i class="fa-regular fa-calendar mr-1"></i> Slot Configuration</th>
                                <th class="px-6 py-4"><i class="fa-solid fa-flag mr-1"></i> Status Flag</th>
                                <th class="px-6 py-4 text-center no-print"><i class="fa-solid fa-gear mr-1"></i> Actions Blueprint</th>
                            </tr>
                        </thead>
                        <tbody class="text-xs divide-y divide-borderGray font-medium text-slate-500 bg-cardWhite">
                            <?php if ($result->num_rows === 0): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-20 text-xs text-slate-400 italic bg-lightBg/50">
                                        <div class="flex flex-col items-center justify-center gap-3">
                                            <i class="fa-regular fa-folder-open text-4xl text-slate-300"></i>
                                            <span class="font-bold text-slate-400">No upcoming appointment sequences detected within the filter timeline matrix.</span>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <tr class="hover:bg-lightBg transition-colors duration-150 group">
                                        <td class="px-6 py-4 font-mono font-bold text-brandBlue">
                                            #APP-<?php echo $row['id']; ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="font-bold text-slateText text-sm tracking-tight group-hover:text-brandBlue transition-colors"><?php echo htmlspecialchars($row['patient_name'] ?? 'In-flight Registration Node', ENT_QUOTES, 'UTF-8'); ?></div>
                                            <div class="text-[10px] text-slate-400 font-mono mt-0.5"><?php echo htmlspecialchars($row['user_email'], ENT_QUOTES, 'UTF-8'); ?></div>
                                        </td>
                                        <td class="px-6 py-4 max-w-xs truncate text-slate-500 italic">
                                            "<?php echo htmlspecialchars($row['symptom'] ?? 'N/A', ENT_QUOTES, 'UTF-8'); ?>"
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="font-bold text-slateText"><?php echo htmlspecialchars($row['appointment_date'], ENT_QUOTES, 'UTF-8'); ?></div>
                                            <div class="text-[10px] text-brandBlue font-bold tracking-wide mt-0.5"><i class="fa-regular fa-clock text-[9px] mr-0.5"></i> <?php echo htmlspecialchars($row['timing'], ENT_QUOTES, 'UTF-8'); ?></div>
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php if (empty($row['status']) || $row['status'] == "Pending"): ?>
                                                <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[10px] font-extrabold bg-warningAmber/10 text-warningAmber border border-warningAmber/20">
                                                    <span class="w-1.5 h-1.5 rounded-full bg-warningAmber animate-pulse"></span>
                                                    Pending Sync
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[10px] font-extrabold bg-successGreen/10 text-successGreen border border-successGreen/20">
                                                    <span class="w-1.5 h-1.5 rounded-full bg-successGreen"></span>
                                                    Completed Node
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 text-center no-print">
                                            <div class="flex items-center justify-center gap-2">
                                                <?php if (empty($row['status']) || $row['status'] == "Pending"): ?>
                                                    <a href="appointments.php?complete=<?php echo $row['id']; ?>" class="px-3 py-1.5 bg-lightBg hover:bg-borderGray text-slateText font-bold text-[11px] rounded-xl border border-borderGray transition-all transform active:scale-95">
                                                        Quick Complete
                                                    </a>
                                                    <a href="medical_records.php?appointment_id=<?php echo $row['id']; ?>" class="px-3 py-1.5 bg-brandBlue hover:bg-brandBlue/90 text-white font-bold text-[11px] rounded-xl transition-all shadow-md shadow-brandBlue/10 transform active:scale-95">
                                                        <i class="fa-solid fa-file-signature text-[10px] mr-1"></i> Complete Slip
                                                    </a>
                                                <?php else: ?>
                                                    <a href="medical_records.php?appointment_id=<?php echo $row['id']; ?>" class="px-4 py-1.5 bg-successGreen/10 text-successGreen font-bold text-[11px] rounded-xl border border-successGreen/20 hover:bg-successGreen/20 transition-all transform active:scale-95">
                                                        <i class="fa-regular fa-eye text-[10px] mr-1"></i> View Entry
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="px-6 py-4 bg-lightBg border-t border-borderGray text-xs font-semibold text-slate-400 flex justify-between items-center">
                    <span>Matrix Grid Status Count: Displayed <?php echo $result->num_rows; ?> active result rows.</span>
                    <span class="text-[10px] tracking-wider uppercase font-bold text-brandBlue bg-brandBlue/10 px-2.5 py-0.5 rounded-md border border-brandBlue/20">Live Sync Authorized</span>
                </div>
            </section>
        </main>
    </div>

    <script>
        function toggleSidebarMenu() {
            const panel = document.getElementById('sidebar-panel');
            const backdrop = document.getElementById('sidebar-backdrop');
            if(panel.classList.contains('-translate-x-full')) {
                panel.classList.remove('-translate-x-full');
                backdrop.classList.remove('hidden');
            } else {
                panel.classList.add('-translate-x-full');
                backdrop.classList.add('hidden');
            }
        }

        function runLiveClock() {
            const el = document.getElementById('live-clock-timestamp');
            if(el) {
                const now = new Date();
                el.innerText = now.toTimeString().split(' ')[0];
            }
        }
        setInterval(runLiveClock, 1000); runLiveClock();
    </script>
</body>
</html>
<?php 
$stmt->close();
?>