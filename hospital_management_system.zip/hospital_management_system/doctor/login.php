<?php
session_start();
include("../includes/conn.php");

$error = "";

// Check if the form has actually been submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username']) && isset($_POST['password'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Run your database validation query
    $query = "SELECT * FROM doctors WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) == 1) {
        $doctor = mysqli_fetch_assoc($result);
        
        $_SESSION['doctor_id'] = $doctor['doctor_id']; 
        $_SESSION['doctor_name'] = $doctor['name'];
        
        header("Location: index.php");
        exit();
    } else {
        $error = "Invalid username or password credentials.";
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Portal - Authentication Gateway</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        lightBg: '#F8FAFC',       // Clean Off-White Background
                        cardWhite: '#FFFFFF',     // Pure White Authentication Sheet
                        brandBlue: '#2563EB',     // Vibrant Royal Blue Primary Actuator
                        brandDarkBlue: '#1E3A8A', // Sapphire Accent Layer
                        slateText: '#475569'      // Slate gray readable prose
                    },
                    fontFamily: {
                        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
                    },
                    animation: {
                        'fade-in-up': 'fadeInUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards',
                        'pulse-glow': 'pulseGlow 3s infinite ease-in-out',
                    },
                    keyframes: {
                        fadeInUp: {
                            '0%': { opacity: '0', transform: 'translateY(20px)' },
                            '100%': { opacity: '1', transform: 'translateY(0)' }
                        },
                        pulseGlow: {
                            '0%, 100%': { opacity: '0.3', transform: 'scale(1)' },
                            '50%': { opacity: '0.5', transform: 'scale(1.08)' }
                        }
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
    </style>
</head>
<body class="bg-lightBg text-slateText font-sans antialiased min-h-screen flex items-center justify-center p-4 relative overflow-hidden selection:bg-blue-100 selection:text-brandDarkBlue">

    <div class="absolute -left-20 -bottom-20 w-96 h-96 bg-blue-100/50 rounded-full blur-3xl pointer-events-none animate-pulse-glow"></div>
    <div class="absolute -right-20 -top-20 w-96 h-96 bg-sky-100/60 rounded-full blur-3xl pointer-events-none animate-pulse-glow" style="animation-delay: 1.5s;"></div>

    <div class="w-full max-w-[440px] bg-cardWhite border border-slate-200 rounded-3xl p-8 lg:p-10 shadow-xl shadow-slate-100 relative z-10 opacity-0 animate-fade-in-up">
        
        <div class="flex flex-col items-center text-center mb-8">
            <div class="w-14 h-14 bg-blue-50 border border-blue-100 rounded-2xl flex items-center justify-center mb-4 shadow-sm group">
                <svg class="text-brandBlue transform group-hover:rotate-180 transition-transform duration-700 ease-out" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
                </svg>
            </div>
            <h2 class="text-xs font-black tracking-widest text-brandBlue uppercase mb-1">Medical Specialist Portal</h2>
            <h1 class="text-2xl font-black text-slate-900 tracking-tight">Doctor Login Gateway</h1>
        </div>

        <?php if (!empty($error)): ?>
            <div class="bg-rose-50 border border-rose-100 text-rose-700 px-4 py-3 rounded-2xl text-xs font-bold text-center mb-6 shadow-sm transition-all duration-300">
                ⚠️ <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="flex flex-col gap-5">
            
            <div class="flex flex-col gap-1.5">
                <label class="text-xs font-bold text-slate-400 uppercase tracking-wider pl-1">Account Username</label>
                <input type="text" 
                       name="username" 
                       required 
                       placeholder="Enter your username"
                       class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 placeholder-slate-300 outline-none focus:border-brandBlue focus:ring-4 focus:ring-blue-50/50 transition-all duration-300">
            </div>
            
            <div class="flex flex-col gap-1.5">
                <label class="text-xs font-bold text-slate-400 uppercase tracking-wider pl-1">Security Password</label>
                <input type="password" 
                       name="password" 
                       required 
                       placeholder="Enter your password"
                       class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 placeholder-slate-300 outline-none focus:border-brandBlue focus:ring-4 focus:ring-blue-50/50 transition-all duration-300">
            </div>

            <button type="submit" 
                    class="w-full bg-brandBlue hover:bg-brandDarkBlue text-white font-bold py-3.5 px-4 rounded-xl text-xs uppercase tracking-widest shadow-md hover:shadow-lg shadow-blue-600/10 transition-all duration-300 transform active:scale-[0.98] mt-2 cursor-pointer">
                Authorize Gateway Session
            </button>
        </form>

        <div class="text-center mt-8 pt-6 border-t border-slate-100">
            <p class="text-[10px] uppercase tracking-widest text-slate-300 font-bold cursor-default">
                Clinical Node Verification Core v2.6.0
            </p>
        </div>

    </div>

</body>
</html>