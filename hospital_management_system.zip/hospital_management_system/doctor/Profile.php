<?php
session_start();
include("../includes/conn.php");

// Enable standard silent reporting so the script doesn't crash on custom errors
mysqli_report(MYSQLI_REPORT_OFF);

// Protection layer: Ensure a doctor session is active
if (!isset($_SESSION['doctor_id'])) {
    header("Location: login.php");
    exit();
}

$doctor_id = $_SESSION['doctor_id'];
$success_msg = "";
$error_msg = "";

// Dynamic Layer: Check if the doctor_schedule table actually exists in the active database schema
$table_check = mysqli_query($conn, "SHOW TABLES LIKE 'doctor_schedule'");
$has_schedule_table = ($table_check && mysqli_num_rows($table_check) > 0);

// --- 1. HANDLE PROFILE UPDATES ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $name = mysqli_real_escape_string($conn, trim($_POST['name']));
    $specialization = mysqli_real_escape_string($conn, trim($_POST['specialization']));
    $experience = mysqli_real_escape_string($conn, trim($_POST['experience']));
    $department = mysqli_real_escape_string($conn, trim($_POST['department']));
    $username = mysqli_real_escape_string($conn, trim($_POST['username']));
    $new_password =  trim($_POST['new_password']);

    $check_user = "SELECT id FROM doctors WHERE username = '$username' AND doctor_id != '$doctor_id'";
    $check_res = mysqli_query($conn, $check_user);

    if (!$check_res) {
        $error_msg = "Username verification query failed: " . mysqli_error($conn);
    } elseif (mysqli_num_rows($check_res) > 0) {
        $error_msg = "The chosen username is already assigned to another doctor.";
    } else {
        if (!empty($new_password)) {
            $escaped_password = mysqli_real_escape_string($conn, $new_password);
            $update_query = "UPDATE doctors SET name='$name', specialization='$specialization', experience='$experience', department='$department', username='$username', password='$escaped_password' WHERE doctor_id='$doctor_id'";
        } else {
            $update_query = "UPDATE doctors SET name='$name', specialization='$specialization', experience='$experience', department='$department', username='$username' WHERE doctor_id='$doctor_id'";
        }

        if (mysqli_query($conn, $update_query)) {
            $_SESSION['doctor_name'] = $name;
            $success_msg = "Profile information updated successfully.";
        } else {
            $error_msg = "Error updating profile credentials: " . mysqli_error($conn);
        }
    }
}

// --- 2. HANDLE SCHEDULE CREATION (ADD) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_schedule'])) {
    if (!$has_schedule_table) {
        $error_msg = "Scheduling feature unavailable: The 'doctor_schedule' table does not exist in the database.";
    } else {
        $day = mysqli_real_escape_string($conn, $_POST['sched_day']);
        $date = mysqli_real_escape_string($conn, $_POST['sched_date']);
        $time_slot = mysqli_real_escape_string($conn, $_POST['sched_time']);

        if (!empty($day) && !empty($date) && !empty($time_slot)) {
            $stmt = $conn->prepare("INSERT INTO doctor_schedule (doctor_id, day, date, time_slot) VALUES (?, ?, ?, ?)");
            if ($stmt === false) {
                $error_msg = "Database Error: Cannot prepare statement. " . $conn->error;
            } else {
                $stmt->bind_param("ssss", $doctor_id, $day, $date, $time_slot);
                if ($stmt->execute()) {
                    $success_msg = "New schedule slot published successfully.";
                } else {
                    $error_msg = "Failed to register schedule parameters: " . $stmt->error;
                }
                $stmt->close();
            }
        } else {
            $error_msg = "Please fill out all schedule data attributes.";
        }
    }
}

// --- 3. HANDLE SCHEDULE MODIFICATION (EDIT) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_schedule'])) {
    if (!$has_schedule_table) {
        $error_msg = "Scheduling feature unavailable: The 'doctor_schedule' table does not exist in the database.";
    } else {
        $schedule_id = intval($_POST['schedule_id']);
        $day = mysqli_real_escape_string($conn, $_POST['sched_day']);
        $date = mysqli_real_escape_string($conn, $_POST['sched_date']);
        $time_slot = mysqli_real_escape_string($conn, $_POST['sched_time']);

        if ($schedule_id > 0 && !empty($day) && !empty($date) && !empty($time_slot)) {
            $stmt = $conn->prepare("UPDATE doctor_schedule SET day = ?, date = ?, time_slot = ? WHERE id = ? AND doctor_id = ?");
            if ($stmt === false) {
                $error_msg = "Database Error: Cannot prepare update statement. " . $conn->error;
            } else {
                $stmt->bind_param("sssis", $day, $date, $time_slot, $schedule_id, $doctor_id);
                if ($stmt->execute()) {
                    $success_msg = "Schedule slot adjustments successfully saved.";
                } else {
                    $error_msg = "Failed to modify selected schedule node: " . $stmt->error;
                }
                $stmt->close();
            }
        } else {
            $error_msg = "Missing attributes required to persist slot change updates.";
        }
    }
}

// --- 4. HANDLE SCHEDULE REMOVAL (DELETE) ---
if (isset($_GET['delete_schedule']) && $has_schedule_table) {
    $schedule_id = intval($_GET['delete_schedule']);
    $stmt = $conn->prepare("DELETE FROM doctor_schedule WHERE id = ? AND doctor_id = ?");
    if ($stmt !== false) {
        $stmt->bind_param("is", $schedule_id, $doctor_id);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: Profile.php");
    exit();
}

// --- 5. DATA QUERIES RETRIEVAL GATEWAY ---
$doc_res = mysqli_query($conn, "SELECT * FROM doctors WHERE doctor_id = '$doctor_id'");
$doctor = mysqli_fetch_assoc($doc_res);
$doctor_name = $doctor['name'] ?? ($_SESSION['doctor_name'] ?? "Specialist");

$sched_res = false;
if ($has_schedule_table) {
    $sched_res = mysqli_query($conn, "SELECT * FROM doctor_schedule WHERE doctor_id = '$doctor_id' ORDER BY date ASC, time_slot ASC");
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practitioner Profile & Scheduling - MEDCORE</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        lightBg: '#F8FAFC',
                        cardWhite: '#FFFFFF',
                        brandBlue: '#2563EB',
                        brandSky: '#0EA5E9',
                        brandTeal: '#14B8A6',
                        successGreen: '#22C55E',
                        warningAmber: '#F59E0B',
                        dangerRed: '#EF4444',
                        slateText: '#1E293B',
                        borderGray: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'Plus Jakarta Sans', 'sans-serif']
                    }
                }
            }
        }
    </script>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght=300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght=400;600;700&display=swap');

        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: #F1F5F9;
        }

        ::-webkit-scrollbar-thumb {
            background: #CBD5E1;
            border-radius: 4px;
        }

        .medical-canvas-underlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 450px;
            background: radial-gradient(circle at 15% 15%, rgba(37,99,237,0.04) 0%, transparent 65%);
            z-index: 0;
            pointer-events: none;
        }

        .hover-lift {
            transition: transform .25s cubic-bezier(.34,1.56,.64,1), box-shadow .25s ease;
        }

        .hover-lift:hover {
            transform: translateY(-4px);
            box-shadow: 0 16px 24px -8px rgba(37,99,237,.08);
        }

        .gradient-border-glow {
            position: relative;
            border-radius: 1rem;
        }

        .gradient-border-glow::before {
            content: '';
            position: absolute;
            inset: -1px;
            border-radius: 1rem;
            background: linear-gradient(135deg, #2563EB10, #0EA5E910, transparent);
            z-index: -1;
            pointer-events: none;
        }

        @media print {
            aside,
            header,
            form,
            .quick-actions-grid,
            .no-print {
                display: none !important;
            }

            main {
                margin-left: 0 !important;
                width: 100 !important;
                padding: 0 !important;
            }

            .print-full-card {
                border: none !important;
                shadow: none !important;
            }
        }
    </style>
</head>
<body class="min-h-full antialiased flex bg-[#F8FAFC] text-[#1E293B] overflow-x-hidden relative">
    
    <div class="medical-canvas-underlay"></div>

    <aside id="sidebar-panel" class="fixed inset-y-0 left-0 w-66 bg-white border-r border-[#E2E8F0] p-6 flex flex-col justify-between z-50 -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out shadow-sm">
        <div class="space-y-8">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center shadow-sm shrink-0">
                        <i class="fa-solid fa-heart-pulse text-[#2563EB] text-xl"></i>
                    </div>
                    <h2 class="text-xl font-bold tracking-tight text-[#1E293B] font-sans">
                        MED<span class="text-[#2563EB]">CORE</span>
                    </h2>
                </div>
                <button onclick="toggleSidebarMenu()" class="lg:hidden text-slate-400 hover:text-slate-600 transition-colors">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <nav class="space-y-1">
                <a href="index.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-[#1E293B] transition-all">
                    <i class="fa-solid fa-chart-pie w-5 text-slate-400 text-base"></i>
                    <span>Dashboard Hub</span>
                </a>
                <a href="lab_reports.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-[#1E293B] transition-all">
                    <i class="fa-solid fa-flask w-5 text-slate-400 text-base"></i>
                    <span>Lab Reports</span>
                </a>
                <a href="medical_records.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-[#1E293B] transition-all">
                    <i class="fa-solid fa-user-injured w-5 text-slate-400 text-base"></i>
                    <span>Patients Record</span>
                </a>
                <a href="appointments.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-[#1E293B] transition-all">
                    <i class="fa-solid fa-calendar-check w-5 text-slate-400 text-base"></i>
                    <span>Appointments</span>
                </a>
                <a href="Profile.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold bg-[#2563EB] text-white shadow-md shadow-blue-500/10 transition-all">
                    <i class="fa-solid fa-user-md w-5 text-white text-base"></i>
                    <span>Profile</span>
                </a>
            </nav>
        </div>

        <div class="border-t border-[#E2E8F0] pt-4">
            <a href="logout.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-[#EF4444] hover:bg-red-50/50 transition-all">
                <i class="fa-solid fa-right-from-bracket w-5 text-base"></i>
                <span>Sign Out</span>
            </a>
        </div>
    </aside>

    <div id="sidebar-backdrop" onclick="toggleSidebarMenu()" class="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 hidden lg:hidden transition-all"></div>

    <div class="flex-1 min-w-0 lg:pl-64 flex flex-col transition-all duration-300 z-10">

        <header class="bg-white/80 px-8 py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between sticky top-0 z-30 gap-4 border-b border-[#E2E8F0] backdrop-blur-md">
            <div class="flex items-center gap-3">
                <button onclick="toggleSidebarMenu()" class="lg:hidden p-2.5 border border-[#E2E8F0] bg-white rounded-xl text-slate-600 hover:bg-slate-50 transition-colors">
                    <i class="fa-solid fa-bars-staggered text-sm"></i>
                </button>
                <div>
                    <div class="flex items-center gap-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        <span>MEDCORE</span>
                        <i class="fa-solid fa-chevron-right text-[9px] text-slate-300"></i>
                        <span>ADMINISTRATIVE PANEL</span>
                    </div>
                    <h1 class="text-2xl font-bold text-[#1E293B] tracking-tight mt-0.5 font-sans">Practitioner Configuration</h1>
                </div>
            </div>
            
            <div class="flex items-center flex-wrap gap-4 w-full sm:w-auto justify-end">
                <div class="bg-white border border-[#E2E8F0] px-3.5 py-2 rounded-xl flex items-center gap-3 text-sm font-medium text-slate-700 shadow-sm">
                    <span class="flex items-center gap-1.5 text-[#2563EB] font-bold tabular-nums">
                        <i class="fa-regular fa-clock text-slate-400 font-normal"></i>
                        <span id="live-clock-timestamp">00:00:00</span>
                    </span>
                    <span class="w-px h-4 bg-[#E2E8F0]"></span>
                    <span class="text-slate-500 font-medium flex items-center gap-1.5">
                        <i class="fa-regular fa-calendar text-slate-400"></i>
                        <?php echo date("M d, Y"); ?>
                    </span>
                </div>
                <div class="w-10 h-10 rounded-xl bg-[#2563EB] text-white font-bold flex items-center justify-center text-sm shadow-md shadow-blue-500/10 select-none">
                    <?php echo strtoupper(substr($doctor_name, 0, 1)); ?>
                </div>
            </div>
        </header>

        <main class="px-8 py-8 space-y-6 flex-grow">
            
            <?php if (!empty($success_msg)): ?>
                <div class="bg-[#22C55E]/10 border border-[#22C55E]/20 text-[#22C55E] rounded-xl px-5 py-4 text-sm font-semibold flex items-center gap-3 shadow-sm max-w-5xl animate-fadeIn">
                    <i class="fa-solid fa-circle-check text-base"></i> 
                    <span><?php echo $success_msg; ?></span>
                </div>
            <?php endif; ?>

            <?php if (!empty($error_msg)): ?>
                <div class="bg-[#EF4444]/10 border border-[#EF4444]/20 text-[#EF4444] rounded-xl px-5 py-4 text-sm font-semibold flex items-center gap-3 shadow-sm max-w-5xl animate-fadeIn">
                    <i class="fa-solid fa-circle-exclamation text-base"></i> 
                    <span><?php echo $error_msg; ?></span>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start max-w-[1600px]">
                
                <section class="xl:col-span-5 bg-white border border-[#E2E8F0] rounded-2xl shadow-sm p-6 space-y-6 gradient-border-glow hover-lift">
                    <div class="flex items-start gap-3.5">
                        <div class="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0">
                            <i class="fa-solid fa-id-card text-[#2563EB]"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-bold text-[#1E293B] font-sans">1. Update Core Identity Matrix</h3>
                            <p class="text-xs text-slate-400 mt-0.5 font-medium">Maintain updated public credentials and verification parameters</p>
                        </div>
                    </div>

                    <form method="POST" class="space-y-5">
                        <div class="space-y-1.5">
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Doctor Identifier Reference</label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none">
                                    <i class="fa-solid fa-fingerprint text-xs"></i>
                                </span>
                                <input type="text" value="<?php echo htmlspecialchars($doctor['doctor_id'] ?? ''); ?>" readonly class="w-full bg-slate-50 border border-[#E2E8F0] rounded-xl pl-9 pr-4 py-2.5 text-xs font-mono font-bold text-slate-400 outline-none cursor-not-allowed">
                            </div>
                        </div>

                        <div class="space-y-1.5">
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Full Professional Name</label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none">
                                    <i class="fa-solid fa-user-doctor text-xs"></i>
                                </span>
                                <input type="text" name="name" value="<?php echo htmlspecialchars($doctor['name'] ?? ''); ?>" required class="w-full bg-white border border-[#E2E8F0] focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/5 rounded-xl pl-9 pr-4 py-2.5 text-xs font-medium text-slate-700 outline-none transition-all shadow-sm">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div class="space-y-1.5">
                                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Medical Specialization</label>
                                <div class="relative">
                                    <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none">
                                        <i class="fa-solid fa-stethoscope text-xs"></i>
                                    </span>
                                    <input type="text" name="specialization" value="<?php echo htmlspecialchars($doctor['specialization'] ?? ''); ?>" required class="w-full bg-white border border-[#E2E8F0] focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/5 rounded-xl pl-9 pr-4 py-2.5 text-xs font-medium text-slate-700 outline-none transition-all shadow-sm">
                                </div>
                            </div>
                            <div class="space-y-1.5">
                                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Practice Experience</label>
                                <div class="relative">
                                    <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none">
                                        <i class="fa-solid fa-business-time text-xs"></i>
                                    </span>
                                    <input type="text" name="experience" value="<?php echo htmlspecialchars($doctor['experience'] ?? ''); ?>" required class="w-full bg-white border border-[#E2E8F0] focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/5 rounded-xl pl-9 pr-4 py-2.5 text-xs font-medium text-slate-700 outline-none transition-all shadow-sm">
                                </div>
                            </div>
                        </div>

                        <div class="space-y-1.5">
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Hospital Department Assigned</label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none">
                                    <i class="fa-solid fa-hospital text-xs"></i>
                                </span>
                                <input type="text" name="department" value="<?php echo htmlspecialchars($doctor['department'] ?? ''); ?>" required class="w-full bg-white border border-[#E2E8F0] focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/5 rounded-xl pl-9 pr-4 py-2.5 text-xs font-medium text-slate-700 outline-none transition-all shadow-sm">
                            </div>
                        </div>

                        <div class="border-t border-[#E2E8F0] my-4 pt-1"></div>

                        <div class="space-y-1.5">
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Authentication Username</label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none">
                                    <i class="fa-solid fa-user-shield text-xs"></i>
                                </span>
                                <input type="text" name="username" value="<?php echo htmlspecialchars($doctor['username'] ?? ''); ?>" required class="w-full bg-white border border-[#E2E8F0] focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/5 rounded-xl pl-9 pr-4 py-2.5 text-xs font-mono font-semibold text-slate-700 outline-none transition-all shadow-sm">
                            </div>
                        </div>

                        <div class="space-y-1.5">
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Update Cipher Password <span class="text-slate-400 lowercase font-medium">(Leave blank to keep current)</span></label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none">
                                    <i class="fa-solid fa-key text-xs"></i>
                                </span>
                                <input type="password" name="new_password" placeholder="••••••••••••" class="w-full bg-white border border-[#E2E8F0] focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/5 rounded-xl pl-9 pr-4 py-2.5 text-xs font-medium text-slate-700 outline-none transition-all shadow-sm">
                            </div>
                        </div>

                        <button type="submit" name="update_profile" class="w-full flex items-center justify-center gap-2 py-3 bg-[#2563EB] hover:bg-blue-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-blue-500/10">
                            <i class="fa-solid fa-floppy-disk"></i>
                            <span>Save Profile Parameters</span>
                        </button>
                    </form>
                </section>

                <section class="xl:col-span-7 space-y-6">
                    
                    <div class="bg-white border border-[#E2E8F0] rounded-2xl shadow-sm p-6 space-y-5 gradient-border-glow hover-lift">
                        <div class="flex items-start gap-3.5">
                            <div class="w-10 h-10 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center shrink-0">
                                <i class="fa-solid fa-calendar-plus text-[#14B8A6]"></i>
                            </div>
                            <div>
                                <h3 id="formTitle" class="text-base font-bold text-[#1E293B] font-sans">2. Publish Available Schedule Slot</h3>
                                <p class="text-xs text-slate-400 mt-0.5 font-medium">Configure structured timeline criteria for coordinated patient routing routes</p>
                            </div>
                        </div>

                        <form id="scheduleForm" method="POST" class="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
                            <input type="hidden" name="schedule_id" id="schedule_id" value="">
                            
                            <div class="space-y-1.5">
                                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Weekday Node</label>
                                <div class="relative">
                                    <select name="sched_day" id="sched_day" required class="w-full bg-white border border-[#E2E8F0] focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/5 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-700 outline-none transition-all appearance-none shadow-sm">
                                        <option value="Monday">Monday</option>
                                        <option value="Tuesday">Tuesday</option>
                                        <option value="Wednesday">Wednesday</option>
                                        <option value="Thursday">Thursday</option>
                                        <option value="Friday">Friday</option>
                                        <option value="Saturday">Saturday</option>
                                        <option value="Sunday">Sunday</option>
                                    </select>
                                    <span class="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 pointer-events-none">
                                        <i class="fa-solid fa-chevron-down text-[10px]"></i>
                                    </span>
                                </div>
                            </div>

                            <div class="space-y-1.5">
                                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Calendar Date</label>
                                <input type="date" name="sched_date" id="sched_date" required class="w-full bg-white border border-[#E2E8F0] focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/5 rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-700 outline-none transition-all shadow-sm">
                            </div>

                            <div class="space-y-1.5">
                                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Hourly Windows Block</label>
                                <input type="text" name="sched_time" id="sched_time" required placeholder="e.g. 09:00 AM - 12:00 PM" class="w-full bg-white border border-[#E2E8F0] focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/5 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-700 outline-none transition-all shadow-sm">
                            </div>

                            <div class="sm:col-span-3 flex gap-3 mt-2">
                                <button type="submit" name="add_schedule" id="submitSchedBtn" class="flex-1 flex items-center justify-center gap-2 py-3 bg-[#1E293B] hover:bg-slate-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-slate-900/10">
                                    <i class="fa-solid fa-circle-plus"></i>
                                    <span>Publish Active Slot</span>
                                </button>
                                <button type="button" id="cancelEditBtn" onclick="resetScheduleForm()" class="px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold text-xs rounded-xl transition-all hidden">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>

                    <div class="bg-white border border-[#E2E8F0] rounded-2xl shadow-sm p-6 space-y-4 gradient-border-glow hover-lift">
                        <div>
                            <h3 class="text-xs font-bold uppercase text-[#2563EB] tracking-wider">Active Published Slots Ledgers</h3>
                            <p class="text-xs font-medium text-slate-400 mt-0.5">Structured availability coordinates allocated inside production storage matrices</p>
                        </div>

                        <div class="overflow-x-auto rounded-xl border border-[#E2E8F0]">
                            <table class="w-full text-left text-xs border-collapse">
                                <thead>
                                    <tr class="bg-slate-50/70 text-slate-500 uppercase font-bold tracking-wider border-b border-[#E2E8F0]">
                                        <th class="px-5 py-3.5">Day</th>
                                        <th class="px-5 py-3.5">Date</th>
                                        <th class="px-5 py-3.5">Time Range Allocation</th>
                                        <th class="px-5 py-3.5 text-right">Actions Matrix</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-[#E2E8F0] font-medium text-slate-600">
                                    <?php if (!$has_schedule_table): ?>
                                        <tr>
                                            <td colspan="4" class="px-5 py-8 text-center text-[#F59E0B] font-semibold bg-amber-50/50 rounded-b-xl">
                                                <div class="flex flex-col items-center gap-2">
                                                    <i class="fa-solid fa-triangle-exclamation text-2xl"></i>
                                                    <span>Database Configuration Notice: The 'doctor_schedule' table is missing. Contact system administration.</span>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php elseif ($sched_res === false || mysqli_num_rows($sched_res) === 0): ?>
                                        <tr>
                                            <td colspan="4" class="px-5 py-10 text-center text-slate-400 font-medium bg-slate-50/20">
                                                <div class="flex flex-col items-center gap-2.5">
                                                    <i class="fa-regular fa-calendar-minus text-3xl text-slate-300"></i>
                                                    <span class="italic text-slate-400">No scheduling operational timelines published inside active registers.</span>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php else: while ($row = mysqli_fetch_assoc($sched_res)): ?>
                                        <tr class="hover:bg-slate-50/50 transition-colors">
                                            <td class="px-5 py-4 font-bold text-[#1E293B]"><?php echo htmlspecialchars($row['day']); ?></td>
                                            <td class="px-5 py-4 font-mono text-slate-500"><?php echo htmlspecialchars($row['date']); ?></td>
                                            <td class="px-5 py-4">
                                                <span class="bg-blue-50/80 text-[#2563EB] font-bold px-2.5 py-1 rounded-lg text-[11px] border border-blue-100/50 inline-flex items-center gap-1.5">
                                                    <i class="fa-regular fa-clock text-[10px]"></i>
                                                    <?php echo htmlspecialchars($row['time_slot']); ?>
                                                </span>
                                            </td>
                                            <td class="px-5 py-4 text-right space-x-2 whitespace-nowrap">
                                                <button type="button" onclick="populateScheduleEdit(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars($row['day'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($row['date'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($row['time_slot'], ENT_QUOTES); ?>')" class="inline-flex items-center gap-1 px-3 py-1.5 text-[11px] font-semibold text-[#F59E0B] bg-amber-50 hover:bg-amber-100 border border-amber-200/60 rounded-lg transition-all">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                    Edit 
                                                </button>
                                                <a href="Profile.php?delete_schedule=<?php echo $row['id']; ?>" onclick="return confirm('Confirm permanent removal of this clinical availability slot window?');" class="inline-flex items-center gap-1 px-3 py-1.5 text-[11px] font-semibold text-[#EF4444] bg-red-50 hover:bg-red-100 border border-red-200/60 rounded-lg transition-all">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                    Remove 
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </section>
            </div>
        </main>
    </div>

    <script>
        function toggleSidebarMenu() {
            const panel = document.getElementById('sidebar-panel');
            const backdrop = document.getElementById('sidebar-backdrop');
            if(panel.classList.contains('-translate-x-full')) {
                panel.classList.remove('-translate-x-full');
                backdrop.classList.remove('hidden');
            } else {
                panel.classList.add('-translate-x-full');
                backdrop.classList.add('hidden');
            }
        }

        function runLiveClock() {
            const el = document.getElementById('live-clock-timestamp');
            if(el) {
                const now = new Date();
                el.innerText = now.toTimeString().split(' ')[0];
            }
        }
        setInterval(runLiveClock, 1000); runLiveClock();

        function populateScheduleEdit(id, day, date, time) {
            document.getElementById('formTitle').innerText = "2. Adjust Existing Schedule Slot Matrix Row";
            document.getElementById('schedule_id').value = id;
            
            const dayDropdown = document.getElementById('sched_day');
            for(let i=0; i<dayDropdown.options.length; i++) {
                if(dayDropdown.options[i].value === day) {
                    dayDropdown.selectedIndex = i;
                    break;
                }
            }
            
            document.getElementById('sched_date').value = date;
            document.getElementById('sched_time').value = time;
            
            const submitBtn = document.getElementById('submitSchedBtn');
            submitBtn.name = "edit_schedule";
            submitBtn.innerHTML = "<i class='fa-solid fa-square-check'></i> <span>Save Slot Changes Matrix</span>";
            
            submitBtn.classList.remove('bg-[#1E293B]', 'hover:bg-slate-800');
            submitBtn.classList.add('bg-[#2563EB]', 'hover:bg-blue-700');
            
            document.getElementById('cancelEditBtn').classList.remove('hidden');
            document.getElementById('scheduleForm').scrollIntoView({ behavior: 'smooth' });
        }

        function resetScheduleForm() {
            document.getElementById('formTitle').innerText = "2. Publish Available Schedule Slot";
            document.getElementById('schedule_id').value = "";
            document.getElementById('sched_day').selectedIndex = 0;
            document.getElementById('sched_date').value = "";
            document.getElementById('sched_time').value = "";
            
            const submitBtn = document.getElementById('submitSchedBtn');
            submitBtn.name = "add_schedule";
            submitBtn.innerHTML = "<i class='fa-solid fa-circle-plus'></i> <span>Publish Active Slot</span>";
            
            submitBtn.classList.remove('bg-[#2563EB]', 'hover:bg-blue-700');
            submitBtn.classList.add('bg-[#1E293B]', 'hover:bg-slate-800');
            
            document.getElementById('cancelEditBtn').classList.add('hidden');
        }
    </script>
</body>
</html>