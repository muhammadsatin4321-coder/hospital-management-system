<?php
session_start();
include("../includes/conn.php");

// 1. Enforce authenticated Doctor identity session boundary context
if (!isset($_SESSION['doctor_id'])) {
    header("Location: login.php");
    exit();
}

$doctor_id = $_SESSION['doctor_id'];
$doctor_name = isset($_SESSION['doctor_name']) ? $_SESSION['doctor_name'] : "Specialist";

// 2. Safely capture and isolate search string variables
$search_query = "";
if (isset($_GET['search'])) {
    $search_query = trim($_GET['search']);
}

// 3. Dynamic Aggregation of Metric Statistics Counters via Prepared Statements
$stmt_tot = $conn->prepare("SELECT COUNT(*) as total FROM lab_report WHERE doctor_id = ?");
$stmt_tot->bind_param("s", $doctor_id);
$stmt_tot->execute();
$count_total = $stmt_tot->get_result()->fetch_assoc()['total'];
$stmt_tot->close();

$stmt_comp = $conn->prepare("SELECT COUNT(*) as total FROM lab_report WHERE doctor_id = ? AND (status='Final' OR status='Completed')");
$stmt_comp->bind_param("s", $doctor_id);
$stmt_comp->execute();
$count_completed = $stmt_comp->get_result()->fetch_assoc()['total'];
$stmt_comp->close();

$stmt_pend = $conn->prepare("SELECT COUNT(*) as total FROM lab_report WHERE doctor_id = ? AND status='Pending'");
$stmt_pend->bind_param("s", $doctor_id);
$stmt_pend->execute();
$count_pending = $stmt_pend->get_result()->fetch_assoc()['total'];
$stmt_pend->close();

$today_date = date('Y-m-d');
$stmt_tod = $conn->prepare("SELECT COUNT(*) as total FROM lab_report WHERE doctor_id = ? AND test_date = ?");
$stmt_tod->bind_param("ss", $doctor_id, $today_date);
$stmt_tod->execute();
$count_today = $stmt_tod->get_result()->fetch_assoc()['total'];
$stmt_tod->close();

// 4. Primary Data Ingestion Logic utilizing Prepared Statements
if (!empty($search_query)) {
    $sql = "SELECT report_id, patient_name, user_email, test_name, test_results, normal_range, test_date, status 
            FROM lab_report 
            WHERE doctor_id = ? 
            AND (patient_name LIKE ? OR user_email LIKE ? OR test_name LIKE ?) 
            ORDER BY report_id DESC";
    $stmt = $conn->prepare($sql);
    $search_param = "%" . $search_query . "%";
    $stmt->bind_param("ssss", $doctor_id, $search_param, $search_param, $search_param);
} else {
    $sql = "SELECT report_id, patient_name, user_email, test_name, test_results, normal_range, test_date, status 
            FROM lab_report 
            WHERE doctor_id = ? 
            ORDER BY report_id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $doctor_id);
}

$stmt->execute();
$result = $stmt->get_result();
$reports = [];
while ($row = $result->fetch_assoc()) {
    $reports[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise Pathology Control Matrix - MEDCORE</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    
    <script>
    tailwind.config = {
        theme:{
            extend:{
                colors:{
                    lightBg:'#F8FAFC',
                    cardWhite:'#FFFFFF',
                    brandBlue:'#2563EB',
                    brandSky:'#0EA5E9',
                    brandTeal:'#14B8A6',
                    successGreen:'#22C55E',
                    warningAmber:'#F59E0B',
                    dangerRed:'#EF4444',
                    slateText:'#1E293B',
                    borderGray:'#E2E8F0'
                },
                fontFamily:{
                    sans:['Inter','Plus Jakarta Sans','sans-serif']
                }
            }
        }
    }
    </script>
    
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;600;700&display=swap');

    ::-webkit-scrollbar{
        width:6px;
        height:6px;
    }

    ::-webkit-scrollbar-track{
        background:#F1F5F9;
    }

    ::-webkit-scrollbar-thumb{
        background:#CBD5E1;
        border-radius:4px;
    }

    .medical-canvas-underlay{
        position:absolute;
        top:0;
        left:0;
        right:0;
        height:450px;
        background:radial-gradient(circle at 15% 15%, rgba(37,99,237,0.04) 0%, transparent 65%);
        z-index:0;
        pointer-events:none;
    }

    .hover-lift{
        transition:transform .25s cubic-bezier(.34,1.56,.64,1),box-shadow .25s ease;
    }

    .hover-lift:hover{
        transform:translateY(-4px);
        box-shadow:0 16px 24px -8px rgba(37,99,237,.08);
    }

    .gradient-border-glow{
        position:relative;
        border-radius:1rem;
    }

    .gradient-border-glow::before{
        content:'';
        position:absolute;
        inset:-1px;
        border-radius:1rem;
        background:linear-gradient(135deg,#2563EB10,#0EA5E910,transparent);
        z-index:-1;
        pointer-events:none;
    }

    @media print{
        aside,
        header,
        form,
        .quick-actions-grid,
        .no-print,
        #printable-certificate-template button {
            display:none!important;
        }

        main{
            margin-left:0!important;
            width:100%!important;
            padding:0!important;
        }

        .print-full-card{
            border:none!important;
            box-shadow:none!important;
        }
        
        #printable-certificate-template {
            visibility: visible !important;
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            display: block !important;
            background: white !important;
            padding: 0 !important;
        }
        #printable-certificate-template * {
            visibility: visible !important;
        }
    }
    
    .slide-element { transition: opacity 0.6s ease-in-out; }
    </style>
</head>
<body class="min-h-full antialiased flex text-slateText bg-lightBg font-sans relative overflow-x-hidden selection:bg-brandBlue/10">

    <div class="medical-canvas-underlay"></div>

    <aside id="sidebar-panel" class="fixed inset-y-0 left-0 w-64 bg-cardWhite border-r border-borderGray p-6 flex flex-col justify-between z-50 -translate-x-full lg:translate-x-0 transition-all duration-300 ease-in-out shadow-sm no-print">
        <div class="space-y-8">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3 group cursor-pointer">
                    <div class="w-10 h-10 rounded-xl bg-brandBlue/10 flex items-center justify-center shadow-sm shrink-0 transition-transform duration-500 group-hover:rotate-[360deg]">
                        <i class="fa-solid fa-heart-pulse text-brandBlue text-lg"></i>
                    </div>
                    <h2 class="text-xl font-extrabold tracking-tight text-slateText uppercase">MED<span class="text-brandBlue">CORE</span></h2>
                </div>
                <button onclick="toggleSidebarMenu()" class="lg:hidden text-slate-400 hover:text-slate-600 p-1.5 hover:bg-lightBg rounded-xl transition-colors">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <nav class="space-y-1">
                <a href="index.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-chart-pie text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Dashboard Hub
                </a>
                <a href="lab_reports.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold bg-brandBlue text-white shadow-md shadow-brandBlue/20 transition-all duration-300">
                    <i class="fa-solid fa-flask-vial w-5 text-center text-white"></i> Lab Reports
                </a>
                <a href="medical_records.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-stethoscope text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Patients Record
                </a>
                <a href="appointments.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-calendar-check text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Appointments
                </a>
                <a href="Profile.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-user-doctor text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Profile
                </a>
            </nav>
        </div>

        <div class="border-t border-borderGray pt-4">
            <a href="logout.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-dangerRed hover:bg-dangerRed/5 transition-all duration-200 group">
                <i class="fa-solid fa-arrow-right-from-bracket group-hover:translate-x-1 transition-transform duration-200"></i> Sign Out
            </a>
        </div>
    </aside>

    <div id="sidebar-backdrop" onclick="toggleSidebarMenu()" class="fixed inset-0 bg-slateText/20 backdrop-blur-sm z-40 hidden lg:hidden transition-all duration-300 no-print"></div>

    <div class="flex-1 min-w-0 lg:pl-64 flex flex-col transition-all duration-300 z-10 relative">
        
        <header class="bg-cardWhite/90 px-4 sm:px-8 py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between sticky top-0 z-30 gap-4 border-b border-borderGray backdrop-blur-md no-print">
            <div class="flex items-center gap-3">
                <button onclick="toggleSidebarMenu()" class="lg:hidden p-2.5 border border-borderGray bg-cardWhite rounded-xl text-slateText hover:bg-lightBg transition-colors">
                    <i class="fa-solid fa-bars-staggered"></i>
                </button>
                <div>
                    <p class="text-[10px] font-bold text-brandBlue uppercase tracking-widest bg-brandBlue/10 px-2 py-0.5 rounded inline-block">MEDCORE · CLINICAL ANALYTICS</p>
                    <h1 class="text-xl font-bold text-slateText tracking-tight mt-0.5">Central Diagnostic Terminal</h1>
                </div>
            </div>
            
            <div class="flex items-center flex-wrap sm:flex-nowrap gap-3 w-full sm:w-auto justify-end">
                <div class="bg-cardWhite border border-borderGray px-3 py-2 rounded-xl flex items-center gap-2 text-xs font-bold text-slate-600 shadow-sm border-l-4 border-l-brandBlue">
                    <i class="fa-regular fa-clock text-brandBlue"></i>
                    <span id="live-clock-timestamp" class="text-slateText tabular-nums font-extrabold tracking-wide">00:00:00</span>
                    <span class="text-borderGray">|</span>
                    <span class="text-slate-400 font-medium"><?php echo date("M d, Y"); ?></span>
                </div>
                <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-brandBlue to-brandSky text-white font-bold flex items-center justify-center text-sm shadow-md shadow-brandBlue/10 transform hover:scale-105 transition-all duration-300">
                    <?php echo strtoupper(substr($doctor_name, 0, 1)); ?>
                </div>
            </div>
        </header>

        <main class="px-4 sm:px-8 py-6 space-y-6 flex-grow no-print">
            
            <section class="bg-gradient-to-r from-brandBlue/10 via-brandSky/5 to-cardWhite border border-brandBlue/10 rounded-2xl p-6 relative overflow-hidden shadow-sm hover-lift">
                <div class="space-y-2 max-w-2xl relative z-10">
                    <div>
                        <p class="text-[10px] font-bold uppercase tracking-wider text-brandBlue">Clinical Terminal Interface</p>
                        <h2 class="text-2xl font-black tracking-tight text-slateText mt-0.5">Welcome Back, Dr. <?php echo htmlspecialchars($doctor_name); ?></h2>
                    </div>
                    <p class="text-sm text-slate-500 leading-relaxed font-medium">
                        Access real-time patient diagnostic metrics charts, evaluate diagnostic log trends, and compile pathology laboratory verification certificates cleanly.
                    </p>
                </div>
            </section>

            <section class="relative w-full overflow-hidden rounded-2xl bg-slateText border border-borderGray shadow-sm group" id="heroAutoSlider" onmouseenter="pauseSlider()" onmouseleave="resumeSlider()">
                <div class="relative h-[200px] md:h-[240px] w-full overflow-hidden">
                    <div class="slide-element absolute inset-0 opacity-100 transition-opacity duration-700 ease-in-out flex items-center bg-cover bg-center" style="background-image: linear-gradient(to right, #1E293B 40%, rgba(30,41,59,0.6)), url('https://images.unsplash.com/photo-1579165466511-71e5d4b85c6b?q=80&w=1200&auto=format&fit=crop');">
                        <div class="p-6 md:p-10 max-w-xl space-y-2 z-10 text-white">
                            <span class="text-[9px] font-extrabold tracking-widest text-brandSky uppercase bg-white/10 px-2 py-0.5 rounded border border-white/10">Facility Core</span>
                            <h3 class="text-lg md:text-2xl font-black tracking-tight text-white">Advanced Pathology Laboratory</h3>
                            <p class="text-xs text-slate-300 font-medium">Delivering ultra-fast, clinical-grade diagnostic reports backed by accuracy matrices.</p>
                        </div>
                    </div>
                    <div class="slide-element absolute inset-0 opacity-0 transition-opacity duration-700 ease-in-out flex items-center bg-cover bg-center" style="background-image: linear-gradient(to right, #2563EB 40%, rgba(37,99,237,0.6)), url('https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=1200&auto=format&fit=crop');">
                        <div class="p-6 md:p-10 max-w-xl space-y-2 z-10 text-white">
                            <span class="text-[9px] font-extrabold tracking-widest text-brandSky uppercase bg-white/10 px-2 py-0.5 rounded border border-white/10">Next-Gen Systems</span>
                            <h3 class="text-lg md:text-2xl font-black tracking-tight text-white">Digital Healthcare Ecosystem</h3>
                            <p class="text-xs text-slate-200 font-medium">AI-powered hospital asset workflows optimizing scheduling and diagnosis accuracy data layers.</p>
                        </div>
                    </div>
                </div>
                <button onclick="shiftSlide(-1)" class="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/40 text-white hover:bg-brandBlue rounded-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md cursor-pointer"><i class="fa-solid fa-chevron-left text-xs"></i></button>
                <button onclick="shiftSlide(1)" class="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/40 text-white hover:bg-brandBlue rounded-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md cursor-pointer"><i class="fa-solid fa-chevron-right text-xs"></i></button>
                <div class="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5" id="slider-dots-container">
                    <span onclick="jumpToSlide(0)" class="w-5 h-1 bg-brandSky rounded-full cursor-pointer transition-all slider-dot"></span>
                    <span onclick="jumpToSlide(1)" class="w-1.5 h-1 bg-white/50 rounded-full cursor-pointer transition-all slider-dot"></span>
                </div>
            </section>

            <section class="grid grid-cols-2 lg:grid-cols-4 gap-5">
                <div class="bg-cardWhite border border-borderGray p-5 rounded-2xl shadow-sm relative flex items-center justify-between hover-lift border-b-4 border-b-brandBlue">
                    <div>
                        <p class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Logs</p>
                        <h3 class="text-3xl font-extrabold text-slateText mt-1 counter-item tracking-tight" data-target="<?php echo $count_total; ?>">0</h3>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-brandBlue/10 text-brandBlue flex items-center justify-center shrink-0 shadow-inner text-base">
                        <i class="fa-solid fa-chart-simple"></i>
                    </div>
                </div>
                <div class="bg-cardWhite border border-borderGray p-5 rounded-2xl shadow-sm relative flex items-center justify-between hover-lift border-b-4 border-b-successGreen">
                    <div>
                        <p class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Verified Files</p>
                        <h3 class="text-3xl font-extrabold text-slateText mt-1 counter-item tracking-tight" data-target="<?php echo $count_completed; ?>">0</h3>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-successGreen/10 text-successGreen flex items-center justify-center shrink-0 shadow-inner text-base">
                        <i class="fa-solid fa-shield-medical"></i>
                    </div>
                </div>
                <div class="bg-cardWhite border border-borderGray p-5 rounded-2xl shadow-sm relative flex items-center justify-between hover-lift border-b-4 border-b-warningAmber">
                    <div>
                        <p class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Pending Charts</p>
                        <h3 class="text-3xl font-extrabold text-slateText mt-1 counter-item tracking-tight" data-target="<?php echo $count_pending; ?>">0</h3>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-warningAmber/10 text-warningAmber flex items-center justify-center shrink-0 shadow-inner text-base">
                        <i class="fa-regular fa-clock"></i>
                    </div>
                </div>
                <div class="bg-cardWhite border border-borderGray p-5 rounded-2xl shadow-sm relative flex items-center justify-between hover-lift border-b-4 border-b-brandSky">
                    <div>
                        <p class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Today's Inflow</p>
                        <h3 class="text-3xl font-extrabold text-slateText mt-1 counter-item tracking-tight" data-target="<?php echo $count_today; ?>">0</h3>
                    </div>
                    <div class="w-12 h-12 rounded-xl bg-brandSky/10 text-brandSky flex items-center justify-center shrink-0 shadow-inner text-base">
                        <i class="fa-solid fa-bolt"></i>
                    </div>
                </div>
            </section>

            <section id="reports-table-view" class="bg-cardWhite border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover-lift">
                <div>
                    <h3 class="text-xs font-bold uppercase text-slateText tracking-wide">Pathology Registry Index</h3>
                    <p class="text-xs text-slate-400 mt-0.5 font-semibold">Filter records by identifier labels or testing module classifications</p>
                </div>
                <form method="GET" action="lab_reports.php" class="flex items-stretch gap-2 w-full sm:max-w-md relative">
                    <div class="relative w-full group">
                        <span class="absolute inset-y-0 left-3.5 flex items-center text-slate-400 group-focus-within:text-brandBlue transition-colors">
                            <i class="fa-solid fa-magnifying-glass text-xs"></i>
                        </span>
                        <input type="text" name="search" value="<?php echo htmlspecialchars($search_query, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search patient demographics or metrics..." class="w-full bg-lightBg border border-borderGray focus:border-brandBlue focus:bg-cardWhite rounded-xl pl-9 pr-4 py-2.5 text-xs font-semibold text-slateText outline-none transition-all shadow-inner">
                    </div>
                    <?php if (!empty($search_query)): ?>
                        <a href="lab_reports.php" class="px-3 bg-lightBg border border-borderGray text-slate-500 font-bold text-xs rounded-xl flex items-center justify-center hover:bg-borderGray transition-colors">Clear</a>
                    <?php endif; ?>
                    <button type="submit" class="px-5 py-2.5 bg-slateText hover:bg-slateText/90 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow shrink-0 cursor-pointer">Filter</button>
                </form>
            </section>

            <section class="bg-cardWhite border border-borderGray rounded-2xl shadow-sm overflow-hidden print-full-card">
                <div class="overflow-x-auto">
                    <table class="w-full border-collapse text-left">
                        <thead>
                            <tr class="bg-slateText border-b border-slateText text-[10px] font-bold uppercase tracking-wider text-white">
                                <th class="px-6 py-4"><i class="fa-solid fa-hashtag mr-1"></i> Report Reference</th>
                                <th class="px-6 py-4"><i class="fa-regular fa-user mr-1"></i> Patient Demographics</th>
                                <th class="px-6 py-4"><i class="fa-solid fa-vials mr-1"></i> Test Classification</th>
                                <th class="px-6 py-4"><i class="fa-solid fa-square-poll-vertical mr-1"></i> Observed Results</th>
                                <th class="px-6 py-4"><i class="fa-solid fa-arrow-up-right-dots mr-1"></i> Reference Intervals</th>
                                <th class="px-6 py-4 text-center"><i class="fa-solid fa-flag mr-1"></i> Status Flag</th>
                                <th class="px-6 py-4 text-center"><i class="fa-solid fa-file-export mr-1"></i> Export Axis</th>
                            </tr>
                        </thead>
                        <tbody class="text-xs divide-y divide-borderGray font-medium text-slate-500 bg-cardWhite">
                            <?php if (empty($reports)): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-16 text-xs font-bold text-slate-400 italic bg-lightBg/50">
                                        <div class="flex flex-col items-center justify-center gap-3">
                                            <i class="fa-regular fa-folder-open text-4xl text-slate-300"></i>
                                            <span>No matching pathology records discovered in registry node.</span>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: $idx = 0; foreach ($reports as $report): $idx++; ?>
                                <tr class="<?php echo ($idx % 2 === 0) ? 'bg-lightBg/30' : 'bg-cardWhite'; ?> hover:bg-lightBg/50 group transition-all duration-150">
                                    <td class="px-6 py-4 font-mono font-bold text-brandBlue">#LAB-<?php echo htmlspecialchars($report['report_id'], ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td class="px-6 py-4">
                                        <div class="font-bold text-slateText text-sm tracking-tight group-hover:text-brandBlue transition-colors"><?php echo htmlspecialchars($report['patient_name'], ENT_QUOTES, 'UTF-8'); ?></div>
                                        <div class="text-[10px] font-mono text-slate-400 mt-0.5"><?php echo htmlspecialchars($report['user_email'], ENT_QUOTES, 'UTF-8'); ?></div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="font-bold text-slateText text-sm"><?php echo htmlspecialchars($report['test_name'], ENT_QUOTES, 'UTF-8'); ?></div>
                                        <div class="text-[10px] text-brandBlue font-bold mt-1 inline-flex items-center gap-1 bg-brandBlue/5 px-2 py-0.5 rounded border border-brandBlue/10">
                                            <i class="fa-regular fa-calendar text-[9px]"></i> <?php echo htmlspecialchars($report['test_date'] ? date("Y-m-d", strtotime($report['test_date'])) : 'N/A', ENT_QUOTES, 'UTF-8'); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 max-w-[220px]">
                                        <div class="bg-lightBg border border-borderGray rounded-xl p-3 font-mono text-[11px] text-slateText max-h-[90px] overflow-y-auto whitespace-pre-line leading-relaxed shadow-inner">
                                            <?php echo htmlspecialchars($report['test_results'], ENT_QUOTES, 'UTF-8'); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 font-mono text-slate-600 font-bold text-xs"><?php echo htmlspecialchars($report['normal_range'], ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td class="px-6 py-4 text-center">
                                        <?php if (trim($report['status']) === 'Final' || trim($report['status']) === 'Completed'): ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 bg-successGreen/10 border border-successGreen/20 text-successGreen text-[10px] font-extrabold rounded-xl uppercase tracking-wider">Verified ✓</span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 bg-warningAmber/10 border border-warningAmber/20 text-warningAmber text-[10px] font-extrabold rounded-xl uppercase tracking-wider animate-pulse">Pending ⏳</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <button onclick='compileCertificatePdf(<?php echo json_encode($report, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' class="px-4 py-2 bg-gradient-to-r from-brandBlue to-brandSky text-white font-bold text-xs tracking-wide uppercase rounded-xl hover:opacity-95 shadow-md shadow-brandBlue/20 hover:scale-[1.02] transform transition-all active:scale-95 cursor-pointer">
                                            <i class="fa-solid fa-print mr-1"></i> Certificate PDF
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="px-6 py-4 bg-lightBg border-t border-borderGray text-xs font-semibold text-slate-400 flex justify-between items-center">
                    <span>Matrix Grid Status Count: Displayed <?php echo count($reports); ?> active result rows.</span>
                    <span class="text-[10px] tracking-wider uppercase font-bold text-brandBlue bg-brandBlue/10 px-2.5 py-0.5 rounded-md border border-brandBlue/20">Live Sync Authorized</span>
                </div>
            </section>
        </main>
    </div>

    <div id="printable-certificate-template" class="hidden p-16 bg-cardWhite text-slateText">
        <div class="max-w-4xl mx-auto border-4 border-slateText p-10 rounded-2xl relative bg-cardWhite space-y-8">
            <div class="absolute inset-0 flex items-center justify-center opacity-[0.03] select-none pointer-events-none z-0">
                <span class="text-8xl font-black tracking-widest text-brandBlue uppercase rotate-12">MEDCORE LABS</span>
            </div>
            <div class="relative z-10 space-y-6">
                <div class="flex justify-between items-start border-b-4 border-slateText pb-4">
                    <div>
                        <h1 class="text-xl font-black tracking-tighter text-slateText uppercase">MEDCORE DIAGNOSTIC LABORATORIES</h1>
                        <p class="text-[9px] font-mono tracking-widest text-slate-400 uppercase">ACCREDITED PATHOLOGY CLINIC CORE ENGINE</p>
                    </div>
                    <div class="bg-slateText text-white font-bold px-3 py-1.5 text-xs rounded-lg tracking-wider" id="cert-id-badge">#LAB-0000</div>
                </div>
                <div class="grid grid-cols-2 gap-4 text-xs">
                    <div class="border border-borderGray p-3 rounded-xl bg-lightBg/50">
                        <p class="text-[8px] uppercase font-black text-slate-400">Patient</p>
                        <p class="font-black text-sm text-slateText" id="cert-patient-name">--</p>
                        <p class="font-mono text-[11px]" id="cert-patient-email">--</p>
                    </div>
                    <div class="border border-borderGray p-3 rounded-xl bg-lightBg/50 text-right">
                        <p class="text-[8px] uppercase font-black text-slate-400">Physician Officer</p>
                        <p class="font-black text-sm text-slateText">Dr. <?php echo htmlspecialchars($doctor_name); ?></p>
                        <p class="font-mono text-[11px]">ID Reference: #<?php echo htmlspecialchars($doctor_id); ?></p>
                    </div>
                </div>
                <table class="w-full text-left text-xs border border-borderGray rounded-xl overflow-hidden">
                    <thead>
                        <tr class="bg-slateText text-white font-extrabold uppercase text-[9px] tracking-wider">
                            <th class="p-2.5">Test Modality</th>
                            <th class="p-2.5">Observed Findings</th>
                            <th class="p-2.5">Reference Ranges</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="bg-cardWhite">
                            <td class="p-3 font-black text-brandBlue text-xs" id="cert-test-name">--</td>
                            <td class="p-3 font-mono text-slateText bg-lightBg/30 text-xs whitespace-pre-line" id="cert-test-results">--</td>
                            <td class="p-3 font-mono text-slate-600 font-bold" id="cert-normal-range">--</td>
                        </tr>
                    </tbody>
                </table>
                <div class="grid grid-cols-3 gap-4 items-center pt-6 border-t border-borderGray">
                    <div class="font-mono text-[8px] border border-borderGray p-2 w-16 h-16 text-center flex flex-col items-center justify-center">🔳<br>SECURE</div>
                    <div class="text-center font-mono text-[10px] tracking-[4px] text-slate-400">||||| | |||| || || | ||<p class="tracking-normal text-[7px] text-slate-400 mt-0.5">SYS-TOKEN-VAL-2026</p></div>
                    <div class="text-center border-t border-slateText font-serif italic text-sm font-bold text-slateText pt-1">Dr. <?php echo htmlspecialchars($doctor_name); ?><p class="font-sans font-black text-[8px] uppercase text-slate-400 tracking-wider mt-0.5">Authorized Signature</p></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleSidebarMenu() {
            const panel = document.getElementById('sidebar-panel');
            const backdrop = document.getElementById('sidebar-backdrop');
            if(panel.classList.contains('-translate-x-full')) {
                panel.classList.remove('-translate-x-full');
                backdrop.classList.remove('hidden');
            } else {
                panel.classList.add('-translate-x-full');
                backdrop.classList.add('hidden');
            }
        }

        function runLiveClock() {
            const el = document.getElementById('live-clock-timestamp');
            if(el) {
                const now = new Date();
                el.innerText = now.toTimeString().split(' ')[0];
            }
        }
        setInterval(runLiveClock, 1000); runLiveClock();

        document.addEventListener("DOMContentLoaded", () => {
            document.querySelectorAll('.counter-item').forEach(c => {
                const tgt = +c.getAttribute('data-target');
                if (tgt === 0) { c.innerText = '0'; return; }
                let curr = 0; const step = tgt / 20;
                const up = () => { curr += step; if(curr < tgt) { c.innerText = Math.floor(curr); requestAnimationFrame(up); } else { c.innerText = tgt; } };
                up();
            });
        });

        // Carousel Automation Drivers
        let currentSlideIdx = 0, sliderTimerInterval = null;
        const slides = document.querySelectorAll('.slide-element'), dots = document.querySelectorAll('.slider-dot');
        function renderActiveSlide(idx) {
            if(!slides.length) return;
            if(idx >= slides.length) currentSlideIdx = 0;
            else if(idx < 0) currentSlideIdx = slides.length - 1;
            else currentSlideIdx = idx;
            slides.forEach((s, i) => { s.classList.toggle('opacity-100', i === currentSlideIdx); s.classList.toggle('opacity-0', i !== currentSlideIdx); s.classList.toggle('z-10', i === currentSlideIdx); });
            dots.forEach((d, i) => { d.className = i === currentSlideIdx ? "w-5 h-1 bg-brandSky rounded-full cursor-pointer transition-all slider-dot" : "w-1.5 h-1 bg-white/50 rounded-full cursor-pointer transition-all slider-dot"; });
        }
        function shiftSlide(o) { renderActiveSlide(currentSlideIdx + o); }
        function jumpToSlide(i) { renderActiveSlide(i); }
        function initSliderCycle() { if(!sliderTimerInterval) sliderTimerInterval = setInterval(() => shiftSlide(1), 4000); }
        function pauseSlider() { clearInterval(sliderTimerInterval); sliderTimerInterval = null; }
        function resumeSlider() { initSliderCycle(); }
        initSliderCycle();

        function compileCertificatePdf(data) {
            if(!data) return;
            document.getElementById('cert-id-badge').innerText = "#LAB-" + (data.report_id || '0000');
            document.getElementById('cert-patient-name').innerText = data.patient_name || 'N/A';
            document.getElementById('cert-patient-email').innerText = data.user_email || 'N/A';
            document.getElementById('cert-test-name').innerText = data.test_name || 'N/A';
            document.getElementById('cert-test-results').innerText = data.test_results || 'N/A';
            document.getElementById('cert-normal-range').innerText = data.normal_range || 'N/A';
            const f = document.getElementById('printable-certificate-template');
            f.classList.remove('hidden'); window.print(); f.classList.add('hidden');
        }
    </script>
</body>
</html>