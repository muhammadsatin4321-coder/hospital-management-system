<?php
session_start();
include("../includes/conn.php");

// Strict MySQLi reporting for robust error tracing
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// 1. Doctor Session Protection Layer Context
if (!isset($_SESSION['doctor_id'])) {
    header("Location: login.php");
    exit();
}

// Generate Anti-CSRF Token if not present
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$doctor_id = $_SESSION['doctor_id'];
$doctor_name = isset($_SESSION['doctor_name']) ? $_SESSION['doctor_name'] : "Specialist";
$message = "";
$message_type = "success"; // success or error

// --- MODULE A: STREAMED PDF DOWNLOAD DISPATCHER ---
if (isset($_GET['download_pdf'])) {
    $record_id = intval($_GET['download_pdf']);
    
    $pdf_stmt = $conn->prepare("SELECT r.*, p.name AS patient_name, p.email, p.phone 
                                FROM medical_records r 
                                JOIN patients p ON r.patient_id = p.id 
                                WHERE r.id = ? AND r.doctor_id = ?");
    $pdf_stmt->bind_param("is", $record_id, $doctor_id);
    $pdf_stmt->execute();
    $r_data = $pdf_stmt->get_result()->fetch_assoc();
    $pdf_stmt->close();
    
    if ($r_data) {
        require_once dirname(__DIR__) . '/fpdf/fpdf.php';
        
        $pdf = new FPDF('P', 'mm', 'A4');
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);
        
        $pdf->Cell(0, 10, 'MEDCORE MEDICAL RECORD CERTIFICATE', 0, 1, 'C');
        $pdf->Ln(5);
        $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
        $pdf->Ln(10);
        
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(50, 8, 'Record Reference ID:', 0, 0);
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(0, 8, '#REC-' . $r_data['id'], 0, 1);
        
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(50, 8, 'Patient Full Name:', 0, 0);
        $pdf->SetFont('Arial', '', 12);
        $patient_name_encoded = iconv('UTF-8', 'windows-1252//TRANSLIT', $r_data['patient_name'] ?? 'Authorized Patient Profile');
        $pdf->Cell(0, 8, $patient_name_encoded, 0, 1);
        
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(50, 8, 'Email Identifier:', 0, 0);
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(0, 8, htmlspecialchars($r_data['email'] ?? ''), 0, 1);
        
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(50, 8, 'Archived Date:', 0, 0);
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(0, 8, date("M d, Y - H:i", strtotime($r_data['created_at'])), 0, 1);
        
        $pdf->Ln(5);
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 8, 'Diagnosed Pathological Assessment:', 0, 1);
        $pdf->SetFont('Arial', 'B', 11);
        $diagnosis_encoded = iconv('UTF-8', 'windows-1252//TRANSLIT', $r_data['diagnosis'] ?? '');
        $pdf->MultiCell(0, 6, $diagnosis_encoded, 1, 'L');
        
        $pdf->Ln(5);
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 8, 'Prescribed Therapeutics & Treatments Protocol:', 0, 1);
        $pdf->SetFont('Arial', '', 11);
        $treatment_encoded = iconv('UTF-8', 'windows-1252//TRANSLIT', $r_data['treatment'] ?? '');
        $pdf->MultiCell(0, 6, $treatment_encoded, 1, 'L');
        
        $pdf->Ln(5);
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 8, 'Clinical Findings & Presenting Symptoms:', 0, 1);
        $pdf->SetFont('Arial', '', 11);
        $notes_encoded = iconv('UTF-8', 'windows-1252//TRANSLIT', $r_data['notes'] ?? '');
        $pdf->MultiCell(0, 6, $notes_encoded, 1, 'L');
        
        $pdf->Ln(20);
        $pdf->SetFont('Arial', 'I', 10);
        $pdf->Cell(0, 10, 'Generated electronically via authorized practitioner verification terminal.', 0, 1, 'C');
        
        $pdf->Output('I', 'Medical_Record_' . $r_data['id'] . '.pdf');
        exit();
    }
}

// Determine Context (Global List vs Specific Appointment Dashboard Node)
$is_appointment_context = isset($_GET['appointment_id']);
$appointment_id = $is_appointment_context ? intval($_GET['appointment_id']) : 0;

// Catch Incoming Notification Messaging From Redirects
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message'], ENT_QUOTES, 'UTF-8');
    if (isset($_GET['msg_type'])) {
        $message_type = htmlspecialchars($_GET['msg_type'], ENT_QUOTES, 'UTF-8');
    }
}

if ($is_appointment_context) {
    // --- WORKFLOW: APPOINTMENT MODE ---
    $app_stmt = $conn->prepare("SELECT a.*, p.id AS calculated_patient_id, p.name AS patient_name 
                                FROM appointment a 
                                LEFT JOIN patients p ON a.user_email = p.email 
                                WHERE a.id = ? AND a.doctor_id = ?");
    $app_stmt->bind_param("is", $appointment_id, $doctor_id);
    $app_stmt->execute();
    $appointment = $app_stmt->get_result()->fetch_assoc();
    $app_stmt->close();

    if (!$appointment) {
        die("Access Denied: The specific appointment channel is either non-existent or restricted.");
    }

    $patient_id = $appointment['calculated_patient_id'];
    $patient_email = $appointment['user_email'];

    // Handle Direct Clinical Record Deletion Requests with Anti-CSRF Token Validation
    if (isset($_GET['delete_record'])) {
        if (!isset($_GET['token']) || !hash_equals($_SESSION['csrf_token'], $_GET['token'])) {
            die("CSRF Security Validation Failed.");
        }
        $del_rec_id = intval($_GET['delete_record']);
        $del_stmt = $conn->prepare("DELETE FROM medical_records WHERE id = ? AND doctor_id = ?");
        $del_stmt->bind_param("is", $del_rec_id, $doctor_id);
        if ($del_stmt->execute()) {
            $message = "Target record successfully removed from permanent clinical archives.";
            $message_type = "success";
        }
        $del_stmt->close();
        header("Location: medical_records.php?appointment_id=" . $appointment_id . "&message=" . urlencode($message) . "&msg_type=" . $message_type);
        exit();
    }

    // Determine if we are operating in Form Editing context state
    $edit_mode = false;
    $edit_data = [
        'diagnosis' => '', 'treatment' => '', 'id' => 0,
        'prescription' => '', 'blood_pressure' => '', 'weight_kg' => '', 
        'temperature_c' => '', 'notes' => '', 'visit_date' => date('Y-m-d')
    ];

    if (isset($_GET['edit_record'])) {
        $edit_rec_id = intval($_GET['edit_record']);
        $ed_stmt = $conn->prepare("SELECT * FROM medical_records WHERE id = ? AND doctor_id = ?");
        $ed_stmt->bind_param("is", $edit_rec_id, $doctor_id);
        $ed_stmt->execute();
        $found = $ed_stmt->get_result()->fetch_assoc();
        $ed_stmt->close();
        
        if ($found) {
            $edit_mode = true;
            $edit_data = array_merge($edit_data, $found);
        }
    }

    // FORM SUBMISSION PIPELINE - FIXED DOCTOR_ID SAVING LAYER & CSRF VALIDATION
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['persist_clinical_record'])) {
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            die("CSRF Security Validation Failed.");
        }

        $in_symptoms       = isset($_POST['symptoms']) ? trim($_POST['symptoms']) : '';
        $in_diagnosis      = trim($_POST['diagnosis']);
        $in_treatment      = trim($_POST['treatment']);
        $in_prescription   = trim($_POST['prescription']);
        $in_blood_pressure = trim($_POST['blood_pressure']);
        $in_weight_kg      = trim($_POST['weight_kg']);
        $in_temperature_c  = trim($_POST['temperature_c']);
        $in_provided_notes = trim($_POST['notes']);
        $in_visit_date     = trim($_POST['visit_date']);
        
        $in_notes = $in_provided_notes;
        if (!empty($in_symptoms)) {
            $in_notes = "Symptoms: " . $in_symptoms . ($in_provided_notes ? " | Notes: " . $in_provided_notes : "");
        }
        
        if (empty($in_diagnosis) || empty($in_treatment)) {
            $message = "Error: Diagnosis and Treatment fields are required.";
            $message_type = "error";
        } else {
            if ($edit_mode) {
                // Update mode logic
                $up_stmt = $conn->prepare("UPDATE medical_records SET diagnosis = ?, treatment = ?, prescription = ?, blood_pressure = ?, weight_kg = ?, temperature_c = ?, notes = ?, visit_date = ? WHERE id = ? AND doctor_id = ?");
                $up_stmt->bind_param("ssssssssis", $in_diagnosis, $in_treatment, $in_prescription, $in_blood_pressure, $in_weight_kg, $in_temperature_c, $in_notes, $in_visit_date, $edit_data['id'], $doctor_id);
                if ($up_stmt->execute()) {
                    $message = "Record modifications securely saved.";
                    $message_type = "success";
                }
                $up_stmt->close();
            } else {
                // Patient registration fallback setup
                if (!$patient_id) {
                    $stub_name = strstr($patient_email, '@', true) ?: $patient_email;
                    $p_stmt = $conn->prepare("INSERT INTO patients (name, email, phone) VALUES (?, ?, '000-000-0000')");
                    $p_stmt->bind_param("ss", $stub_name, $patient_email);
                    $p_stmt->execute();
                    $patient_id = $conn->insert_id;
                    $p_stmt->close();
                }
                
                // STRICT ENFORCEMENT: Enforcing explicit data parsing configuration
                $ins_stmt = $conn->prepare("INSERT INTO medical_records (patient_id, doctor_id, diagnosis, treatment, prescription, blood_pressure, weight_kg, temperature_c, notes, visit_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                
                // Explicit type assignment protection logic
                $ins_stmt->bind_param(
                    "isssssssss", 
                    $patient_id, 
                    $doctor_id, 
                    $in_diagnosis, 
                    $in_treatment, 
                    $in_prescription, 
                    $in_blood_pressure, 
                    $in_weight_kg, 
                    $in_temperature_c, 
                    $in_notes, 
                    $in_visit_date
                );
                
                if ($ins_stmt->execute()) {
                    $message = "New historical record row committed successfully with Doctor ID linking.";
                    $message_type = "success";
                    
                    $st_stmt = $conn->prepare("UPDATE appointment SET status = 'Completed' WHERE id = ?");
                    $st_stmt->bind_param("i", $appointment_id);
                    $st_stmt->execute();
                    $st_stmt->close();
                }
                $ins_stmt->close();
            }
            header("Location: medical_records.php?appointment_id=" . $appointment_id . "&message=" . urlencode($message) . "&msg_type=" . $message_type);
            exit();
        }
    }

    // Fetch historical records bound to this patient profile object configuration
    $history_records = [];
    if ($patient_id) {
        $h_stmt = $conn->prepare("SELECT * FROM medical_records WHERE patient_id = ? ORDER BY created_at DESC");
        $h_stmt->bind_param("i", $patient_id);
        $h_stmt->execute();
        $h_res = $h_stmt->get_result();
        while ($h_row = $h_res->fetch_assoc()) {
            $history_records[] = $h_row;
        }
        $h_stmt->close();
    }
} else {
    // --- WORKFLOW: GLOBAL MATRIX ARCHIVE MODE ---
    if (isset($_GET['delete_id'])) {
        if (!isset($_GET['token']) || !hash_equals($_SESSION['csrf_token'], $_GET['token'])) {
            die("CSRF Security Validation Failed.");
        }
        $delete_id = intval($_GET['delete_id']);
        
        $stmt = $conn->prepare("DELETE FROM medical_records WHERE id = ? AND doctor_id = ?");
        $stmt->bind_param("is", $delete_id, $doctor_id);
        
        if ($stmt->execute()) {
            $message = "Record successfully removed from the database archives.";
            $message_type = "success";
        } else {
            $message = "Error purging target database ledger entry.";
            $message_type = "error";
        }
        $stmt->close();
        
        header("Location: medical_records.php?message=" . urlencode($message) . "&msg_type=" . $message_type);
        exit();
    }

    $search = isset($_GET['search']) ? trim($_GET['search']) : '';

    if ($search !== '') {
        $query = "SELECT mr.*, a.id AS appointment_id, a.patient_name
                  FROM medical_records mr
                  LEFT JOIN appointment a
                      ON mr.patient_id = (SELECT p.id FROM patients p WHERE p.email = a.user_email LIMIT 1)
                      AND a.doctor_id = mr.doctor_id
                  WHERE mr.doctor_id = ? 
                    AND (a.patient_name LIKE ? OR mr.diagnosis LIKE ? OR mr.treatment LIKE ?)
                  GROUP BY mr.id
                  ORDER BY mr.created_at DESC";
                  
        $stmt = $conn->prepare($query);
        $like_search = "%$search%";
        $stmt->bind_param("ssss", $doctor_id, $like_search, $like_search, $like_search);
    } else {
        $query = "SELECT mr.*, a.id AS appointment_id, a.patient_name
                  FROM medical_records mr
                  LEFT JOIN appointment a
                      ON mr.patient_id = (SELECT p.id FROM patients p WHERE p.email = a.user_email LIMIT 1)
                      AND a.doctor_id = mr.doctor_id
                  WHERE mr.doctor_id = ?
                  GROUP BY mr.id
                  ORDER BY mr.created_at DESC";
                  
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $doctor_id);
    }

    $stmt->execute();
    $records = $stmt->get_result();
    $count_records = $records->num_rows;
}
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-[#F8FAFC]">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinical Records Portal - MEDCORE</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    
    <script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    lightBg: '#F8FAFC',
                    cardWhite: '#FFFFFF',
                    brandBlue: '#2563EB',
                    brandSky: '#0EA5E9',
                    brandTeal: '#14B8A6',
                    successGreen: '#22C55E',
                    warningAmber: '#F59E0B',
                    dangerRed: '#EF4444',
                    slateText: '#1E293B',
                    borderGray: '#E2E8F0'
                },
                fontFamily: {
                    sans: ['Inter', 'Plus Jakarta Sans', 'sans-serif']
                }
            }
        }
    }
    </script>
    
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;600;700&display=swap');

    ::-webkit-scrollbar {
        width: 6px;
        height: 6px;
    }

    ::-webkit-scrollbar-track {
        background: #F1F5F9;
    }

    ::-webkit-scrollbar-thumb {
        background: #CBD5E1;
        border-radius: 4px;
    }

    .medical-canvas-underlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 450px;
        background: radial-gradient(circle at 15% 15%, rgba(37,99,237,0.04) 0%, transparent 65%);
        z-index: 0;
        pointer-events: none;
    }

    .hover-lift {
        transition: transform .25s cubic-bezier(.34,1.56,.64,1), box-shadow .25s ease;
    }

    .hover-lift:hover {
        transform: translateY(-4px);
        box-shadow: 0 16px 24px -8px rgba(37,99,237,.08);
    }

    .gradient-border-glow {
        position: relative;
        border-radius: 1rem;
    }

    .gradient-border-glow::before {
        content: '';
        position: absolute;
        inset: -1px;
        border-radius: 1rem;
        background: linear-gradient(135deg, #2563EB10, #0EA5E910, transparent);
        z-index: -1;
        pointer-events: none;
    }

    @media print {
        aside, header, form, .quick-actions-grid, .no-print {
            display: none !important;
        }

        main {
            margin-left: 0 !important;
            width: 100 !important;
            padding: 0 !important;
        }

        .print-full-card {
            border: none !important;
            box-shadow: none !important;
        }
    }
    </style>
</head>
<body class="min-h-full antialiased flex text-slateText bg-lightBg font-sans relative overflow-x-hidden selection:bg-brandBlue/10">

    <div class="medical-canvas-underlay"></div>

    <aside id="sidebar-panel" class="fixed inset-y-0 left-0 w-64 bg-cardWhite border-r border-borderGray p-6 flex flex-col justify-between z-50 -translate-x-full lg:translate-x-0 transition-all duration-300 ease-in-out shadow-sm no-print">
        <div class="space-y-8">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3 group cursor-pointer">
                    <div class="w-10 h-10 rounded-xl bg-brandBlue/10 flex items-center justify-center shadow-sm shrink-0 transition-transform duration-500 group-hover:rotate-[360deg]">
                        <i class="fa-solid fa-heart-pulse text-brandBlue text-lg"></i>
                    </div>
                    <h2 class="text-xl font-extrabold tracking-tight text-slateText uppercase">MED<span class="text-brandSky">CORE</span></h2>
                </div>
                <button onclick="toggleSidebarMenu()" class="lg:hidden text-slate-400 hover:text-slate-600 p-1.5 hover:bg-lightBg rounded-xl transition-colors">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <nav class="space-y-1">
                <a href="index.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-chart-pie text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Dashboard Hub
                </a>
                <a href="lab_reports.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-flask text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Lab Reports
                </a>
                <a href="medical_records.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold bg-brandBlue text-white shadow-md shadow-brandBlue/20 transition-all duration-300">
                    <i class="fa-solid fa-stethoscope w-5 text-center text-white"></i> Patients Record
                </a>
                <a href="appointments.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-calendar-check text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Appointments
                </a>
                <a href="Profile.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-500 hover:bg-brandBlue/5 hover:text-brandBlue transition-all duration-200 group">
                    <i class="fa-solid fa-user text-slate-400 group-hover:text-brandBlue w-5 text-center transition-transform duration-300 group-hover:scale-110"></i> Profile
                </a>
            </nav>
        </div>

        <div class="border-t border-borderGray pt-4">
            <a href="logout.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-dangerRed hover:bg-dangerRed/5 transition-all duration-200 group">
                <i class="fa-solid fa-arrow-right-from-bracket group-hover:translate-x-1 transition-transform duration-200"></i> Sign Out
            </a>
        </div>
    </aside>

    <div id="sidebar-backdrop" onclick="toggleSidebarMenu()" class="fixed inset-0 bg-slateText/20 backdrop-blur-sm z-40 hidden lg:hidden transition-all duration-300 no-print"></div>

    <div class="flex-1 min-w-0 lg:pl-64 flex flex-col transition-all duration-300 z-10 relative">
        
        <header class="bg-cardWhite/90 px-8 py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between sticky top-0 z-30 gap-4 border-b border-borderGray backdrop-blur-md transition-all duration-300 no-print">
            <div class="flex items-center gap-3">
                <button onclick="toggleSidebarMenu()" class="lg:hidden p-2.5 border border-borderGray bg-cardWhite rounded-xl text-slateText hover:bg-lightBg transition-colors">
                    <i class="fa-solid fa-bars-staggered"></i>
                </button>
                <div>
                    <p class="text-[10px] font-bold text-brandBlue uppercase tracking-widest bg-brandBlue/10 px-2 py-0.5 rounded inline-block">MEDCORE · PRACTITIONER TERMINAL</p>
                    <h1 class="text-xl font-bold text-slateText tracking-tight mt-0.5">
                        <?php echo $is_appointment_context ? 'Clinical Chart Desk' : 'Patient Records Matrix'; ?>
                    </h1>
                </div>
            </div>
            
            <div class="flex items-center flex-wrap gap-3 w-full sm:w-auto justify-end">
                <div class="bg-cardWhite border border-borderGray px-3 py-2 rounded-xl flex items-center gap-2 text-xs font-bold text-slate-600 shadow-sm border-l-4 border-l-brandBlue transition-all duration-300">
                    <i class="fa-regular fa-clock text-brandBlue"></i>
                    <span id="live-clock-timestamp" class="text-slateText tabular-nums font-extrabold tracking-wide">00:00:00</span>
                    <span class="text-borderGray">|</span>
                    <span class="text-slate-400 font-medium"><?php echo date("M d, Y"); ?></span>
                </div>
                <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-brandBlue to-brandSky text-white font-bold flex items-center justify-center text-sm shadow-md shadow-brandBlue/10 transform hover:scale-105 transition-all duration-300">
                    <?php echo strtoupper(substr($doctor_name, 0, 1)); ?>
                </div>
            </div>
        </header>

        <main class="px-8 py-6 space-y-6 flex-grow">
            
            <?php if (!empty($message)): ?>
                <div id="alert-toast" class="<?php echo $message_type === 'success' ? 'bg-successGreen/10 border-successGreen text-successGreen' : 'bg-dangerRed/10 border-dangerRed text-dangerRed'; ?> border rounded-xl px-5 py-4 text-xs font-bold flex items-center justify-between shadow-sm transition-all duration-500 transform no-print">
                    <div class="flex items-center gap-3">
                        <i class="fa-solid <?php echo $message_type === 'success' ? 'fa-circle-check text-successGreen' : 'fa-circle-exclamation text-dangerRed'; ?> text-base"></i> 
                        <span><?php echo $message; ?></span>
                    </div>
                    <button onclick="document.getElementById('alert-toast').style.display='none'" class="text-slate-400 hover:text-slate-600 cursor-pointer"><i class="fa-solid fa-xmark"></i></button>
                </div>
            <?php endif; ?>

            <?php if ($is_appointment_context): ?>
                <section class="bg-cardWhite border border-borderGray rounded-2xl p-6 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative overflow-hidden group gradient-border-glow">
                    <div class="absolute right-4 -bottom-6 opacity-5 pointer-events-none text-brandBlue transition-transform duration-700 group-hover:scale-110">
                        <i class="fa-solid fa-id-card-clip text-9xl"></i>
                    </div>
                    <div class="relative z-10">
                        <span class="text-[10px] font-extrabold tracking-wider bg-brandBlue/10 text-brandBlue px-2.5 py-1 rounded-md uppercase"><i class="fa-solid fa-robot mr-1"></i> Active Consultation</span>
                        <h2 class="text-2xl font-bold tracking-tight text-slateText mt-2"><?php echo htmlspecialchars($appointment['patient_name'] ?? 'Admission Profile', ENT_QUOTES, 'UTF-8'); ?></h2>
                        <p class="text-xs font-semibold text-slate-400 flex items-center gap-1.5 mt-1"><i class="fa-regular fa-envelope text-brandSky"></i> <?php echo htmlspecialchars($patient_email, ENT_QUOTES, 'UTF-8'); ?></p>
                        <a href="medical_records.php" class="inline-flex items-center gap-1.5 mt-4 text-xs text-brandBlue font-bold hover:text-brandSky transition-colors no-print">
                            <i class="fa-solid fa-arrow-left transition-transform group-hover:-translate-x-1"></i> Main Archives Ledger
                        </a>
                    </div>
                    <div class="flex flex-wrap gap-2 text-xs relative z-10">
                        <div class="bg-lightBg border border-borderGray px-4 py-3 rounded-xl shadow-sm">
                            <p class="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Channel Code</p>
                            <p class="font-bold text-brandBlue font-mono mt-0.5">#APP-<?php echo $appointment_id; ?></p>
                        </div>
                    </div>
                </section>

                <div class="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
                    
                    <section class="xl:col-span-7 bg-cardWhite border border-borderGray rounded-2xl shadow-sm p-6 space-y-5 hover-lift no-print">
                        <div class="flex items-center gap-2 border-b border-borderGray pb-4">
                            <i class="fa-solid fa-file-waveform text-brandBlue text-lg"></i>
                            <h3 class="text-sm font-bold text-slateText uppercase tracking-wide">
                                <?php echo $edit_mode ? 'Modify Historic Record Entry' : 'Record Case Consultation Metrics'; ?>
                            </h3>
                        </div>
                        <form method="POST" class="space-y-4">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <input type="hidden" name="patient_id" value="<?php echo htmlspecialchars($patient_id ?? ''); ?>">
                                <div class="space-y-1.5">
                                    <label class="block text-xs font-bold uppercase text-slate-400">Diagnosis Vector *</label>
                                    <div class="relative group">
                                        <span class="absolute inset-y-0 left-3.5 flex items-center text-slate-400 group-focus-within:text-brandBlue transition-colors"><i class="fa-solid fa-stethoscope text-xs"></i></span>
                                        <input type="text" name="diagnosis" required value="<?php echo htmlspecialchars($edit_data['diagnosis'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="e.g. Hypertension" class="w-full bg-lightBg border border-borderGray rounded-xl pl-9 pr-4 py-2.5 text-xs font-semibold text-slateText outline-none focus:border-brandBlue focus:bg-cardWhite transition-all duration-200">
                                    </div>
                                </div>
                                <div class="space-y-1.5">
                                    <label class="block text-xs font-bold uppercase text-slate-400">Log Verification Date</label>
                                    <div class="relative">
                                        <span class="absolute inset-y-0 left-3.5 flex items-center text-slate-400"><i class="fa-solid fa-calendar-day text-xs"></i></span>
                                        <input type="date" name="visit_date" value="<?php echo htmlspecialchars($edit_data['visit_date'], ENT_QUOTES, 'UTF-8'); ?>" class="w-full bg-lightBg border border-borderGray rounded-xl pl-9 pr-4 py-2.5 text-xs font-semibold text-slateText outline-none focus:border-brandBlue focus:bg-cardWhite transition-all duration-200">
                                    </div>
                                </div>
                            </div>
                            <div class="space-y-1.5">
                                <label class="block text-xs font-bold uppercase text-slate-400">Reported Symptoms Matrix</label>
                                <textarea name="symptoms" rows="2" placeholder="Input specific complaints or physiological indicators..." class="w-full bg-lightBg border border-borderGray rounded-xl px-4 py-2.5 text-xs text-slateText outline-none focus:border-brandBlue focus:bg-cardWhite transition-all duration-200"><?php echo htmlspecialchars($appointment['symptom'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                            </div>
                            <div class="space-y-1.5">
                                <label class="block text-xs font-bold uppercase text-slate-400">Prescribed Therapy / Treatment Protocol *</label>
                                <textarea name="treatment" rows="2" required placeholder="Outline medical actions, surgical instructions, or guidance routines..." class="w-full bg-lightBg border border-borderGray rounded-xl px-4 py-2.5 text-xs text-slateText outline-none focus:border-brandBlue focus:bg-cardWhite transition-all duration-200"><?php echo htmlspecialchars($edit_data['treatment'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                            </div>
                            <div class="space-y-1.5">
                                <label class="block text-xs font-bold uppercase text-slate-400">Rx Formulary Prescription</label>
                                <textarea name="prescription" rows="2" placeholder="e.g. Lipitor 10mg — 1x daily" class="w-full bg-lightBg border border-borderGray rounded-xl px-4 py-2.5 text-xs font-mono text-slateText outline-none focus:border-brandBlue focus:bg-cardWhite transition-all duration-200"><?php echo htmlspecialchars($edit_data['prescription'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                            </div>
                            
                            <div class="space-y-1.5">
                                <label class="block text-xs font-bold uppercase text-slate-400">Systemic Vitals Parameters</label>
                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                    <div class="relative group">
                                        <span class="absolute inset-y-0 left-3.5 flex items-center text-slate-400 text-[10px] font-extrabold">BP</span>
                                        <input type="text" name="blood_pressure" value="<?php echo htmlspecialchars($edit_data['blood_pressure'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="120/80 mmHg" class="w-full bg-lightBg border border-borderGray rounded-xl pl-9 pr-3 py-2.5 text-xs font-mono outline-none focus:border-brandBlue focus:bg-cardWhite transition-all">
                                    </div>
                                    <div class="relative group">
                                        <span class="absolute inset-y-0 left-3.5 flex items-center text-slate-400 text-[10px] font-extrabold">WT</span>
                                        <input type="text" name="weight_kg" value="<?php echo htmlspecialchars($edit_data['weight_kg'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="Weight (kg)" class="w-full bg-lightBg border border-borderGray rounded-xl pl-9 pr-3 py-2.5 text-xs font-mono outline-none focus:border-brandBlue focus:bg-cardWhite transition-all">
                                    </div>
                                    <div class="relative group">
                                        <span class="absolute inset-y-0 left-3.5 flex items-center text-slate-400 text-[10px] font-extrabold">TMP</span>
                                        <input type="text" name="temperature_c" value="<?php echo htmlspecialchars($edit_data['temperature_c'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="Temp (°C)" class="w-full bg-lightBg border border-borderGray rounded-xl pl-10 pr-3 py-2.5 text-xs font-mono outline-none focus:border-brandBlue focus:bg-cardWhite transition-all">
                                    </div>
                                </div>
                            </div>

                            <div class="space-y-1.5">
                                <label class="block text-xs font-bold uppercase text-slate-400">Clinical Reference Notes</label>
                                <textarea name="notes" rows="2" placeholder="Internal remarks, physical follow-up dates or observations..." class="w-full bg-lightBg border border-borderGray rounded-xl px-4 py-2.5 text-xs text-slateText outline-none focus:border-brandBlue focus:bg-cardWhite transition-all duration-200"><?php echo htmlspecialchars($edit_data['notes'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                            </div>
                            <button type="submit" name="persist_clinical_record" class="w-full py-3 bg-brandBlue hover:bg-brandBlue/90 text-white font-bold text-xs uppercase rounded-xl transition-all duration-300 shadow-md shadow-brandBlue/10 tracking-wider flex items-center justify-center gap-2 transform cursor-pointer">
                                <i class="fa-solid fa-floppy-disk text-xs"></i>
                                <?php echo $edit_mode ? 'Authorize System Modifications' : 'Publish & Save Authenticated Entry'; ?>
                            </button>
                        </form>
                    </section>

                    <section class="xl:col-span-5 space-y-4 print-full-card">
                        <div class="bg-cardWhite border border-borderGray p-4 rounded-2xl shadow-sm flex items-center gap-3">
                            <div class="w-8 h-8 rounded-lg bg-brandSky/10 text-brandSky flex items-center justify-center"><i class="fa-solid fa-clock-rotate-left text-xs"></i></div>
                            <div>
                                <h3 class="text-xs font-bold uppercase text-slate-400 tracking-wider">Historical Evaluation Timeline</h3>
                                <p class="text-xs font-bold text-slate-600 mt-0.5">Found <span class="text-brandBlue font-extrabold"><?php echo count($history_records); ?></span> archived entries</p>
                            </div>
                        </div>
                        <div class="space-y-4 max-h-[660px] overflow-y-auto pr-1">
                            <?php if (empty($history_records)): ?>
                                <div class="bg-cardWhite border border-borderGray border-dashed rounded-2xl p-12 text-center text-xs font-bold text-slate-400 italic">No historical case charts published on this patient identity link yet.</div>
                            <?php else: foreach ($history_records as $h_row): ?>
                                <div class="bg-cardWhite border border-borderGray rounded-2xl p-5 shadow-sm space-y-3 border-l-4 <?php echo ($edit_mode && $edit_data['id'] == $h_row['id']) ? 'border-l-warningAmber bg-warningAmber/5' : 'border-l-brandBlue hover:border-l-brandSky'; ?> transition-all duration-300 transform">
                                    <div class="flex justify-between items-start border-b border-lightBg pb-2">
                                        <div>
                                            <span class="font-mono text-[9px] font-extrabold text-brandBlue bg-brandBlue/10 px-2 py-0.5 rounded-md">#REC-<?php echo $h_row['id']; ?></span>
                                            <h4 class="text-sm font-bold text-slateText mt-1.5"><?php echo htmlspecialchars($h_row['diagnosis'] ?? 'General Health Evaluation', ENT_QUOTES, 'UTF-8'); ?></h4>
                                        </div>
                                        <span class="text-[10px] text-slate-400 font-bold bg-lightBg px-2 py-1 rounded-md flex items-center gap-1 shrink-0"><i class="fa-regular fa-clock text-[9px] text-brandSky"></i> <?php echo htmlspecialchars($h_row['visit_date'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></span>
                                    </div>
                                    <?php if(!empty($h_row['notes'])): ?>
                                        <p class="text-xs text-slate-500 bg-lightBg p-2.5 rounded-xl border border-borderGray italic">"<?php echo htmlspecialchars($h_row['notes'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"</p>
                                    <?php endif; ?>
                                    <div class="text-xs font-medium text-slate-600 bg-brandBlue/5 p-2.5 rounded-xl border border-brandBlue/10">
                                        <span class="text-[9px] uppercase font-bold text-brandBlue block mb-0.5">Therapeutics Setup</span>
                                        <?php echo htmlspecialchars($h_row['treatment'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                                    </div>
                                    <div class="flex justify-end gap-1.5 text-[10px] pt-2 border-t border-lightBg no-print">
                                        <a href="medical_records.php?appointment_id=<?php echo $appointment_id; ?>&download_pdf=<?php echo $h_row['id']; ?>" target="_blank" class="px-2.5 py-1.5 bg-slateText text-white rounded-lg font-bold uppercase transition-all hover:bg-slateText/90 flex items-center gap-1">
                                            <i class="fa-solid fa-file-pdf"></i> PDF
                                        </a>
                                        <?php if ($h_row['doctor_id'] == $doctor_id): ?>
                                            <a href="medical_records.php?appointment_id=<?php echo $appointment_id; ?>&edit_record=<?php echo $h_row['id']; ?>" class="px-2.5 py-1.5 bg-warningAmber/10 text-warningAmber border border-warningAmber/20 rounded-lg font-bold uppercase transition-all hover:bg-warningAmber/20 flex items-center gap-1">
                                                <i class="fa-solid fa-pen-to-square"></i> Edit
                                            </a>
                                            <a href="medical_records.php?appointment_id=<?php echo $appointment_id; ?>&delete_record=<?php echo $h_row['id']; ?>&token=<?php echo urlencode($_SESSION['csrf_token']); ?>" onclick="return confirm('Erase this archival medical entry permanently?');" class="px-2.5 py-1.5 bg-dangerRed/10 text-dangerRed border border-dangerRed/20 rounded-lg font-bold uppercase transition-all hover:bg-dangerRed/20 flex items-center gap-1">
                                                <i class="fa-solid fa-trash-can"></i> Del
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; endif; ?>
                        </div>
                    </section>
                </div>

            <?php else: ?>
                <section class="bg-gradient-to-r from-brandBlue to-brandSky border border-brandBlue rounded-2xl p-6 shadow-md shadow-brandBlue/10 text-white relative overflow-hidden group">
                    <div class="absolute -right-6 -bottom-6 opacity-10 pointer-events-none text-white transition-transform duration-700 group-hover:scale-105">
                        <i class="fa-solid fa-shield-halved text-9xl"></i>
                    </div>
                    <div class="relative z-10 space-y-1">
                        <p class="text-[10px] font-bold uppercase text-brandBlue/10 bg-white px-2 py-0.5 rounded inline-block">Ledger Archive System</p>
                        <h2 class="text-2xl font-bold tracking-tight">Patient Clinical Records Matrix</h2>
                        <p class="text-xs text-white/80 max-w-xl font-medium">Audit historical patient criteria parameters, trace detailed pathological diagnostic reports and export digitally compiled PDF file certificates securely.</p>
                    </div>
                </section>

                <section class="bg-cardWhite border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover-lift no-print">
                    <div>
                        <h3 class="text-xs font-bold uppercase text-slateText tracking-wider">Registry Ledger Index</h3>
                        <p class="text-xs text-slate-400 mt-0.5 font-bold">Total Confirmed Nodes: <span class="text-brandBlue font-extrabold"><?php echo $count_records; ?></span></p>
                    </div>
                    <form method="GET" action="medical_records.php" class="flex items-stretch gap-2 w-full sm:max-w-md">
                        <div class="relative w-full group">
                            <span class="absolute inset-y-0 left-3.5 flex items-center text-slate-400 group-focus-within:text-brandBlue transition-colors"><i class="fa-solid fa-magnifying-glass text-xs"></i></span>
                            <input type="text" name="search" value="<?php echo htmlspecialchars($search ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search diagnostics, treatments or patients..." class="w-full bg-lightBg border border-borderGray rounded-xl pl-9 pr-4 py-2 text-xs font-semibold text-slateText outline-none focus:border-brandBlue focus:bg-cardWhite transition-all duration-200">
                        </div>
                        <button type="submit" class="px-5 py-2 bg-slateText hover:bg-slateText/90 text-white font-bold text-xs uppercase rounded-xl transition-all tracking-wider shrink-0 cursor-pointer">Filter</button>
                    </form>
                </section>

                <section class="bg-cardWhite border border-borderGray rounded-2xl shadow-sm overflow-hidden print-full-card">
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse text-left">
                            <thead>
                                <tr class="bg-slateText border-b border-slateText text-white text-[10px] font-bold uppercase tracking-wider">
                                    <th class="px-6 py-4">Record ID</th>
                                    <th class="px-6 py-4">Patient Profile</th>
                                    <th class="px-6 py-4">Observed Vitals</th>
                                    <th class="px-6 py-4">Diagnosis Summary</th>
                                    <th class="px-6 py-4">Treatment Protocol</th>
                                    <th class="px-6 py-4 text-center no-print">Operations</th>
                                </tr>
                            </thead>
                            <tbody class="text-xs divide-y divide-borderGray font-medium text-slate-500 bg-cardWhite">
                                <?php if ($records->num_rows === 0): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-20 text-xs text-slate-400 italic bg-lightBg/50">
                                            <div class="flex flex-col items-center justify-center gap-3">
                                                <i class="fa-regular fa-folder-open text-4xl text-slate-300"></i>
                                                <span class="font-bold text-slate-400">No active clinical record nodes matched your filtered parameters.</span>
                                            </div>
                                        </td>
                                    </tr>
                                <?php else: while ($row = $records->fetch_assoc()): ?>
                                    <tr class="hover:bg-lightBg transition-colors duration-150 group">
                                        <td class="px-6 py-4 font-mono font-bold text-brandBlue">#REC-<?php echo htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td class="px-6 py-4">
                                            <div class="font-bold text-slateText text-sm transition-colors group-hover:text-brandBlue"><?php echo htmlspecialchars($row['patient_name'] ? $row['patient_name'] : 'System Assigned Identity', ENT_QUOTES, 'UTF-8'); ?></div>
                                            <div class="text-[10px] text-slate-400 font-bold mt-0.5 flex items-center gap-1"><i class="fa-regular fa-calendar text-brandSky"></i> <?php echo date("M d, Y", strtotime($row['created_at'])); ?></div>
                                        </td>
                                        <td class="px-6 py-4 font-mono text-[11px] text-slate-400 space-y-0.5">
                                            <div>BP: <span class="text-slateText font-bold"><?php echo !empty($row['blood_pressure']) ? htmlspecialchars($row['blood_pressure']) : 'N/A'; ?></span></div>
                                            <div>WT: <span class="text-slateText font-bold"><?php echo !empty($row['weight_kg']) ? htmlspecialchars($row['weight_kg'])."kg" : 'N/A'; ?></span></div>
                                        </td>
                                        <td class="px-6 py-4 text-slate-800 text-xs">
                                            <span class="px-2 py-0.5 bg-brandBlue/10 text-brandBlue font-bold text-[9px] uppercase rounded inline-block mb-1"><i class="fa-solid fa-wave-square text-[9px]"></i> Assessment</span><br>
                                            <span class="font-bold text-slateText"><?php echo htmlspecialchars($row['diagnosis'], ENT_QUOTES, 'UTF-8'); ?></span>
                                        </td>
                                        <td class="px-6 py-4 max-w-xs">
                                            <div class="font-mono text-[11px] text-slate-600 bg-lightBg p-2 rounded-xl border border-borderGray line-clamp-2 transition-colors" title="<?php echo htmlspecialchars($row['treatment']); ?>">
                                                <?php echo htmlspecialchars($row['treatment'], ENT_QUOTES, 'UTF-8'); ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 text-center no-print">
                                            <div class="flex items-center justify-center gap-1.5">
                                                <a href="medical_records.php?download_pdf=<?php echo $row['id']; ?>" target="_blank" class="p-2 bg-lightBg text-slate-600 hover:bg-slateText hover:text-white rounded-lg border border-borderGray transition-all" title="Stream Generated PDF Document">
                                                    <i class="fa-solid fa-file-pdf text-xs"></i>
                                                </a>
                                                <?php if (isset($row['appointment_id']) && intval($row['appointment_id']) > 0): ?>
                                                    <a href="medical_records.php?appointment_id=<?php echo intval($row['appointment_id']); ?>&edit_record=<?php echo $row['id']; ?>" class="px-2.5 py-1.5 bg-warningAmber/10 hover:bg-warningAmber/20 text-warningAmber font-bold uppercase rounded-lg border border-warningAmber/20 text-[10px] flex items-center gap-1 transition-all">
                                                        <i class="fa-solid fa-pencil"></i> Edit
                                                    </a>
                                                <?php endif; ?>
                                                <a href="medical_records.php?delete_id=<?php echo $row['id']; ?>&token=<?php echo urlencode($_SESSION['csrf_token']); ?>" onclick="return confirm('Permanent data purge initialization requested. Proceed?');" class="p-2 bg-dangerRed/10 hover:bg-dangerRed hover:text-white text-dangerRed rounded-lg border border-dangerRed/20 transition-all" title="Purge Ledger Element">
                                                    <i class="fa-solid fa-trash-can text-xs"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            <?php endif; ?>
        </main>
    </div>

    <script>
        function toggleSidebarMenu() {
            const panel = document.getElementById('sidebar-panel');
            const backdrop = document.getElementById('sidebar-backdrop');
            panel.classList.toggle('-translate-x-full');
            backdrop.classList.toggle('hidden');
        }

        function runLiveClock() {
            const el = document.getElementById('live-clock-timestamp');
            if(el) { 
                const now = new Date(); 
                el.innerText = now.toTimeString().split(' ')[0]; 
            }
        }
        setInterval(runLiveClock, 1000); 
        runLiveClock();
    </script>
</body>
</html>