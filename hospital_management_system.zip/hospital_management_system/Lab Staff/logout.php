<?php
session_start();
unset($_SESSION['lab_staff_id']);
unset($_SESSION['lab_staff_name']);
session_destroy();
header("Location: login.php");
exit();
?>