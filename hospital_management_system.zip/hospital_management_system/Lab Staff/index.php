<?php
session_start();
include("../includes/conn.php");

if (!isset($_SESSION['lab_staff_id'])) {
    header("Location: login.php");
    exit();
}

$lab_staff_id = mysqli_real_escape_string($conn, $_SESSION['lab_staff_id']);
$message = "";

/* --- 1. HANDLING REPORT GENERATION FORM --- */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    
    // ACTION: CREATE NEW REPORT
    if ($_POST['action'] == 'create_report') {
        $patient_data = mysqli_real_escape_string($conn, $_POST['patient_data']);
        $parts = explode('|', $patient_data);
        
        if (count($parts) === 2) {
            $user_email = $parts[0];
            $patient_name = $parts[1];
            
            $doctor_id = mysqli_real_escape_string($conn, $_POST['doctor_id']);
            $test_name = mysqli_real_escape_string($conn, $_POST['test_name']);
            $test_results = mysqli_real_escape_string($conn, $_POST['test_results']);
            $normal_range = mysqli_real_escape_string($conn, $_POST['normal_range']);
            $test_date = mysqli_real_escape_string($conn, $_POST['test_date']);

            $insert_query = "INSERT INTO lab_report (patient_name, user_email, doctor_id, test_name, test_results, normal_range, test_date, status) 
                             VALUES ('$patient_name', '$user_email', '$doctor_id', '$test_name', '$test_results', '$normal_range', '$test_date', 'Final')";
            
            if (mysqli_query($conn, $insert_query)) {
                $message = "
                <div class='animate-slide-up p-5 mb-6 text-sm text-sky-800 bg-sky-50 rounded-2xl border border-sky-100 font-semibold shadow-sm flex items-center gap-4'>
                    <div class='flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-sky-100 text-sky-600 shadow-sm animate-pulse'>
                        <svg class='w-5 h-5' fill='none' stroke='currentColor' stroke-width='2.5' viewBox='0 0 24 24'><path stroke-linecap='round' stroke-linejoin='round' d='M4.5 12.75l6 6 9-13.5'/></svg>
                    </div>
                    <div>
                        <p class='font-bold text-slate-900 text-sm'>Action Success</p>
                        <p class='text-xs text-slate-500 font-medium'>Laboratory diagnostics report logged and transmitted to patient profile.</p>
                    </div>
                </div>";
            }
        }
    }

    // ACTION: UPDATE EXISTING REPORT (EDIT MODAL ROUTE)
    if ($_POST['action'] == 'update_report') {
        $report_id = intval($_POST['report_id']);
        $test_name = mysqli_real_escape_string($conn, $_POST['test_name']);
        $test_results = mysqli_real_escape_string($conn, $_POST['test_results']);
        $normal_range = mysqli_real_escape_string($conn, $_POST['normal_range']);
        $test_date = mysqli_real_escape_string($conn, $_POST['test_date']);
        $doctor_id = mysqli_real_escape_string($conn, $_POST['doctor_id']);

        $update_query = "UPDATE lab_report SET 
                            test_name = '$test_name', 
                            test_results = '$test_results', 
                            normal_range = '$normal_range', 
                            test_date = '$test_date',
                            doctor_id = '$doctor_id'
                         WHERE report_id = $report_id";
        
        if (mysqli_query($conn, $update_query)) {
            $message = "
            <div class='animate-slide-up p-5 mb-6 text-sm text-blue-800 bg-blue-50 rounded-2xl border border-blue-100 font-semibold shadow-sm flex items-center gap-4'>
                <div class='flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-100 text-blue-600 shadow-sm'>
                    <svg class='w-5 h-5' fill='none' stroke='currentColor' stroke-width='2.5' viewBox='0 0 24 24'><path stroke-linecap='round' stroke-linejoin='round' d='M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99'/></svg>
                </div>
                <div>
                    <p class='font-bold text-slate-900 text-sm'>Database Updated</p>
                    <p class='text-xs text-slate-500 font-medium'>Report ID #LAB-$report_id has been successfully recompiled.</p>
                </div>
            </div>";
        }
    }
}

/* --- 2. TELEMETRY STATS --- */
$total_reports = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM lab_report"))['total'];
$doctors_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT doctor_id) as total FROM lab_report"))['total'];
$patients_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT patient_name) as total FROM lab_report"))['total'];
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50 selection:bg-sky-500 selection:text-white">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedScope Lab Administration Terminal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        
        /* Modern Continuous Smooth Floating Animations */
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-5px); }
        }
        .animated-float { animation: float 4s ease-in-out infinite; }
        
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(16px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-slide-up { animation: slideUp 0.45s cubic-bezier(0.16, 1, 0.3, 1) forwards; }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .animate-fade-in { animation: fadeIn 0.25s ease-out forwards; }

        /* Smooth View Panel Display Mapping */
        .tab-panel { display: none; }
        .tab-panel.active-view { display: block; }
    </style>
</head>
<body class="min-h-screen bg-slate-50 text-slate-700 antialiased flex overflow-x-hidden">

    <aside class="w-72 bg-white flex flex-col justify-between fixed h-full z-40 border-r border-slate-200 shadow-sm">
        <div class="p-6 space-y-8">
            <div class="flex items-center gap-3">
                <div class="w-11 h-11 rounded-xl bg-sky-50 border border-sky-100 flex items-center justify-center shadow-sm shrink-0 animated-float">
                    <svg class="w-6 h-6 text-sky-500" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 12h3l3-7 4 14 3-10 2 5h3"/>
                    </svg>
                </div>
                <h2 class="text-xl font-black tracking-tight text-slate-900 uppercase">
                    MED<span class="text-sky-600 bg-gradient-to-r from-sky-600 to-blue-600 bg-clip-text text-transparent">CORE</span>
                </h2>
            </div>

            <nav class="space-y-2">
                <button onclick="switchTab('overview')" id="btn-overview" class="tab-btn w-full px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider text-white bg-gradient-to-r from-sky-500 to-blue-600 shadow-md shadow-sky-500/10 hover:shadow-lg hover:shadow-sky-500/20 active:scale-[0.98] flex items-center gap-3 transition-all border-l-[3px] border-sky-500">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M7.5 14.25v2.25m3-4.5v4.5m3-6.75v6.75m3-9v9M6 20.25h12A2.25 2.25 0 0020.25 18V6A2.25 2.25 0 0018 3.75H6A2.25 2.25 0 003.75 6v12A2.25 2.25 0 006 20.25z"/></svg>
                    Overview Hub
                </button>
                <button onclick="switchTab('create-report')" id="btn-create-report" class="tab-btn w-full px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider text-slate-400 hover:text-slate-800 hover:bg-slate-50 active:scale-[0.98] flex items-center gap-3 transition-all border-l-[3px] border-transparent">
                    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15"/></svg>
                    Create Lab Report
                </button>
            </nav>
        </div>

        <div class="p-4 border-t border-slate-100 bg-slate-50">
            <a href="logout.php" class="group w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-widest border border-rose-200 text-rose-600 bg-rose-50/60 hover:bg-rose-100/80 active:scale-[0.98] transition-all shadow-sm">
                <svg class="w-4 h-4 text-rose-600 group-hover:translate-x-0.5 transition-transform" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 0013.5-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75"/></svg>
                Disconnect Session
            </a>
        </div>
    </aside>

    <main class="flex-grow ml-72 min-h-screen flex flex-col transition-all duration-300">
        
        <header class="h-16 border-b border-slate-200 bg-white/80 backdrop-blur-md flex items-center justify-between px-8 sticky top-0 z-30">
            <div class="flex items-center gap-4">
                <div class="flex items-center gap-2 bg-slate-50 border border-slate-200/80 px-3.5 py-1.5 rounded-xl shadow-sm">
                    <svg class="w-3.5 h-3.5 text-sky-500" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5m-9-6h.008v.008H12v-.008zM12 15h.008v.008H12V15zm0 2.25h.008v.008H12v-.008zM9.75 15h.008v.008H9.75V15zm0 2.25h.008v.008H9.75v-.008zM7.5 15h.008v.008H7.5V15zm0 2.25h.008v.008H7.5v-.008zm6.75-4.5h.008v.008h-.008v-.008zm0 2.25h.008v.008h-.008V15zm0 2.25h.008v.008h-.008v-.008zm2.25-4.5h.008v.008H16.5v-.008zm0 2.25h.008v.008H16.5V15z"/></svg>
                    <span id="live-date" class="text-[11px] font-extrabold uppercase tracking-wide text-slate-600 font-mono">Loading Date...</span>
                </div>
                <div class="flex items-center gap-2 bg-sky-50/60 border border-sky-100 px-3.5 py-1.5 rounded-xl shadow-sm">
                    <svg class="w-3.5 h-3.5 text-sky-600 animate-pulse" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <span id="live-time" class="text-[11px] font-black tracking-wide text-sky-700 font-mono">00:00:00 AM</span>
                </div>
            </div>

            <div class="text-xs text-slate-600 font-medium flex items-center bg-white border border-slate-200 px-4 py-2 rounded-xl shadow-sm transition-all hover:border-sky-300 hover:shadow-sky-100/50">
                <div class="w-6 h-6 rounded-full bg-gradient-to-tr from-sky-400 to-blue-600 flex items-center justify-center text-white text-[10px] font-black mr-2.5 shadow-sm">
                    <?php echo strtoupper(substr($_SESSION['lab_staff_name'], 0, 2)); ?>
                </div>
                Active Operator: <strong class="ml-1 text-slate-900 font-bold uppercase tracking-wide"><?php echo htmlspecialchars($_SESSION['lab_staff_name']); ?></strong>
            </div>
        </header>

        <div class="flex-grow p-8 max-w-7xl w-full mx-auto space-y-6">
            <?php echo $message; ?>

            <div id="view-overview" class="tab-panel active-view space-y-8 animate-slide-up">
                
                <div class="relative bg-gradient-to-br from-sky-500 via-blue-700 to-slate-950 rounded-3xl p-8 overflow-hidden shadow-xl border border-sky-400/20 text-white transition-all duration-300 hover:shadow-sky-300/20">
                    <div class="relative z-10">
                        <span class="bg-white/10 text-sky-200 border border-white/20 text-[10px] px-3 py-1 rounded-full font-bold uppercase tracking-widest backdrop-blur-md">Diagnostic Pipeline Core</span>
                        <h2 class="text-3xl font-black tracking-tight mt-4">Welcome back, <?php echo htmlspecialchars($_SESSION['lab_staff_name']); ?></h2>
                        <p class="text-sky-100/80 text-xs mt-1 max-w-xl font-medium">Pathology Registry Database Overview System. Update, log, and monitor diagnostics instantly via dynamic telemetry cards.</p>
                    </div>
                    <div class="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-white/5 to-transparent pointer-events-none"></div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
                    <div class="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm flex items-center justify-between hover:shadow-lg hover:shadow-sky-100/30 hover:-translate-y-0.5 transition-all duration-300 group">
                        <div><p class="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest group-hover:text-sky-500 transition-colors">Total Logs</p><h3 class="text-3xl font-black text-slate-900 mt-1"><?php echo $total_reports; ?></h3></div>
                        <div class="p-3 bg-sky-50 text-sky-600 rounded-xl border border-sky-100 shadow-sm transition-all group-hover:scale-110 group-hover:bg-sky-500 group-hover:text-white"><svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.064.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.03 0 1.9.693 2.166 1.638m-7.377 2.24a4.5 4.5 0 111.583-1.583m-1.585 1.585L12 6.75"/></svg></div>
                    </div>
                    <div class="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm flex items-center justify-between hover:shadow-lg hover:shadow-sky-100/30 hover:-translate-y-0.5 transition-all duration-300 group">
                        <div><p class="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest group-hover:text-blue-500 transition-colors">Mapped Patients</p><h3 class="text-3xl font-black text-slate-900 mt-1"><?php echo $patients_count; ?></h3></div>
                        <div class="p-3 bg-blue-50 text-blue-600 rounded-xl border border-blue-100 shadow-sm transition-all group-hover:scale-110 group-hover:bg-blue-500 group-hover:text-white"><svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"/></svg></div>
                    </div>
                    <div class="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm flex items-center justify-between hover:shadow-lg hover:shadow-sky-100/30 hover:-translate-y-0.5 transition-all duration-300 group">
                        <div><p class="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest group-hover:text-indigo-500 transition-colors">Active Physicians</p><h3 class="text-3xl font-black text-slate-900 mt-1"><?php echo $doctors_count; ?></h3></div>
                        <div class="p-3 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-100 shadow-sm transition-all group-hover:scale-110 group-hover:bg-indigo-500 group-hover:text-white"><svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z"/></svg></div>
                    </div>
                </div>

                <div class="bg-white rounded-3xl border border-slate-200/60 shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md">
                    <div class="px-6 py-5 border-b border-slate-100 bg-slate-50/60 flex items-center justify-between">
                        <h3 class="text-xs font-black text-slate-900 tracking-wider uppercase">Central Pathology Diagnostics Registry</h3>
                        <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse block shadow-sm"></span>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-slate-200 bg-slate-50 text-[10px] font-extrabold uppercase tracking-widest text-slate-400">
                                    <th class="px-6 py-4">Report ID</th>
                                    <th class="px-6 py-4">Patient</th>
                                    <th class="px-6 py-4">Test Modality</th>
                                    <th class="px-6 py-4">Results</th>
                                    <th class="px-6 py-4">Ref Range</th>
                                    <th class="px-6 py-4">Doctor</th>
                                    <th class="px-6 py-4 text-center">Action Parameters</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 text-xs font-medium text-slate-600">
                                <?php
                                $res = mysqli_query($conn, "SELECT * FROM lab_report ORDER BY report_id DESC");
                                if ($res && mysqli_num_rows($res) > 0) {
                                    while($row = mysqli_fetch_assoc($res)) {
                                        $safe_row = json_encode([
                                            'id' => $row['report_id'],
                                            'name' => $row['patient_name'],
                                            'test' => $row['test_name'],
                                            'results' => $row['test_results'],
                                            'range' => $row['normal_range'],
                                            'date' => $row['test_date'],
                                            'doc' => $row['doctor_id']
                                        ], JSON_HEX_APOS | JSON_HEX_QUOT);

                                        echo "<tr class='hover:bg-sky-50/30 transition-colors group'>
                                            <td class='px-6 py-4 font-mono font-bold text-sky-600'>#LAB-{$row['report_id']}</td>
                                            <td class='px-6 py-4 font-bold text-slate-900'>" . htmlspecialchars($row['patient_name']) . "</td>
                                            <td class='px-6 py-4'>" . htmlspecialchars($row['test_name']) . "</td>
                                            <td class='px-6 py-4 font-mono max-w-[180px] truncate text-slate-500'>" . htmlspecialchars($row['test_results']) . "</td>
                                            <td class='px-6 py-4 text-slate-400'>" . htmlspecialchars($row['normal_range']) . "</td>
                                            <td class='px-6 py-4'><code class='bg-slate-50 border border-slate-200 px-2 py-0.5 rounded text-[11px] text-slate-600 font-semibold group-hover:border-sky-200 group-hover:bg-sky-50 transition-colors'>" . htmlspecialchars($row['doctor_id']) . "</code></td>
                                            <td class='px-6 py-4 text-center'>
                                                <button onclick='launchEditModal({$safe_row})' class='px-3 py-1.5 bg-sky-50 border border-sky-100 text-sky-600 rounded-xl hover:bg-sky-500 hover:text-white active:scale-[0.96] font-bold tracking-wide uppercase text-[10px] transition-all flex items-center gap-1 mx-auto shadow-sm'>
                                                    <svg class='w-3 h-3' fill='none' stroke='currentColor' stroke-width='2.5' viewBox='0 0 24 24'><path d='M16.862 4.487l1.687-1.688a1.875 1.875 0 11-2.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125'/></svg>
                                                    Modify Log
                                                </button>
                                            </td>
                                        </tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='7' class='text-center py-12 text-slate-400 font-medium'>No diagnostics profiles currently logged.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="view-create-report" class="tab-panel space-y-6 animate-slide-up">
                <div class="bg-white rounded-3xl border border-slate-200/60 shadow-xl max-w-4xl mx-auto overflow-hidden transition-all hover:shadow-sky-200/30 hover:shadow-2xl duration-300">
                    <div class="px-8 py-6 border-b border-slate-100 bg-gradient-to-r from-slate-50 via-sky-50/10 to-white">
                        <h3 class="text-xs font-black text-slate-900 tracking-wider uppercase">Transmit Diagnostics Parameters</h3>
                    </div>

                    <form action="index.php" method="POST" class="p-10 space-y-6">
                        <input type="hidden" name="action" value="create_report">

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="relative group">
                                <select name="patient_data" class="w-full bg-slate-50/60 border border-slate-200 rounded-2xl px-4 pt-5 pb-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-50/70 transition-all appearance-none" required>
                                    <option value="" disabled selected class="text-slate-400">Select target recipient mapping...</option>
                                    <?php
                                    $patients_result = mysqli_query($conn, "SELECT id, name, email FROM patients ORDER BY name ASC");
                                    while ($p_row = mysqli_fetch_assoc($patients_result)) {
                                        echo "<option value='".htmlspecialchars($p_row['email']."|".$p_row['name'])."'>".htmlspecialchars($p_row['name'])."</option>";
                                    }
                                    ?>
                                </select>
                                <label class="absolute text-[10px] font-extrabold uppercase text-slate-400 tracking-wider left-4 top-1.5 pointer-events-none group-focus-within:text-sky-600 transition-colors">Target Patient Profile Mapping</label>
                            </div>

                            <div class="relative group">
                                <select name="doctor_id" class="w-full bg-slate-50/60 border border-slate-200 rounded-2xl px-4 pt-5 pb-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-50/70 transition-all appearance-none" required>
                                    <option value="" disabled selected>Select system medical officer link...</option>
                                    <?php
                                    $doctors_result = mysqli_query($conn, "SELECT doctor_id, name, department FROM doctors ORDER BY name ASC");
                                    while ($d_row = mysqli_fetch_assoc($doctors_result)) {
                                        echo "<option value='".htmlspecialchars($d_row['doctor_id'])."'>Dr. ".htmlspecialchars($d_row['name'])." [".htmlspecialchars($d_row['department'])."]</option>";
                                    }
                                    ?>
                                </select>
                                <label class="absolute text-[10px] font-extrabold uppercase text-slate-400 tracking-wider left-4 top-1.5 pointer-events-none group-focus-within:text-sky-600 transition-colors">Reviewing Physician Reference</label>
                            </div>
                        </div>

                        <div class="relative group">
                            <input type="text" name="test_name" placeholder=" " class="peer w-full bg-slate-50/60 border border-slate-200 rounded-2xl px-4 pt-6 pb-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-50/70 transition-all" required>
                            <label class="absolute text-[10px] font-extrabold uppercase text-slate-400 tracking-wider left-4 top-2 transition-all pointer-events-none peer-placeholder-shown:text-xs peer-placeholder-shown:top-4 peer-focus:top-2 peer-focus:text-[10px] peer-focus:text-sky-600">Test Modality Classification</label>
                        </div>

                        <div class="relative group">
                            <textarea name="test_results" rows="4" placeholder=" " class="peer w-full bg-slate-50/60 border border-slate-200 rounded-2xl px-4 pt-6 pb-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-50/70 transition-all shadow-inner resize-none" required></textarea>
                            <label class="absolute text-[10px] font-extrabold uppercase text-slate-400 tracking-wider left-4 top-2 transition-all pointer-events-none peer-placeholder-shown:text-xs peer-placeholder-shown:top-4 peer-focus:top-2 peer-focus:text-[10px] peer-focus:text-sky-600">Observed Quantitative Metrics</label>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="relative group">
                                <input type="text" name="normal_range" placeholder=" " class="peer w-full bg-slate-50/60 border border-slate-200 rounded-2xl px-4 pt-6 pb-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-50/70 transition-all" required>
                                <label class="absolute text-[10px] font-extrabold uppercase text-slate-400 tracking-wider left-4 top-2 transition-all pointer-events-none peer-placeholder-shown:text-xs peer-placeholder-shown:top-4 peer-focus:top-2 peer-focus:text-[10px] peer-focus:text-sky-600">Reference Intervals</label>
                            </div>
                            <div class="relative group">
                                <input type="date" name="test_date" value="<?php echo date('Y-m-d'); ?>" class="w-full bg-slate-50/60 border border-slate-200 rounded-2xl px-4 pt-5 pb-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-50/70 transition-all" required>
                                <label class="absolute text-[10px] font-extrabold uppercase text-slate-400 tracking-wider left-4 top-1.5 pointer-events-none group-focus-within:text-sky-600 transition-colors">Processing Timestamp</label>
                            </div>
                        </div>

                        <button type="submit" class="w-full py-4 rounded-2xl font-bold text-xs uppercase tracking-widest text-white bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 active:scale-[0.98] shadow-md shadow-sky-500/20 hover:shadow-xl hover:shadow-sky-500/30 transition-all mt-4">
                            TRANSMIT DIAGNOSTICS TO REGISTRY
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <div id="editModal" class="hidden fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
        <div class="bg-white rounded-3xl border border-slate-200/80 max-w-xl w-full shadow-2xl overflow-hidden transform transition-all duration-300">
            <div class="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                <div>
                    <h3 class="text-xs font-black text-slate-900 uppercase tracking-wider">Modify Partition Matrix</h3>
                    <p class="text-[10px] font-medium text-slate-400 mt-0.5" id="modal-report-lbl">Updating Record ID: #LAB-00</p>
                </div>
                <button onclick="closeEditModal()" class="p-1.5 hover:bg-slate-200 rounded-xl transition-colors text-slate-400 hover:text-slate-700 active:scale-[0.92]">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
            
            <form action="index.php" method="POST" class="p-8 space-y-4">
                <input type="hidden" name="action" value="update_report">
                <input type="hidden" name="report_id" id="edit-report-id">

                <div>
                    <label class="block text-[10px] font-extrabold uppercase text-slate-400 tracking-wider mb-1.5">Patient Account Name (Protected Profile)</label>
                    <input type="text" id="edit-patient-name" class="w-full bg-slate-100 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-400 cursor-not-allowed outline-none" readonly>
                </div>

                <div>
                    <label class="block text-[10px] font-extrabold uppercase text-slate-400 tracking-wider mb-1.5">Physician Officer Signature Link</label>
                    <select name="doctor_id" id="edit-doctor-id" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-semibold text-slate-700 focus:outline-none focus:border-sky-500 focus:bg-white transition-all" required>
                        <?php
                        $doctors_result = mysqli_query($conn, "SELECT doctor_id, name, department FROM doctors ORDER BY name ASC");
                        mysqli_data_seek($doctors_result, 0);
                        while ($d_row = mysqli_fetch_assoc($doctors_result)) {
                            echo "<option value='".htmlspecialchars($d_row['doctor_id'])."'>Dr. ".htmlspecialchars($d_row['name'])." [".htmlspecialchars($d_row['department'])."]</option>";
                        }
                        ?>
                    </select>
                </div>

                <div>
                    <label class="block text-[10px] font-extrabold uppercase text-slate-400 tracking-wider mb-1.5">Test Classification Modality</label>
                    <input type="text" name="test_name" id="edit-test-name" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-semibold text-slate-700 focus:outline-none focus:border-sky-500 focus:bg-white transition-all" required>
                </div>

                <div>
                    <label class="block text-[10px] font-extrabold uppercase text-slate-400 tracking-wider mb-1.5">Observed Laboratory Metrics Findings</label>
                    <textarea name="test_results" id="edit-test-results" rows="3" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-semibold text-slate-700 focus:outline-none focus:border-sky-500 focus:bg-white transition-all resize-none" required></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-extrabold uppercase text-slate-400 tracking-wider mb-1.5">Reference Intervals</label>
                        <input type="text" name="normal_range" id="edit-normal-range" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-semibold text-slate-700 focus:outline-none focus:border-sky-500 focus:bg-white transition-all" required>
                    </div>
                    <div>
                        <label class="block text-[10px] font-extrabold uppercase text-slate-400 tracking-wider mb-1.5">Collection Stamp Date</label>
                        <input type="date" name="test_date" id="edit-test-date" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-semibold text-slate-700 focus:outline-none focus:border-sky-500 focus:bg-white transition-all" required>
                    </div>
                </div>

                <div class="pt-4 flex gap-3 justify-end border-t border-slate-100 mt-4">
                    <button type="button" onclick="closeEditModal()" class="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-500 hover:bg-slate-50 active:scale-[0.97] transition-all">Abort Changes</button>
                    <button type="submit" class="px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 text-xs font-bold text-white hover:from-sky-600 shadow-md shadow-sky-500/10 active:scale-[0.97] transition-all">Compile Changes</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Live Real-Time Updating Digital Clock Function
        function updateLiveDateTime() {
            const now = new Date();
            
            // Format Live Time Parameters
            let hours = now.getHours();
            let minutes = now.getMinutes();
            let seconds = now.getSeconds();
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // conversion of '0' hour to '12'
            minutes = minutes < 10 ? '0' + minutes : minutes;
            seconds = seconds < 10 ? '0' + seconds : seconds;
            
            document.getElementById('live-time').innerText = `${hours}:${minutes}:${seconds} ${ampm}`;

            // Format Live Date Parameters
            const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
            document.getElementById('live-date').innerText = now.toLocaleDateString('en-US', options);
        }
        
        // Fire runtime clock instance looping every 1000 milliseconds
        setInterval(updateLiveDateTime, 1000);
        updateLiveDateTime();

        function switchTab(tabId) {
            document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active-view'));
            const targetPanel = document.getElementById('view-' + tabId);
            if (targetPanel) targetPanel.classList.add('active-view');

            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.className = "tab-btn w-full px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider text-slate-400 hover:text-slate-800 hover:bg-slate-50 active:scale-[0.98] flex items-center gap-3 transition-all border-l-[3px] border-transparent";
            });

            const activeBtn = document.getElementById('btn-' + tabId);
            if (activeBtn) {
                if (tabId === 'overview') {
                    activeBtn.className = "tab-btn w-full px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider text-white bg-gradient-to-r from-sky-500 to-blue-600 shadow-md shadow-sky-500/10 hover:shadow-lg hover:shadow-sky-500/20 active:scale-[0.98] flex items-center gap-3 transition-all border-l-[3px] border-sky-500";
                } else {
                    activeBtn.className = "tab-btn w-full px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider text-sky-600 border border-dashed border-sky-200 bg-sky-50/50 hover:bg-sky-50 active:scale-[0.98] flex items-center gap-3 transition-all border-l-[3px] border-sky-500";
                }
            }
        }

        function launchEditModal(data) {
            document.getElementById('edit-report-id').value = data.id;
            document.getElementById('modal-report-lbl').innerText = "Updating Record ID: #LAB-" + data.id;
            document.getElementById('edit-patient-name').value = data.name;
            document.getElementById('edit-test-name').value = data.test;
            document.getElementById('edit-test-results').value = data.results;
            document.getElementById('edit-normal-range').value = data.range;
            document.getElementById('edit-test-date').value = data.date;
            document.getElementById('edit-doctor-id').value = data.doc;

            document.getElementById('editModal').classList.remove('hidden');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.add('hidden');
        }
    </script>
</body>
</html>