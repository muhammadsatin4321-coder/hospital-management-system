<?php
session_start();
include("../includes/conn.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = mysqli_real_escape_string($conn, trim($_POST['username']));
    $password = mysqli_real_escape_string($conn, trim($_POST['password']));

    // Fetch user from database
    $sql = "SELECT * FROM lab_staff WHERE username='$username' LIMIT 1";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) == 1){

        $row = mysqli_fetch_assoc($result);

        // Check password
        if($password == $row['password']){

            $_SESSION['lab_staff_id']   = $row['lab_staff_id'];
            $_SESSION['lab_staff_name'] = $row['name'];
            $_SESSION['username']       = $row['username'];
            $_SESSION['shift']          = $row['shift'];

            header("Location: index.php");
            exit();

        }else{
            $error = "Incorrect Password!";
        }

    }else{
        $error = "Username not found!";
    }

}
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50 selection:bg-sky-500 selection:text-white">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Portal Login - MedScope</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brandBlue: '#0284C7', 
                        brandLightBlue: '#38BDF8', 
                        brandTeal: '#0EA5E9', 
                        brandOrange: '#F43F5E',
                        darkText: '#0F172A',
                        lightBg: '#F0F9FF' 
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        
        /* Smooth Floating Label Logic */
        .floating-input:focus ~ .floating-label,
        .floating-input:not(:placeholder-shown) ~ .floating-label {
            transform: translateY(-1rem) scale(0.85);
            color: #0284c7;
        }

        /* Continuous Floating Action for Logo Icon */
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-4px); }
        }
        .animated-float { animation: float 3s ease-in-out infinite; }

        /* FIXED: Added explicit Fade-In Keyframe Definition */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(16px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .animate-fade-in {
            animation: fadeIn 0.5s ease-out forwards;
        }
    </style>
</head>
<body class="min-h-screen bg-gradient-to-tr from-sky-100 via-slate-50 to-blue-50 text-slate-700 antialiased flex items-center justify-center p-4">

    <div class="w-full max-w-md bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden transition-all duration-300 hover:shadow-sky-200/50 hover:shadow-2xl animate-fade-in">
        
        <div class="p-8 pb-4 flex items-center justify-between border-b border-slate-50">
            <div class="flex items-center gap-3">
                <div class="w-11 h-11 rounded-xl bg-sky-50 border border-sky-100 flex items-center justify-center shadow-sm shrink-0 animated-float">
                    <svg class="w-6 h-6 text-sky-500" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 12h3l3-7 4 14 3-10 2 5h3"/>
                    </svg>
                </div>
                <h2 class="text-xl font-black tracking-tight text-slate-900 uppercase">
                    MED<span class="text-sky-600 bg-gradient-to-r from-sky-600 to-blue-600 bg-clip-text text-transparent">CORE</span>
                </h2>
            </div>
            <span class="text-[10px] font-bold uppercase tracking-wider bg-sky-50 text-sky-700 px-2.5 py-1 rounded-full border border-sky-100">Node v2.4</span>
        </div>

        <div class="p-8 space-y-6">
            <div class="text-center sm:text-left">
                <h1 class="text-2xl font-black tracking-tight text-slate-900">Lab Staff Portal</h1>
                <p class="text-xs text-slate-400 font-medium mt-1">Authenticate into the Pathology Entry & Modification node.</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="p-4 text-xs text-rose-800 bg-rose-50 rounded-2xl border border-rose-100 font-semibold shadow-sm flex items-center gap-3">
                    <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-rose-100 text-rose-600">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"/>
                        </svg>
                    </div>
                    <div>
                        <p class="font-bold text-slate-900">Authentication Failed</p>
                        <p class="text-[11px] text-slate-500 font-medium mt-0.5"><?php echo htmlspecialchars($error); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-4">
                
                <div class="relative group">
                    <input type="text" name="username" placeholder=" " class="floating-input peer w-full bg-slate-50/60 border border-slate-200 rounded-2xl px-4 pt-6 pb-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-50 transition-all duration-200" required autofocus autocomplete="username">
                    <label class="floating-label absolute text-[10px] font-bold uppercase text-slate-400 tracking-wider left-4 top-4 origin-left pointer-events-none transition-all duration-200">Staff Username Node</label>
                </div>

                <div class="relative group">
                    <input type="password" name="password" placeholder=" " class="floating-input peer w-full bg-slate-50/60 border border-slate-200 rounded-2xl px-4 pt-6 pb-2 text-xs font-semibold text-slate-800 focus:outline-none focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-50 transition-all duration-200" required autocomplete="current-password">
                    <label class="floating-label absolute text-[10px] font-bold uppercase text-slate-400 tracking-wider left-4 top-4 origin-left pointer-events-none transition-all duration-200">Security Access Key</label>
                </div>

                <button type="submit" class="w-full py-4 rounded-2xl font-bold text-xs uppercase tracking-widest text-white bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 active:scale-[0.98] shadow-lg shadow-sky-500/20 hover:shadow-xl hover:shadow-sky-500/30 transition-all duration-200 flex items-center justify-center gap-2 mt-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9" />
                    </svg>
                    Establish Secure Session
                </button>
            </form>
            
        </div>
        
        <div class="px-8 py-4 bg-slate-50 border-t border-slate-100 text-center">
            <span class="inline-flex items-center gap-1.5 text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">
                <span class="w-2 h-2 rounded-full bg-sky-500 inline-block animate-pulse"></span>
                Secure Environment Connection
            </span>
        </div>
    </div>

</body>
</html>