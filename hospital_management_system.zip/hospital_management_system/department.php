<?php 
session_start();
include("includes/conn.php"); 
$current_page = 'department.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$dept_id = intval($_GET['id']);

// 1. Fetch Department Details Securely
$dept_query = "SELECT * FROM departments WHERE id = ?";
$stmt = mysqli_prepare($conn, $dept_query);
mysqli_stmt_bind_param($stmt, "i", $dept_id);
mysqli_stmt_execute($stmt);
$dept_result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($dept_result) === 0) {
    header("Location: index.php");
    exit();
}

$department = mysqli_fetch_assoc($dept_result);
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($department['name']); ?> | MedNetwork</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: '#F8FAFC',
                        card: '#FFFFFF',
                        primary: '#2563EB',
                        secondary: '#0EA5E9',
                        accent: '#14B8A6',
                        success: '#22C55E',
                        warning: '#F59E0B',
                        danger: '#EF4444',
                        textMain: '#1E293B',
                        borderColor: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        heading: ['Poppins', 'sans-serif']
                    },
                    borderRadius: {
                        'premium': '20px'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F8FAFC;
        }

        .font-heading {
            font-family: 'Poppins', sans-serif;
        }

        .premium-transition { 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
        }
        
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }

        /* Medical Pattern Grid Background Overlay */
        .medical-pattern {
            background-image: radial-gradient(#2563eb 0.75px, transparent 0.75px), radial-gradient(#0ea5e9 0.75px, #F8FAFC 0.75px);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            opacity: 0.15;
        }

        /* Scroll Reveal Systems */
        .reveal-section {
            opacity: 0; 
            transform: translateY(30px); 
            will-change: transform, opacity;
            transition: opacity 0.8s cubic-bezier(0.25, 1, 0.5, 1), transform 0.8s cubic-bezier(0.25, 1, 0.5, 1);
        }
        .reveal-section.visible { 
            opacity: 1; 
            transform: translateY(0); 
        }

        .form-input-focus:focus {
            border-color: #2563EB;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
            background-color: #FFFFFF;
        }
    </style>
</head>
<body class="text-textMain antialiased min-h-screen flex flex-col pt-[120px] relative overflow-x-hidden">

    <div class="absolute inset-0 medical-pattern pointer-events-none z-0"></div>
    <div class="absolute top-[10%] left-[-5%] w-[450px] h-[450px] bg-secondary/10 rounded-full blur-[120px] pointer-events-none z-0"></div>
    <div class="absolute bottom-[10%] right-[-5%] w-[500px] h-[500px] bg-accent/10 rounded-full blur-[150px] pointer-events-none z-0"></div>

    <div class="bg-danger text-white fixed top-0 left-0 right-0 z-[60] h-[40px] flex items-center text-sm font-medium shadow-sm border-b border-white/10">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <div class="flex items-center gap-6">
                <a href="tel:+15559113940" class="flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91" /></svg>
                    <span class="tracking-wide">Emergency: <strong class="font-semibold">+92 3000000000</strong></span>
                </a>
                <a href="mailto:support@mednetwork.org" class="hidden sm:flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    <span class="opacity-90">support@mednetwork.org</span>
                </a>
            </div>
            <div class="text-xs tracking-widest uppercase font-semibold opacity-90 hidden md:flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-white animate-pulse"></span> Available 24/7 For Urgent Clinical Response
            </div>
        </div>
    </div>

    <nav class="glass-nav fixed top-[40px] left-0 right-0 z-50 h-[80px] flex items-center border-b border-borderColor premium-transition shadow-sm" id="main-navbar">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-textMain group">
                <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 premium-transition">
                    <svg class="text-primary group-hover:scale-110 premium-transition" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                </div>
                <span class="tracking-tight">Med<span class="text-primary font-extrabold">Network</span></span>
            </a>
            
            <button class="md:hidden flex flex-col justify-between w-6 h-4 bg-transparent border-none cursor-pointer z-50 focus:outline-none" id="mobile-menu-btn" aria-label="Toggle navigation menu">
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar1"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition my-auto" id="bar2"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar3"></span>
            </button>
            
            <ul class="fixed md:static top-[120px] left-[-100%] md:left-0 w-full md:w-auto h-[calc(100vh-120px)] md:h-auto bg-card md:bg-transparent border-t border-borderColor md:border-none flex flex-col md:flex-row items-center pt-8 md:pt-0 gap-6 md:gap-8 premium-transition z-40" id="nav-links-menu">
                <li><a href="index.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Home</a></li>
                <li><a href="services.php" class="text-[15px] font-semibold text-primary premium-transition relative py-2 block">Services</a></li>
                <li><a href="doctors.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Our Doctors</a></li>
                <li><a href="about.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">About Us</a></li>
                <li><a href="contact.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Contact</a></li>
                
                <li class="hidden md:block w-px h-5 bg-borderColor mx-1"></li>

                <?php if(isset($_SESSION['patient_email'])): ?>
                    <li class="mt-4 md:mt-0"><a href="appointment.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-lg shadow-primary/10 select-none">Book Appointment</a></li>
                    <li><a href="Patient/dashboard.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition py-2 block">My Account</a></li>
                    <li><a href="logout.php" class="text-[15px] text-danger hover:text-red-700 font-semibold premium-transition py-2 block">Logout</a></li>
                <?php else: ?>
                    <li class="mt-4 md:mt-0"><a href="login.php" class="text-[15px] font-semibold text-textMain/80 hover:text-primary premium-transition py-2 block">Login</a></li>
                    <li class="mt-2 md:mt-0"><a href="register.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-sm">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <header class="w-full bg-card border-b border-borderColor py-16 relative z-10 reveal-section">
        <div class="container mx-auto px-6 max-w-[1200px] text-center">
            <div class="inline-flex items-center gap-2 bg-primary/10 text-primary font-bold text-xs px-3.5 py-1.5 rounded-xl uppercase tracking-wider border border-primary/20 mb-4">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>
                Clinical Faculty Matrix
            </div>
            <h1 class="font-heading text-3xl md:text-5xl font-bold text-textMain mb-4 tracking-tight leading-tight">
                <?php echo htmlspecialchars($department['name']); ?>
            </h1>
            <p class="text-[16px] text-textMain/75 max-w-2xl mx-auto leading-relaxed">
                Explore specialized medical frameworks, dedicated treatment infrastructure resources, and authorized practitioner nodes mapped dynamically below.
            </p>
        </div>
    </header>

    <main class="w-full max-w-[1200px] mx-auto px-6 py-12 relative z-10 flex-grow reveal-section">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            
            <div class="lg:col-span-7 bg-card border border-borderColor rounded-premium p-8 md:p-10 shadow-sm space-y-6">
                <div class="inline-flex items-center gap-2 bg-secondary/10 text-secondary font-bold text-xs px-3 py-1.5 rounded-xl uppercase tracking-wider border border-secondary/20">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    Operational Overview
                </div>
                <h3 class="font-heading text-2xl font-bold text-textMain tracking-tight">Department Charter Specifications</h3>
                <p class="text-[15px] text-textMain/80 leading-relaxed font-light">
                    <?php echo htmlspecialchars($department['description']); ?>
                </p>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                    <div class="p-6 bg-background border border-borderColor rounded-xl flex items-start gap-4 shadow-sm hover:shadow-md premium-transition">
                        <div class="bg-card text-primary p-3 rounded-xl shadow-sm border border-borderColor">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                        </div>
                        <div>
                            <h4 class="font-heading text-[15px] font-bold text-textMain tracking-tight">Data Security & Compliance</h4>
                            <p class="text-textMain/60 text-xs mt-1 leading-relaxed">Strict data privacy and medical compliance standards maintained across processing queues.</p>
                        </div>
                    </div>

                    <div class="p-6 bg-background border border-borderColor rounded-xl flex items-start gap-4 shadow-sm hover:shadow-md premium-transition">
                        <div class="bg-card text-accent p-3 rounded-xl shadow-sm border border-borderColor">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        </div>
                        <div>
                            <h4 class="font-heading text-[15px] font-bold text-textMain tracking-tight">Real-Time Grid Syncing</h4>
                            <p class="text-textMain/60 text-xs mt-1 leading-relaxed">Live scheduling windows connect explicitly into main medical practitioner routers.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="lg:col-span-5 bg-card border border-borderColor p-6 md:p-8 rounded-premium shadow-sm border-t-4 border-t-accent space-y-6">
                <div>
                    <h3 class="font-heading text-lg font-bold text-textMain tracking-tight mb-1">Assigned Unit Physicians</h3>
                    <p class="text-xs text-textMain/50">On-duty practitioners linked to this active grid location panel.</p>
                </div>

                <div class="space-y-4 max-h-[400px] overflow-y-auto pr-1">
                    <?php 
                    // 2. Fetch Doctors in this Department Securely
                    $doc_query = "SELECT * FROM doctors WHERE department = ? ORDER BY name ASC";
                    $doc_stmt = mysqli_prepare($conn, $doc_query);
                    mysqli_stmt_bind_param($doc_stmt, "s", $department['name']);
                    mysqli_stmt_execute($doc_stmt);
                    $doc_result = mysqli_stmt_get_result($doc_stmt);

                    if(mysqli_num_rows($doc_result) > 0): 
                        while($doctor = mysqli_fetch_assoc($doc_result)):
                            $doc_image = (!empty($doctor['image'])) ? 'uploads/' . $doctor['image'] : 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=200&auto=format&fit=crop';
                    ?>
                        <div class="bg-background border border-borderColor p-4 rounded-xl flex items-center justify-between shadow-sm hover:shadow-md hover:border-primary/40 transition duration-300 group">
                            <div class="flex items-center gap-4">
                                <div class="w-12 h-12 rounded-full overflow-hidden border border-borderColor bg-card flex-shrink-0">
                                    <img src="<?php echo htmlspecialchars($doc_image); ?>" class="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300" alt="Dr. <?php echo htmlspecialchars($doctor['name']); ?>">
                                </div>
                                <div>
                                    <h4 class="text-sm font-bold text-textMain group-hover:text-primary transition-colors duration-150">
                                        Dr. <?php echo htmlspecialchars($doctor['name']); ?>
                                    </h4>
                                    <p class="text-textMain/50 text-xs mt-0.5">
                                        <?php echo htmlspecialchars($doctor['experience']); ?> Years
                                    </p>
                                </div>
                            </div>
                            <a href="appointment.php" class="p-2.5 bg-card text-textMain/50 hover:text-white hover:bg-primary border border-borderColor hover:border-transparent rounded-xl shadow-sm premium-transition" title="Request Consultation Slot">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                            </a>
                        </div>
                    <?php 
                        endwhile;
                    else:
                    ?>
                        <div class="text-center py-10 text-textMain/50 text-sm bg-background rounded-xl border border-dashed border-borderColor">
                            No physician entities currently routed to this active department grid position.
                        </div>
                    <?php endif; ?>
                </div>

                <a href="appointment.php" class="text-[14px] block text-center w-full bg-gradient-to-r from-primary to-secondary text-white font-bold py-3.5 rounded-xl shadow-lg shadow-primary/20 transform hover:-translate-y-0.5 active:translate-y-0 premium-transition">
                    Book Consultation Now
                </a>
            </div>
            
        </div>
    </main>

    <footer class="bg-textMain text-white pt-16 pb-10 border-t border-textMain mt-auto relative z-10 shadow-inner">
        <div class="container mx-auto px-6 max-w-[1200px]">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-10 mb-12">
                <div class="md:col-span-2 space-y-4">
                    <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-white group inline-block">
                        <div class="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
                            <svg class="text-secondary" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                        </div>
                        <span class="tracking-tight">Med<span class="text-secondary font-extrabold">Network</span></span>
                    </a>
                    <p class="text-[14px] text-borderColor/70 max-w-sm leading-relaxed font-light">Providing high-quality clinical operations management tools and professional healthcare networking platforms globally.</p>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Platform</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="index.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Network Modules</a></li>
                        <li><a href="services.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Clinical Services</a></li>
                        <li><a href="doctors.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Doctor Portal</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Resources</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Developer API</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">System Status</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Support Center</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Emergency Contact</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li class="text-danger font-bold tracking-wide flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-danger animate-ping"></span> Hotline: +92 3000000000
                        </li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Terms & Conditions</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="pt-8 border-t border-white/10 text-center text-[13px] text-borderColor/40 tracking-wide">
                &copy; 2026 MedNetwork Systems Inc. All rights reserved. Secure clinical systems architecture verified.
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Mobile responsive menu drawer layout controller
            const menuBtn = document.getElementById("mobile-menu-btn");
            const navMenu = document.getElementById("nav-links-menu");
            const bar1 = document.getElementById("bar1");
            const bar2 = document.getElementById("bar2");
            const bar3 = document.getElementById("bar3");
            
            menuBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                navMenu.classList.toggle("left-0");
                navMenu.classList.toggle("left-[-100%]");
                
                bar1.classList.toggle("rotate-45");
                bar1.classList.toggle("translate-y-1.5");
                bar2.classList.toggle("opacity-0");
                bar3.classList.toggle("-rotate-45");
                bar3.classList.toggle("-translate-y-1.5");
            });

            document.addEventListener("click", function (e) {
                if (!menuBtn.contains(e.target) && !navMenu.contains(e.target)) {
                    navMenu.classList.add("left-[-100%]");
                    navMenu.classList.remove("left-0");
                    bar1.classList.remove("rotate-45", "translate-y-1.5");
                    bar2.classList.remove("opacity-0");
                    bar3.classList.remove("-rotate-45", "-translate-y-1.5");
                }
            });

            // Reactive Scroll Adjustments for Navigation Height
            const navbar = document.getElementById("main-navbar");
            window.addEventListener("scroll", function() {
                if (window.scrollY > 20) {
                    navbar.classList.remove("h-[80px]");
                    navbar.classList.add("h-[70px]", "shadow-md");
                } else {
                    navbar.classList.remove("h-[70px]", "shadow-md");
                    navbar.classList.add("h-[80px]", "shadow-sm");
                }
            }, { passive: true });

            // Staggered Scroll Animation Observer Frame
            const scrollSections = document.querySelectorAll(".reveal-section");
            const scrollObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if(entry.isIntersecting) {
                        entry.target.classList.add("visible");
                        scrollObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.05 });

            scrollSections.forEach(section => scrollObserver.observe(section));
        });
    </script>
</body>
</html>