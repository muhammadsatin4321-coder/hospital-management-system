<?php
session_start();

// Clear all active patient session variables
unset($_SESSION['patient_email']);
unset($_SESSION['patient_name']);

// Destroy the session completely
session_destroy();

// Redirect back to the patient login portal
header("Location: login.php");
exit();
?>