<?php 
session_start();
include("includes/conn.php");

if(!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: services.php");
    exit();
}

$service_id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM Services WHERE id = ? AND status = 'Active'");
$stmt->bind_param("i", $service_id);
$stmt->execute();
$res = $stmt->get_result();
$service = $res->fetch_assoc();

if(!$service) {
    header("Location: services.php");
    exit();
}
$image = trim($service['image_url']);

if (!empty($image) && file_exists($image)) {
    $img_path = $image;
} else {
    $img_path = "services/default.jpg";
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($service['name']); ?> | MedNetwork</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: '#F8FAFC',
                        card: '#FFFFFF',
                        primary: '#2563EB',
                        secondary: '#0EA5E9',
                        accent: '#14B8A6',
                        success: '#22C55E',
                        warning: '#F59E0B',
                        danger: '#EF4444',
                        textMain: '#1E293B',
                        borderColor: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        heading: ['Poppins', 'sans-serif']
                    },
                    borderRadius: {
                        'premium': '20px'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F8FAFC;
        }

        .font-heading {
            font-family: 'Poppins', sans-serif;
        }

        .premium-transition { 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
        }
        
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }

        /* Medical Grid Background Pattern Overlay */
        .medical-pattern {
            background-image: radial-gradient(#2563eb 0.75px, transparent 0.75px), radial-gradient(#0ea5e9 0.75px, #F8FAFC 0.75px);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            opacity: 0.12;
        }

        /* Scroll Reveal and Fade Animation Subsystems */
        .reveal-section {
            opacity: 0; 
            transform: translateY(20px); 
            will-change: transform, opacity;
            transition: opacity 0.8s cubic-bezier(0.25, 1, 0.5, 1), transform 0.8s cubic-bezier(0.25, 1, 0.5, 1);
        }
        .reveal-section.visible { 
            opacity: 1; 
            transform: translateY(0); 
        }
    </style>
</head>
<body class="text-textMain antialiased min-h-screen flex flex-col pt-[120px] relative overflow-x-hidden">

    <div class="absolute inset-0 medical-pattern pointer-events-none z-0"></div>
    <div class="absolute top-[5%] left-[-5%] w-[450px] h-[450px] bg-secondary/10 rounded-full blur-[130px] pointer-events-none z-0"></div>
    <div class="absolute bottom-[10%] right-[-5%] w-[500px] h-[500px] bg-accent/10 rounded-full blur-[150px] pointer-events-none z-0"></div>

    <div class="bg-danger text-white fixed top-0 left-0 right-0 z-[60] h-[40px] flex items-center text-sm font-medium shadow-sm border-b border-white/10">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <div class="flex items-center gap-6">
                <a href="tel:+15559113940" class="flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91" /></svg>
                    <span class="tracking-wide">Emergency Response: <strong class="font-semibold">+92 3000000000</strong></span>
                </a>
                <a href="mailto:support@mednetwork.org" class="hidden sm:flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    <span>support@mednetwork.org</span>
                </a>
            </div>
            <div class="text-xs tracking-widest uppercase font-semibold opacity-90 hidden md:flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-white animate-pulse"></span> Available 24/7 For Urgent Clinical Response
            </div>
        </div>
    </div>

    <nav class="glass-nav fixed top-[40px] left-0 right-0 z-50 h-[80px] flex items-center border-b border-borderColor premium-transition shadow-sm" id="main-navbar">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-textMain group">
                <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 premium-transition">
                    <svg class="text-primary group-hover:scale-110 premium-transition" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                </div>
                <span class="tracking-tight">Med<span class="text-primary font-extrabold">Network</span></span>
            </a>
            
            <button class="md:hidden flex flex-col justify-between w-6 h-4 bg-transparent border-none cursor-pointer z-50 focus:outline-none" id="mobile-menu-btn" aria-label="Toggle navigation menu">
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar1"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition my-auto" id="bar2"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar3"></span>
            </button>
            
            <ul class="fixed md:static top-[120px] left-[-100%] md:left-0 w-full md:w-auto h-[calc(100vh-120px)] md:h-auto bg-card md:bg-transparent border-t border-borderColor md:border-none flex flex-col md:flex-row items-center pt-8 md:pt-0 gap-6 md:gap-8 premium-transition z-40" id="nav-links-menu">
                <li><a href="index.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Home</a></li>
                <li><a href="services.php" class="text-[15px] font-semibold text-primary block border-b-2 border-primary pb-0.5">Services</a></li>
                <li><a href="doctors.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Our Doctors</a></li>
                <li><a href="about.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">About Us</a></li>
                <li><a href="contact.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Contact</a></li>
                
                <li class="hidden md:block w-px h-5 bg-borderColor mx-1"></li>
                <?php if(isset($_SESSION['patient_email'])): ?>
                    <li class="mt-4 md:mt-0"><a href="appointment.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-sm hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 premium-transition">Book Appointment</a></li>
                    <li><a href="Patient/dashboard.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">My Account</a></li>
                    <li><a href="logout.php" class="text-[15px] text-danger hover:text-red-700 font-semibold premium-transition">Logout</a></li>
                <?php else: ?>
                    <li class="mt-4 md:mt-0"><a href="login.php" class="text-[15px] font-semibold text-textMain/80 hover:text-primary premium-transition py-2 block">Login</a></li>
                    <li class="mt-2 md:mt-0"><a href="register.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-sm">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <main class="flex-grow w-full max-w-[1200px] mx-auto px-6 py-12 relative z-10 reveal-section">
        <div class="bg-card rounded-premium border border-borderColor shadow-xl overflow-hidden">
            
            <div class="h-80 w-full relative bg-textMain">
                <img src="<?php echo htmlspecialchars($img_path); ?>" class="w-full h-full object-cover opacity-75" alt="Clinical Banner Matrix Element">
                <div class="absolute inset-0 bg-gradient-to-t from-textMain via-textMain/40 to-transparent"></div>
                <div class="absolute bottom-8 left-8 right-8 flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
                    <div class="flex items-center gap-4">
                        <div class="w-16 h-16 bg-white/95 backdrop-blur-sm border border-borderColor rounded-xl flex items-center justify-center text-3xl shadow-lg transform hover:scale-105 premium-transition select-none">
                            <?php echo htmlspecialchars($service['icon']); ?>
                        </div>
                        <div>
                            <span class="bg-primary/20 text-primary font-bold text-[10px] tracking-widest px-3 py-1 rounded-md uppercase border border-primary/20"><?php echo htmlspecialchars($service['department_name']); ?></span>
                            <h1 class="text-2xl md:text-4xl font-heading font-extrabold text-white mt-1.5 tracking-tight"><?php echo htmlspecialchars($service['name']); ?></h1>
                        </div>
                    </div>
                    <?php if(isset($_SESSION['patient_email'])): ?>
                        <div class="flex-shrink-0 self-start sm:self-auto">
                            <a href="appointment.php" class="bg-gradient-to-r from-primary to-secondary text-white font-bold px-6 py-3 rounded-xl text-[14px] shadow-lg shadow-primary/20 hover:shadow-primary/30 transform hover:-translate-y-0.5 active:translate-y-0 premium-transition tracking-wide block text-center">Schedule Consultation</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="p-8 md:p-12 space-y-10">
                
                <div class="prose max-w-none">
                    <h2 class="font-heading text-lg font-bold text-textMain mb-4 flex items-center gap-2">
                        <span class="w-1.5 h-5 bg-primary rounded-full"></span>
                        Service Description Overview
                    </h2>
                    <p class="text-textMain/70 text-[15px] leading-relaxed whitespace-pre-line font-light bg-background p-6 rounded-xl border border-borderColor/50"><?php echo htmlspecialchars($service['full_description']); ?></p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="bg-background border border-borderColor p-6 rounded-premium shadow-sm hover:shadow-md premium-transition">
                        <h3 class="font-heading text-md font-bold text-textMain mb-3.5 flex items-center gap-2.5">
                            <span class="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center text-sm">⚙️</span> 
                            How It Works
                        </h3>
                        <p class="text-textMain/60 text-[14px] leading-relaxed whitespace-pre-line font-light"><?php echo htmlspecialchars($service['how_it_works']); ?></p>
                    </div>
                    <div class="bg-background border border-borderColor p-6 rounded-premium shadow-sm hover:shadow-md premium-transition">
                        <h3 class="font-heading text-md font-bold text-textMain mb-3.5 flex items-center gap-2.5">
                            <span class="w-8 h-8 rounded-lg bg-accent/10 text-accent flex items-center justify-center text-sm">💎</span> 
                            Key Benefits
                        </h3>
                        <p class="text-textMain/60 text-[14px] leading-relaxed whitespace-pre-line font-light"><?php echo htmlspecialchars($service['benefits']); ?></p>
                    </div>
                </div>

                <div class="bg-textMain text-white rounded-premium p-6 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden shadow-xl">
                    <div class="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none"></div>
                    <div class="flex items-center gap-4 relative z-10">
                        <div class="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-secondary">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        </div>
                        <div>
                            <div class="text-[10px] font-bold uppercase text-borderColor/40 tracking-widest">Available Timings Vector Matrix</div>
                            <div class="text-md font-bold text-secondary mt-0.5"><?php echo htmlspecialchars($service['timings']); ?></div>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 relative z-10">
                        <span class="w-2.5 h-2.5 rounded-full bg-success animate-pulse"></span>
                        <span class="text-xs uppercase font-bold tracking-wider text-borderColor/60">Clinical Unit Synchronized</span>
                    </div>
                </div>

            </div>
        </div>
    </main>

    <footer class="bg-textMain text-white pt-16 pb-10 border-t border-textMain mt-auto relative z-10 shadow-inner">
        <div class="container mx-auto px-6 max-w-[1200px]">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-10 mb-12">
                <div class="md:col-span-2 space-y-4">
                    <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-white group inline-block">
                        <div class="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
                            <svg class="text-secondary" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                        </div>
                        <span class="tracking-tight">Med<span class="text-secondary font-extrabold">Network</span></span>
                    </a>
                    <p class="text-[14px] text-borderColor/70 max-w-sm leading-relaxed font-light">Providing high-quality clinical operations management tools and professional healthcare networking platforms globally.</p>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Platform</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="index.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Network Modules</a></li>
                        <li><a href="services.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Clinical Services</a></li>
                        <li><a href="doctors.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Doctor Portal</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Resources</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Developer API</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">System Status</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Support Center</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Emergency Contact</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li class="text-danger font-bold tracking-wide flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-danger animate-ping"></span> Hotline: +92 3000000000
                        </li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Terms & Conditions</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="pt-8 border-t border-white/10 text-center text-[13px] text-borderColor/40 tracking-wide">
                &copy; 2026 MedNetwork Systems Inc. All rights reserved. Secure clinical systems architecture verified.
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Mobile responsive layout drawer layout controller
            const menuBtn = document.getElementById("mobile-menu-btn");
            const navMenu = document.getElementById("nav-links-menu");
            const bar1 = document.getElementById("bar1");
            const bar2 = document.getElementById("bar2");
            const bar3 = document.getElementById("bar3");
            
            menuBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                navMenu.classList.toggle("left-0");
                navMenu.classList.toggle("left-[-100%]");
                
                bar1.classList.toggle("rotate-45");
                bar1.classList.toggle("translate-y-1.5");
                bar2.classList.toggle("opacity-0");
                bar3.classList.toggle("-rotate-45");
                bar3.classList.toggle("-translate-y-1.5");
            });

            document.addEventListener("click", function (e) {
                if (!menuBtn.contains(e.target) && !navMenu.contains(e.target)) {
                    navMenu.classList.add("left-[-100%]");
                    navMenu.classList.remove("left-0");
                    bar1.classList.remove("rotate-45", "translate-y-1.5");
                    bar2.classList.remove("opacity-0");
                    bar3.classList.remove("-rotate-45", "-translate-y-1.5");
                }
            });

            // Reactive Scroll Adjustments for Navigation Height
            const navbar = document.getElementById("main-navbar");
            window.addEventListener("scroll", function() {
                if (window.scrollY > 20) {
                    navbar.classList.remove("h-[80px]");
                    navbar.classList.add("h-[70px]", "shadow-md");
                } else {
                    navbar.classList.remove("h-[70px]", "shadow-md");
                    navbar.classList.add("h-[80px]", "shadow-sm");
                }
            }, { passive: true });

            // Scroll Animation Observer Frame
            const scrollSections = document.querySelectorAll(".reveal-section");
            const scrollObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if(entry.isIntersecting) {
                        entry.target.classList.add("visible");
                        scrollObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.05 });

            scrollSections.forEach(section => scrollObserver.observe(section));
        });
    </script>
</body>
</html>