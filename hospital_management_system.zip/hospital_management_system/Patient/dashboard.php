<?php
session_start();
include("../includes/conn.php"); // Consolidated root database connection template context

// Secure Route Gatekeeper
if (!isset($_SESSION['patient_email'])) {
    header("Location: login.php");
    exit();
}

$p_email = mysqli_real_escape_string($conn, $_SESSION['patient_email']);
$p_name = mysqli_real_escape_string($conn, $_SESSION['patient_name']);
$current_page = 'dashboard.php'; // Updated to map to the user dashboard page context

// Multi-Segment Active Display Router
$active_segment = isset($_GET['view']) ? $_GET['view'] : 'overview';

// Core Dashboard Layer Global Analytics Queries
$pending_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM appointment WHERE user_email='$p_email' AND status='Pending'");
$pending_count = mysqli_fetch_assoc($pending_res)['total'];

$complete_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM appointment WHERE user_email='$p_email' AND status='Complete'");
$complete_count = mysqli_fetch_assoc($complete_res)['total'];
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Hub Profile Console | MedNetwork</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        medicalBg: '#F8FAFC',
                        medicalCard: '#FFFFFF',
                        medicalPrimary: '#2563EB',
                        medicalSecondary: '#0EA5E9',
                        medicalAccent: '#14B8A6',
                        medicalSuccess: '#22C55E',
                        medicalWarning: '#F59E0B',
                        medicalDanger: '#EF4444',
                        medicalText: '#1E293B',
                        medicalBorder: '#E2E8F0',
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        heading: ['Poppins', 'sans-serif']
                    },
                    boxShadow: {
                        premium: '0 4px 20px -2px rgba(148, 163, 184, 0.12), 0 2px 8px -1px rgba(148, 163, 184, 0.08)',
                        premiumHover: '0 12px 30px -4px rgba(37, 99, 235, 0.12), 0 4px 12px -2px rgba(37, 99, 235, 0.06)'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@500;600;700&display=swap');
        
        body {
            background-color: #F8FAFC;
            background-image: 
                radial-gradient(at 0% 0%, rgba(14, 165, 233, 0.03) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(20, 184, 166, 0.03) 0px, transparent 50%);
            background-attachment: fixed;
        }

        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #F1F5F9;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #CBD5E1;
            border-radius: 3px;
        }

        /* Nav link border-bottom indicator styles matching design guidelines */
        .nav-link-active {
            color: #2563EB !important;
            font-weight: 600;
        }
        
        /* Hide the print area from screen view */
        #clinicalReceiptPrintArea { display: none; }

        @media print {
            body * { display: none !important; }
            #clinicalReceiptPrintArea, #clinicalReceiptPrintArea * { display: block !important; }
            #clinicalReceiptPrintArea { display: block !important; position: absolute; left: 0; top: 0; width: 100%; color: #000; }
        }
    </style>
</head>
<body class="text-medicalText font-sans antialiased min-h-screen flex flex-col pt-[115px]">

    <div class="bg-gradient-to-r from-medicalDanger to-red-500 text-white fixed top-0 left-0 right-0 z-[60] h-[35px] flex items-center text-xs font-medium shadow-sm">
        <div class="container mx-auto px-6 max-w-[1400px] w-full flex justify-between items-center">
            <div class="flex items-center gap-6">
                <a href="tel:+15559113940" class="flex items-center gap-2 hover:opacity-90 transition-opacity">
                    <i data-lucide="phone" class="w-3.5 h-3.5"></i>
                    <span>Emergency Hotline: <strong>+92 3000000000</strong></span>
                </a>
                <a href="mailto:support@mednetwork.org" class="hidden sm:flex items-center gap-2 hover:opacity-90 transition-opacity">
                    <i data-lucide="mail" class="w-3.5 h-3.5"></i>
                    <span>support@mednetwork.org</span>
                </a>
            </div>
            <div class="tracking-wide text-[10px] uppercase font-semibold opacity-95 hidden md:block">
                <span class="inline-block w-2 h-2 rounded-full bg-white animate-pulse mr-1"></span> Continuous System Security Telemetry Matrix Active
            </div>
        </div>
    </div>

    <nav class="bg-white fixed top-[35px] left-0 right-0 z-50 h-[80px] flex items-center shadow-sm border-b border-medicalBorder transition-all duration-300" id="main-navbar">
        <div class="container mx-auto px-6 max-w-[1400px] w-full flex justify-between items-center">
            <a href="index.php" class="flex items-center gap-3 font-heading text-xl font-bold text-slate-900 group">
                <div class="p-2.5 bg-blue-50 rounded-xl text-medicalPrimary group-hover:scale-105 transition-transform duration-300">
                    <i data-lucide="activity" class="w-6 h-6 stroke-[2.5]"></i>
                </div>
                <span class="tracking-tight text-slate-900">Med<span class="text-medicalPrimary">Network</span></span>
            </a>
            
            <button class="md:hidden flex flex-col justify-between w-6 h-4 bg-transparent border-none cursor-pointer z-50 focus:outline-none" id="mobile-menu-btn" aria-label="Toggle navigation menu">
                <span class="w-full h-0.5 bg-slate-800 rounded transition-all duration-300 origin-left" id="bar1"></span>
                <span class="w-full h-0.5 bg-slate-800 rounded transition-all duration-300 my-auto" id="bar2"></span>
                <span class="w-full h-0.5 bg-slate-800 rounded transition-all duration-300 origin-left" id="bar3"></span>
            </button>
            
            <ul class="fixed md:static top-[115px] left-[-100%] md:left-0 w-full md:w-auto h-[calc(100vh-115px)] md:h-auto bg-white border-t border-medicalBorder md:border-none flex flex-col md:flex-row items-center pt-8 md:pt-0 gap-6 md:gap-7 transition-all duration-300 z-40 shadow-xl md:shadow-none font-sans" id="nav-links-menu">
                <li><a href="../index.php" class="text-[15px] font-medium text-slate-500 hover:text-medicalPrimary transition-colors">Home</a></li>
                <li><a href="../services.php" class="text-[15px] font-medium text-slate-500 hover:text-medicalPrimary transition-colors">Services</a></li>
                <li><a href="../doctors.php" class="text-[15px] font-medium text-slate-500 hover:text-medicalPrimary transition-colors">Our Doctors</a></li>
                <li><a href="../about.php" class="text-[15px] font-medium text-slate-500 hover:text-medicalPrimary transition-colors">About Us</a></li>
                <li><a href="../contact.php" class="text-[15px] font-medium text-slate-500 hover:text-medicalPrimary transition-colors">Contact</a></li>
                
                <li class="hidden md:block h-5 w-[1px] bg-slate-200 mx-1"></li>

                <?php if(isset($_SESSION['patient_email'])): ?>
                    <li class="mt-4 md:mt-0"><a href="../appointment.php" class="text-[14px] bg-gradient-to-r from-blue-600 to-sky-500 hover:shadow-md hover:-translate-y-0.5 text-white font-semibold px-5 py-2.5 rounded-full transition-all duration-200 flex items-center gap-2 shadow-sm"><i data-lucide="calendar" class="w-4 h-4"></i> Book Appointment</a></li>
                    <li><a href="dashboard.php" class="text-[15px] font-medium text-slate-700 hover:text-medicalPrimary transition-colors nav-link-active">My Account</a></li>
                    <li><a href="../logout.php" class="text-[15px] text-red-500 hover:text-red-700 font-medium transition-colors">Logout</a></li>
                <?php else: ?>
                    <li class="mt-4 md:mt-0"><a href="login.php" class="text-[15px] font-medium text-slate-500 hover:text-medicalPrimary transition-colors">Login</a></li>
                    <li class="mt-2 md:mt-0"><a href="register.php" class="text-[14px] bg-gradient-to-r from-blue-600 to-sky-500 text-white font-semibold px-5 py-2.5 rounded-full shadow-sm transition-all hover:shadow-md">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="flex-grow flex flex-col md:flex-row w-full max-w-[1400px] mx-auto px-4 lg:px-6 py-6 gap-6 print:hidden">
        
        <aside class="w-full md:w-64 bg-white border border-medicalBorder rounded-2xl p-4 flex flex-col shrink-0 shadow-premium self-start">
            <div class="p-4 mb-4 border-b border-medicalBorder bg-slate-50/50 rounded-xl flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-medicalPrimary to-medicalSecondary flex items-center justify-center text-white font-bold text-lg shadow-sm">
                    <?php echo strtoupper(substr($_SESSION['patient_name'], 0, 1)); ?>
                </div>
                <div class="min-w-0 flex-1">
                    <p class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Patient Registry</p>
                    <h3 class="text-sm font-bold text-slate-800 truncate mt-0.5"><?php echo htmlspecialchars($_SESSION['patient_name']); ?></h3>
                </div>
            </div>
            <nav class="flex flex-row md:flex-col overflow-x-auto md:overflow-x-visible gap-1.5 custom-scrollbar pb-2 md:pb-0">
                <a href="?view=overview" class="whitespace-nowrap flex items-center gap-2.5 px-4 py-3 rounded-xl font-medium transition-all duration-200 text-xs sm:text-sm <?php echo $active_segment === 'overview' ? 'bg-blue-50 text-medicalPrimary font-bold border border-blue-100 shadow-sm' : 'text-slate-600 hover:bg-slate-50 border border-transparent'; ?>">
                    <i data-lucide="layout-dashboard" class="w-4 h-4 shrink-0"></i>
                    <span>Overview Hub</span>
                </a>
                <a href="?view=appointments" class="whitespace-nowrap flex items-center gap-2.5 px-4 py-3 rounded-xl font-medium transition-all duration-200 text-xs sm:text-sm <?php echo $active_segment === 'appointments' ? 'bg-blue-50 text-medicalPrimary font-bold border border-blue-100 shadow-sm' : 'text-slate-600 hover:bg-slate-50 border border-transparent'; ?>">
                    <i data-lucide="calendar" class="w-4 h-4 shrink-0"></i>
                    <span>My Appointments</span>
                </a>
                <a href="?view=lab_reports" class="whitespace-nowrap flex items-center gap-2.5 px-4 py-3 rounded-xl font-medium transition-all duration-200 text-xs sm:text-sm <?php echo $active_segment === 'lab_reports' ? 'bg-blue-50 text-medicalPrimary font-bold border border-blue-100 shadow-sm' : 'text-slate-600 hover:bg-slate-50 border border-transparent'; ?>">
                    <i data-lucide="flask-conical" class="w-4 h-4 shrink-0"></i>
                    <span>Lab Test Results</span>
                </a>
            </nav>
        </aside>

        <main class="flex-grow flex flex-col min-w-0 w-full">
            
            <?php if ($active_segment === 'overview'): ?>
                <div class="flex-grow flex flex-col justify-between h-full w-full">
                    <div class="space-y-6">
                        <header class="bg-white p-6 rounded-2xl border border-medicalBorder shadow-premium flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                            <div>
                                <h1 class="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mb-1">Welcome Back, <?php echo htmlspecialchars($_SESSION['patient_name']); ?></h1>
                                <p class="text-slate-400 text-xs sm:text-sm">Real-time health ledger network routing module and automated operational tracking nodes.</p>
                            </div>
                            <div class="text-xs font-medium px-3 py-1.5 bg-slate-50 border border-medicalBorder rounded-xl text-slate-500 self-start sm:self-auto flex items-center gap-1.5">
                                <span class="w-2 h-2 rounded-full bg-medicalSuccess"></span> Synced Node Matrix
                            </div>
                        </header>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div class="bg-white border-l-4 border-medicalWarning border-y border-r border-medicalBorder rounded-2xl p-5 shadow-premium flex items-center justify-between group hover:shadow-premiumHover hover:-translate-y-0.5 transition-all duration-300">
                                <div>
                                    <h3 class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-0.5">Awaiting Sequences</h3>
                                    <div class="text-2xl font-bold text-slate-850 tracking-tight"><?php echo $pending_count; ?></div>
                                </div>
                                <div class="p-3 bg-amber-50 text-medicalWarning rounded-xl group-hover:scale-105 transition-transform">
                                    <i data-lucide="clock" class="w-6 h-6"></i>
                                </div>
                            </div>
                            <div class="bg-white border-l-4 border-medicalPrimary border-y border-r border-medicalBorder rounded-2xl p-5 shadow-premium flex items-center justify-between group hover:shadow-premiumHover hover:-translate-y-0.5 transition-all duration-300">
                                <div>
                                    <h3 class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-0.5">Completed Diagnostic Records</h3>
                                    <div class="text-2xl font-bold text-slate-850 tracking-tight"><?php echo $complete_count; ?></div>
                                </div>
                                <div class="p-3 bg-blue-50 text-medicalPrimary rounded-xl group-hover:scale-105 transition-transform">
                                    <i data-lucide="check-circle-2" class="w-6 h-6"></i>
                                </div>
                            </div>
                        </div>

                        <section class="bg-white border border-medicalBorder rounded-2xl shadow-premium overflow-hidden transition-all duration-300">
                            <div class="p-5 border-b border-medicalBorder bg-slate-50/60 flex items-center justify-between flex-wrap gap-2">
                                <div class="flex items-center gap-2">
                                    <div class="p-1.5 bg-blue-100 text-medicalPrimary rounded-lg"><i data-lucide="activity" class="w-4 h-4"></i></div>
                                    <h2 class="text-sm sm:text-base font-bold text-slate-800">Recent Consultation Allocations</h2>
                                </div>
                                <a href="?view=appointments" class="text-xs font-bold text-medicalPrimary hover:text-blue-700 transition flex items-center gap-1">Expand Table Ledger <i data-lucide="arrow-right" class="w-3 h-3"></i></a>
                            </div>
                            <div class="overflow-x-auto w-full custom-scrollbar">
                                <table class="w-full text-left border-collapse min-w-[650px]">
                                    <thead>
                                        <tr class="bg-slate-50/70 text-slate-400 text-[10px] font-bold uppercase border-b border-medicalBorder tracking-wider">
                                            <th class="px-5 py-3">Specialist Consultant</th>
                                            <th class="px-5 py-3">Target Department</th>
                                            <th class="px-5 py-3">Temporal Window</th>
                                            <th class="px-5 py-3">Diagnostic Symptoms</th>
                                            <th class="px-5 py-3">System Status Signature</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-medicalBorder text-xs sm:text-sm text-slate-600">
                                        <?php
                                        $query = "SELECT a.*, d.name AS doc_name, d.department AS doc_dept FROM appointment a INNER JOIN doctors d ON a.doctor_id = d.doctor_id WHERE a.user_email = '$p_email' ORDER BY a.id DESC LIMIT 4";
                                        $res = mysqli_query($conn, $query);
                                        if ($res && mysqli_num_rows($res) > 0) {
                                            while($row = mysqli_fetch_assoc($res)) {
                                                $badge = ($row['status'] === 'Complete') ? 'bg-emerald-50 text-medicalSuccess border-emerald-200' : 'bg-amber-50 text-medicalWarning border-amber-200';
                                                ?>
                                                <tr class="hover:bg-slate-50/40 transition">
                                                    <td class="px-5 py-4 font-semibold text-slate-800">Dr. <?php echo htmlspecialchars($row['doc_name']); ?></td>
                                                    <td class="px-5 py-4 text-slate-500"><?php echo htmlspecialchars($row['doc_dept']); ?></td>
                                                    <td class="px-5 py-4 font-medium text-slate-700"><span class="inline-flex items-center gap-1"><i data-lucide="calendar" class="w-3.5 h-3.5 text-slate-400"></i> <?php echo htmlspecialchars($row['timing']); ?></span></td>
                                                    <td class="px-5 py-4 text-slate-400 max-w-[180px] truncate"><?php echo htmlspecialchars($row['symptom']); ?></td>
                                                    <td class="px-5 py-4"><span class="inline-flex px-2.5 py-1 rounded-lg text-[10px] font-bold border uppercase tracking-wider <?php echo $badge; ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                                                </tr>
                                                <?php
                                            }
                                        } else {
                                            echo '<tr><td colspan="5" class="text-center py-12 text-slate-400"><div class="flex flex-col items-center justify-center gap-2"><i data-lucide="inbox" class="w-8 h-8 text-slate-300"></i><span>No active operational metrics returned from database server.</span></div></td></tr>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                    <div class="mt-8 border-t border-medicalBorder pt-4 text-[10px] tracking-wider font-medium uppercase text-slate-400 text-center flex items-center justify-center gap-2"><i data-lucide="shield-check" class="w-3.5 h-3.5 text-medicalAccent"></i> MedNetwork Security Pipeline Module Operational Block Matrix V2.26</div>
                </div>

            <?php elseif ($active_segment === 'appointments'): ?>
                <div class="flex-grow flex flex-col justify-between h-full w-full">
                    <div class="space-y-6">
                        <header class="bg-white p-6 rounded-2xl border border-medicalBorder shadow-premium flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                            <div>
                                <h1 class="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mb-1">Your Appointment Ledger</h1>
                                <p class="text-slate-400 text-xs sm:text-sm">System parameters tracing architectural deployment times across scheduling queues.</p>
                            </div>
                            <a href="../appointment.php" class="text-xs bg-gradient-to-r from-medicalPrimary to-blue-700 hover:shadow-md text-white font-semibold px-4 py-2.5 rounded-xl transition-all self-start sm:self-auto flex items-center gap-1.5"><i data-lucide="plus-circle" class="w-4 h-4"></i> New Booking Sequence</a>
                        </header>

                        <section class="bg-white border border-medicalBorder rounded-2xl shadow-premium overflow-hidden w-full">
                            <div class="overflow-x-auto w-full custom-scrollbar">
                                <table class="w-full text-left border-collapse min-w-[750px]">
                                    <thead>
                                        <tr class="bg-slate-50/70 text-slate-400 text-[10px] font-bold uppercase border-b border-medicalBorder tracking-wider">
                                            <th class="px-5 py-3">Faculty Node</th>
                                            <th class="px-5 py-3">Department Vector</th>
                                            <th class="px-5 py-3">Execution Sequence Slot</th>
                                            <th class="px-5 py-3">Contact Parameter</th>
                                            <th class="px-5 py-3">Symptom Manifesto</th>
                                            <th class="px-5 py-3">Processing Signature</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-medicalBorder text-xs sm:text-sm text-slate-600">
                                        <?php
                                        $query = "SELECT a.*, d.name AS doc_name, d.department AS doc_dept FROM appointment a INNER JOIN doctors d ON a.doctor_id = d.doctor_id WHERE a.user_email = '$p_email' ORDER BY a.id DESC";
                                        $res = mysqli_query($conn, $query);
                                        if ($res && mysqli_num_rows($res) > 0) {
                                            while($row = mysqli_fetch_assoc($res)) {
                                                $badge = ($row['status'] === 'Complete') ? 'bg-emerald-50 text-medicalSuccess border-emerald-200' : 'bg-amber-50 text-medicalWarning border-amber-200';
                                                ?>
                                                <tr class="hover:bg-slate-50/40 transition">
                                                    <td class="px-5 py-4 font-semibold text-slate-800">Dr. <?php echo htmlspecialchars($row['doc_name']); ?></td>
                                                    <td class="px-5 py-4 text-slate-500"><?php echo htmlspecialchars($row['doc_dept']); ?></td>
                                                    <td class="px-5 py-4 font-medium text-slate-700"><span class="inline-flex items-center gap-1"><i data-lucide="calendar" class="w-3.5 h-3.5 text-slate-400"></i> <?php echo htmlspecialchars($row['timing']); ?></span></td>
                                                    <td class="px-5 py-4 font-mono text-slate-500 text-xs"><?php echo htmlspecialchars($row['contact']); ?></td>
                                                    <td class="px-5 py-4"><div class="max-w-[180px] text-slate-400 truncate"><?php echo htmlspecialchars($row['symptom']); ?></div></td>
                                                    <td class="px-5 py-4"><span class="inline-flex px-2.5 py-1 rounded-lg text-[10px] font-bold border uppercase tracking-wider <?php echo $badge; ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                                                </tr>
                                                <?php
                                            }
                                        } else {
                                            echo '<tr><td colspan="6" class="text-center py-16 text-slate-400"><div class="flex flex-col items-center justify-center gap-2"><i data-lucide="calendar-x" class="w-10 h-10 text-slate-300"></i><span>No scheduled healthcare allocations mapped under this token matrix profile.</span></div></td></tr>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                    <div class="mt-8 border-t border-medicalBorder pt-4 text-[10px] tracking-wider font-medium uppercase text-slate-400 text-center">Data encryption parameters synced globally with clinical infrastructure frameworks.</div>
                </div>

            <?php elseif ($active_segment === 'lab_reports'): ?>
                <div class="flex-grow flex flex-col justify-between h-full w-full">
                    <div class="space-y-6">
                        <header class="bg-white p-6 rounded-2xl border border-medicalBorder shadow-premium">
                            <h1 class="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mb-1">Laboratory Diagnostic Profiles</h1>
                            <p class="text-slate-400 text-xs sm:text-sm">Verified clinical records securely captured internally via core diagnostic telemetry protocols.</p>
                        </header>

                        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start w-full">
                            
                            <div class="lg:col-span-4 space-y-3 w-full">
                                <h3 class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1"><i data-lucide="folder-heart" class="w-3.5 h-3.5"></i> Released Biological Logs</h3>
                                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3">
                                <?php
                                $query = "SELECT lr.*, d.name AS ordering_doctor, d.department AS doc_dept
                                          FROM lab_report lr
                                          LEFT JOIN doctors d ON lr.doctor_id = d.doctor_id
                                          WHERE lr.user_email = '$p_email'
                                          ORDER BY lr.report_id DESC";
                                $res = mysqli_query($conn, $query);
                                $reports = [];
                                if ($res && mysqli_num_rows($res) > 0) {
                                    $idx = 0;
                                    while($row = mysqli_fetch_assoc($res)) {
                                        $reports[] = $row;
                                        $isActive = (isset($_GET['report_id']) && intval($_GET['report_id']) === intval($row['report_id'])) || (!isset($_GET['report_id']) && $idx === 0);
                                        ?>
                                        <a href="?view=lab_reports&report_id=<?php echo $row['report_id']; ?>" class="block p-4 rounded-xl border transition-all duration-200 <?php echo $isActive ? 'bg-gradient-to-br from-slate-900 to-slate-800 text-white border-slate-950 shadow-md translate-x-1' : 'bg-white border-medicalBorder text-slate-700 hover:border-slate-300 hover:bg-slate-50/50 shadow-sm'; ?>">
                                            <div class="flex justify-between items-center mb-2">
                                                <span class="text-[9px] font-bold uppercase px-2 py-0.5 rounded <?php echo $isActive ? 'bg-medicalPrimary text-white' : 'bg-slate-100 text-slate-500'; ?>">ID-#<?php echo $row['report_id']; ?></span>
                                                <span class="text-[10px] <?php echo $isActive ? 'text-slate-300' : 'text-slate-400'; ?> font-medium flex items-center gap-1"><i data-lucide="clock" class="w-3 h-3"></i> <?php echo htmlspecialchars($row['test_date']); ?></span>
                                            </div>
                                            <h4 class="font-bold truncate text-sm"><?php echo htmlspecialchars($row['test_name']); ?></h4>
                                            <p class="text-xs mt-1.5 opacity-80 truncate flex items-center gap-1"><i data-lucide="user" class="w-3 h-3"></i> Spec: Dr. <?php echo htmlspecialchars($row['ordering_doctor'] ?? 'Unassigned'); ?></p>
                                        </a>
                                        <?php
                                        $idx++;
                                    }
                                } else {
                                    echo '<div class="col-span-full text-center py-12 text-slate-400 border border-dashed border-medicalBorder rounded-2xl text-xs sm:text-sm bg-white flex flex-col items-center justify-center gap-2"><i data-lucide="flask-conical" class="w-8 h-8 text-slate-300"></i> No analysis profiles mapped inside database arrays.</div>';
                                }
                                ?>
                                </div>
                            </div>

                            <div class="lg:col-span-8 w-full">
                                <?php
                                $selected_report_id = isset($_GET['report_id']) ? intval($_GET['report_id']) : (isset($reports[0]['report_id']) ? $reports[0]['report_id'] : 0);
                                $active_report = null;
                                foreach($reports as $r) {
                                    if(intval($r['report_id']) === $selected_report_id) { $active_report = $r; break; }
                                }

                                if($active_report):
                                    ?>
                                    <div class="bg-white border border-medicalBorder rounded-2xl p-5 sm:p-6 relative shadow-premium w-full transition-all duration-300">
                                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-medicalBorder pb-4 mb-5">
                                            <div>
                                                <span class="text-[9px] font-bold text-medicalPrimary uppercase tracking-widest block mb-0.5">Active Stream Display Scope</span>
                                                <h2 class="text-lg sm:text-xl font-bold text-slate-900 tracking-tight"><?php echo htmlspecialchars($active_report['test_name']); ?></h2>
                                            </div>
                                            <button onclick="window.print()" class="sm:self-center bg-gradient-to-r from-slate-900 to-slate-800 hover:from-slate-800 hover:to-slate-700 text-white font-semibold text-xs px-4 py-2.5 rounded-xl shadow transition-all flex items-center justify-center gap-1.5 self-start sm:self-auto hover:-translate-y-0.5">
                                                <i data-lucide="printer" class="w-3.5 h-3.5"></i>
                                                Print Document
                                            </button>
                                        </div>

                                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs mb-6 bg-slate-50/70 p-4 rounded-xl border border-medicalBorder">
                                            <div><span class="text-slate-400 block text-[9px] font-bold uppercase mb-0.5 tracking-wider">Subject Matrix Node</span><strong class="text-slate-700 font-semibold text-sm"><?php echo htmlspecialchars($active_report['patient_name']); ?></strong></div>
                                            <div><span class="text-slate-400 block text-[9px] font-bold uppercase mb-0.5 tracking-wider">Authorization Timestamp</span><strong class="text-slate-700 font-semibold text-sm"><?php echo htmlspecialchars($active_report['test_date']); ?></strong></div>
                                            <div><span class="text-slate-400 block text-[9px] font-bold uppercase mb-0.5 tracking-wider">Ordering Clinical Director</span><strong class="text-slate-700 font-semibold text-sm">Dr. <?php echo htmlspecialchars($active_report['ordering_doctor'] ?? 'Unassigned'); ?> (<?php echo htmlspecialchars($active_report['doc_dept'] ?? 'General'); ?>)</strong></div>
                                            <div><span class="text-slate-400 block text-[9px] font-bold uppercase mb-0.5 tracking-wider">Secure Transaction Index</span><strong class="font-mono text-slate-500 bg-white px-2 py-0.5 rounded border border-medicalBorder text-[11px]">LR-REQUISITION-<?php echo $active_report['report_id']; ?></strong></div>
                                        </div>

                                        <h3 class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2.5 flex items-center gap-1"><i data-lucide="bar-chart-3" class="w-3.5 h-3.5"></i> Metrics Spectrum Range Findings</h3>
                                        <div class="overflow-hidden border border-medicalBorder rounded-xl bg-white mb-6 w-full">
                                            <table class="w-full text-left border-collapse min-w-[400px]">
                                                <thead>
                                                    <tr class="bg-slate-50/70 text-slate-500 font-bold text-[10px] uppercase border-b border-medicalBorder tracking-wider">
                                                        <th class="px-4 py-3">Parameter Metric</th>
                                                        <th class="px-4 py-3">Result Findings</th>
                                                        <th class="px-4 py-3">Standard Threshold Range</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="text-xs sm:text-sm divide-y divide-medicalBorder">
                                                    <tr class="hover:bg-slate-50/30">
                                                        <td class="px-4 py-4 font-medium text-slate-800"><?php echo htmlspecialchars($active_report['test_name']); ?> Factor</td>
                                                        <td class="px-4 py-4 font-mono font-bold text-medicalPrimary bg-blue-50/30 text-base"><?php echo htmlspecialchars($active_report['test_results']); ?></td>
                                                        <td class="px-4 py-4 text-slate-500 font-medium"><?php echo htmlspecialchars($active_report['normal_range']); ?></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <h3 class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1"><i data-lucide="signature" class="w-3.5 h-3.5"></i> Practitioner Analysis Signature Statement</h3>
                                        <div class="p-4 bg-slate-50 border border-medicalBorder rounded-xl text-xs sm:text-sm italic text-slate-600 leading-relaxed flex gap-2">
                                            <span class="text-2xl text-slate-300 font-serif leading-none">“</span>
                                            <span>Biomedical indices monitored during session context <?php echo htmlspecialchars($active_report['test_date']); ?> correspond within standard operational vectors for clinical documentation.</span>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="border border-dashed border-medicalBorder rounded-2xl flex flex-col items-center justify-center p-12 text-center bg-white shadow-premium">
                                        <div class="p-4 bg-slate-50 text-slate-400 rounded-full mb-3">
                                            <i data-lucide="file-question" class="w-8 h-8"></i>
                                        </div>
                                        <p class="text-slate-500 font-medium text-sm">Please select an isolated analytics report from the directory menu mapping.</p>
                                    </div>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                    <div class="mt-8 border-t border-medicalBorder pt-4 text-[10px] tracking-wider font-medium uppercase text-slate-400 text-center">Encryption standard checks: 256-bit active framework authentication enabled.</div>
                </div>

            <?php endif; ?>

        </main>
    </div>

    <?php if($active_segment === 'lab_reports' && $active_report): ?>
        <div id="clinicalReceiptPrintArea" style="font-family: 'Inter', sans-serif; padding: 40px; color: #1E293B;">
            <div style="text-align: center; border-bottom: 3px solid #2563EB; padding-bottom: 20px; margin-bottom: 30px;">
                <h1 style="font-size: 28px; font-weight: 800; margin: 0; color: #1E293B; letter-spacing: -0.5px;">MEDNETWORK CLINICAL LAB FINDINGS</h1>
                <p style="margin: 6px 0 0 0; font-size: 11px; color: #64748B; text-transform: uppercase; tracking-wider; font-weight: 600;">Verified Patient Profile Registry System Token Document</p>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 35px; font-size: 13px; background: #F8FAFC; padding: 20px; border-radius: 12px; border: 1px solid #E2E8F0;">
                <div><span style="color: #64748B; font-size: 11px; text-transform: uppercase; font-weight: 700; display: block; margin-bottom: 2px;">Subject Profile Node Name</span><strong><?php echo htmlspecialchars($active_report['patient_name']); ?></strong></div>
                <div><span style="color: #64748B; font-size: 11px; text-transform: uppercase; font-weight: 700; display: block; margin-bottom: 2px;">System Records Identity</span><strong><?php echo htmlspecialchars($p_email); ?></strong></div>
                <div style="margin-top: 8px;"><span style="color: #64748B; font-size: 11px; text-transform: uppercase; font-weight: 700; display: block; margin-bottom: 2px;">Ordering Staff Consultant</span><strong>Dr. <?php echo htmlspecialchars($active_report['ordering_doctor'] ?? 'Unassigned'); ?></strong></div>
                <div style="margin-top: 8px;"><span style="color: #64748B; font-size: 11px; text-transform: uppercase; font-weight: 700; display: block; margin-bottom: 2px;">Clinical Registry Timestamp</span><strong><?php echo htmlspecialchars($active_report['test_date']); ?></strong></div>
            </div>
            
            <h3 style="font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #E2E8F0; padding-bottom: 6px; margin-bottom: 15px; color: #1E293B;">METRIC SPECTRUM VALUE LOGS</h3>
            <table style="width: 100%; text-align: left; border-collapse: collapse; font-size: 13px; margin-bottom: 35px;">
                <thead>
                    <tr style="background: #F1F5F9; color: #475569;">
                        <th style="padding: 12px 14px; border: 1px solid #E2E8F0; font-weight: 700; text-transform: uppercase; font-size: 10px;">Testing Specification Vector Field</th>
                        <th style="padding: 12px 14px; border: 1px solid #E2E8F0; font-weight: 700; text-transform: uppercase; font-size: 10px;">Output Metrics</th>
                        <th style="padding: 12px 14px; border: 1px solid #E2E8F0; font-weight: 700; text-transform: uppercase; font-size: 10px;">Baseline Normalized Range</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="padding: 14px; border: 1px solid #E2E8F0; font-weight: 600; color: #1E293B;"><?php echo htmlspecialchars($active_report['test_name']); ?></td>
                        <td style="padding: 14px; border: 1px solid #E2E8F0; font-weight: 700; color: #2563EB; font-size: 15px; font-family: monospace; background: #EFF6FF;"><?php echo htmlspecialchars($active_report['test_results']); ?></td>
                        <td style="padding: 14px; border: 1px solid #E2E8F0; color: #334155; font-weight: 500;"><?php echo htmlspecialchars($active_report['normal_range']); ?></td>
                    </tr>
                </tbody>
            </table>
            
            <div style="margin-top: 40px; padding: 16px; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; font-style: italic; font-size: 12px; color: #475569; line-height: 1.6;">
                "Biomedical indices monitored during session context <?php echo htmlspecialchars($active_report['test_date']); ?> correspond within standard operational vectors for clinical documentation."
            </div>

            <div style="text-align: center; margin-top: 80px; font-size: 10px; color: #94A3B8; border-top: 1px solid #E2E8F0; padding-top: 15px; text-transform: uppercase; font-weight: 600; letter-spacing: 0.5px;">
                Automated clinical data matrix generation protocol. Verification security block integrity maintained.
            </div>
        </div>
    <?php endif; ?>

    <footer class="bg-[#0F172A] text-slate-400 pt-16 pb-10 mt-auto border-t border-slate-900 print:hidden">
        <div class="container mx-auto px-6 max-w-[1400px]">
            <div class="grid grid-cols-1 md:grid-cols-5 gap-10 mb-12">
                <div class="md:col-span-2 space-y-4">
                    <h3 class="font-heading text-xl font-bold text-white flex items-center gap-2">
                        <div class="p-1.5 bg-blue-600/20 text-medicalSecondary rounded-lg">
                            <i data-lucide="activity" class="w-5 h-5"></i>
                        </div>
                        Med<span class="text-medicalPrimary">Network</span>
                    </h3>
                    <p class="text-sm text-slate-400 max-w-sm leading-relaxed">Providing high-quality clinical operations management tools and professional healthcare networking platforms globally.</p>
                </div>
                <div>
                    <h4 class="font-heading text-xs font-bold tracking-wider text-medicalAccent uppercase mb-4">Platform</h4>
                    <ul class="space-y-3 text-sm">
                        <li><a href="index.php" class="hover:text-white transition-colors">Network Modules</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Clinical Services</a></li>
                        <li><a href="doctors.php" class="hover:text-white transition-colors">Doctor Portal</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-xs font-bold tracking-wider text-medicalAccent uppercase mb-4">Resources</h4>
                    <ul class="space-y-3 text-sm">
                        <li><a href="#" class="hover:text-white transition-colors">Developer API</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">System Status</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Support Center</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-xs font-bold tracking-wider text-medicalAccent uppercase mb-4">Emergency Contact</h4>
                    <ul class="space-y-3 text-sm">
                        <li class="text-medicalDanger font-semibold flex items-center gap-1"><span class="inline-block w-2 h-2 rounded-full bg-medicalDanger animate-ping"></span> Hotline: +92 3000000000</li>
                        <li><a href="#" class="hover:text-white transition-colors">Terms & Conditions</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="pt-8 border-t border-slate-800 text-center text-xs text-slate-500 font-medium tracking-wide">
                &copy; 2026 MedNetwork Systems Inc. All rights reserved. Secure clinical systems architecture verified.
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Initialize lucide icons
            lucide.createIcons();

            const menuBtn = document.getElementById("mobile-menu-btn");
            const navMenu = document.getElementById("nav-links-menu");
            const bar1 = document.getElementById("bar1");
            const bar2 = document.getElementById("bar2");
            const bar3 = document.getElementById("bar3");
            
            menuBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                navMenu.classList.toggle("left-0");
                navMenu.classList.toggle("left-[-100%]");
                
                bar1.classList.toggle("rotate-45");
                bar1.classList.toggle("translate-y-1.5");
                bar2.classList.toggle("opacity-0");
                bar3.classList.toggle("-rotate-45");
                bar3.classList.toggle("-translate-y-1.5");
            });

            document.addEventListener("click", function (e) {
                if (!menuBtn.contains(e.target) && !navMenu.contains(e.target)) {
                    navMenu.classList.add("left-[-100%]");
                    navMenu.classList.remove("left-0");
                    bar1.classList.remove("rotate-45", "translate-y-1.5");
                    bar2.classList.remove("opacity-0");
                    bar3.classList.remove("-rotate-45", "-translate-y-1.5");
                }
            });

            const navbar = document.getElementById("main-navbar");
            window.addEventListener("scroll", function() {
                if (window.scrollY > 20) {
                    navbar.classList.remove("h-[80px]");
                    navbar.classList.add("h-[70px]", "shadow-md");
                } else {
                    navbar.classList.remove("h-[70px]", "shadow-md");
                    navbar.classList.add("h-[80px]", "shadow-sm");
                }
            }, { passive: true });
        });
    </script>
</body>
</html>