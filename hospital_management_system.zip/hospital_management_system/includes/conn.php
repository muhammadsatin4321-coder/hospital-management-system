<?php
/*$host = "sql300.infinityfree.com";
$user = "if0_42370558";
$pass = ""; // Replace with your actual InfinityFree password
$db   = "if0_42370558_hospital_management_system";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}*/
$host = "localhost";
$user = "root";
$pass = ""; // Replace with your actual InfinityFree password
$db   = "hospital_management_system";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>