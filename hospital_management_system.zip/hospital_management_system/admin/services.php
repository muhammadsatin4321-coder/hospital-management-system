<?php
session_start();
ob_start();
include("../includes/conn.php"); // Path checking vector mapping out of admin module

// Authentication Gatekeeper Matrix
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$msg = "";
$edit_mode = false;
$edit_data = [
    'id' => '', 'name' => '', 'short_description' => '', 'full_description' => '',
    'how_it_works' => '', 'benefits' => '', 'timings' => '', 'department_name' => '',
    'icon' => '🩺', 'status' => 'Active', 'image_url' => ''
];

/* ==========================================
   1. OPERATION: DELETE SERVICE ARTIFACT
   ========================================== */
if (isset($_GET['delete'])) {
    $del_id = intval($_GET['delete']);
    // Fetch file pointer to purge storage footprint if required
    $img_res = mysqli_query($conn, "SELECT image_url FROM Services WHERE id = $del_id");
    if($img_row = mysqli_fetch_assoc($img_res)) {
        if(!empty($img_row['image_url']) && $img_row['image_url'] != 'uploads/default.png' && file_exists('../' . $img_row['image_url'])) {
            unlink('../' . $img_row['image_url']);
        }
    }
    if (mysqli_query($conn, "DELETE FROM Services WHERE id = $del_id")) {
        header("Location: services.php?success=Service layer permanently removed from the system registry.");
        exit();
    }
}

/* ==========================================
   2. OPERATION: POST PROCESSOR (ADD / UPDATE)
   ========================================== */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_service'])) {
    $id = intval($_POST['service_id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $short_desc = mysqli_real_escape_string($conn, $_POST['short_description']);
    $full_desc = mysqli_real_escape_string($conn, $_POST['full_description']);
    $how_it_works = mysqli_real_escape_string($conn, $_POST['how_it_works']);
    $benefits = mysqli_real_escape_string($conn, $_POST['benefits']);
    $timings = mysqli_real_escape_string($conn, $_POST['timings']);
    $dept_name = mysqli_real_escape_string($conn, $_POST['department_name']);
    $icon = mysqli_real_escape_string($conn, $_POST['icon']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    
    // File Upload Handler Module Mapping
    $image_url = !empty($_POST['existing_image']) ? $_POST['existing_image'] : "uploads/default.png";
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "../uploads/";
        if (!file_exists($target_dir)) { mkdir($target_dir, 0777, true); }
        $file_name = time() . "_" . basename($_FILES["image"]["name"]);
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir . $file_name)) {
            $image_url = "uploads/" . $file_name;
        }
    }

    if ($id > 0) {
        // Dynamic Update Router Matrix Elements
        $sql = "UPDATE Services SET name='$name', short_description='$short_desc', full_description='$full_desc', 
                how_it_works='$how_it_works', benefits='$benefits', timings='$timings', department_name='$dept_name', 
                icon='$icon', image_url='$image_url', status='$status' WHERE id=$id";
        $action = "configuration updated successfully!";
    } else {
        // Dynamic Insert Registry Vector Entry
        $sql = "INSERT INTO Services (name, short_description, full_description, how_it_works, benefits, timings, department_name, icon, image_url, status) 
                VALUES ('$name', '$short_desc', '$full_desc', '$how_it_works', '$benefits', '$timings', '$dept_name', '$icon', '$image_url', '$status')";
        $action = "compiled to the ecosystem registry successfully!";
    }

    if (mysqli_query($conn, $sql)) {
        header("Location: services.php?success=Service module " . urlencode($action));
        exit();
    } else {
        $msg = "Operational network failure error: " . mysqli_error($conn);
    }
}

/* ==========================================
   3. OPERATION: LOAD TARGET ROW INTO EDIT MODE
   ========================================== */
if (isset($_GET['edit'])) {
    $edit_id = intval($_GET['edit']);
    $edit_res = mysqli_query($conn, "SELECT * FROM Services WHERE id = $edit_id");
    if ($row = mysqli_fetch_assoc($edit_res)) {
        $edit_mode = true;
        $edit_data = $row;
    }
}

if(isset($_GET['success'])) { $msg = htmlspecialchars($_GET['success']); }
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth h-full bg-[#F8FAFC]">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinical Care Hub - Services Matrix Control Console</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        lightBg: '#F8FAFC',       
                        cardWhite: '#FFFFFF',     
                        brandBlue: '#2563EB',     
                        brandSky: '#0EA5E9',
                        brandTeal: '#14B8A6', 
                        successGreen: '#22C55E',  
                        warningAmber: '#F59E0B', 
                        dangerRed: '#EF4444',     
                        slateText: '#1E293B',
                        borderGray: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'Plus Jakarta Sans', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;600;700&display=swap');
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #F1F5F9; }
        ::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #94A3B8; }
        
        .medical-canvas-underlay {
            position: absolute; top: 0; left: 0; right: 0; height: 450px;
            background: radial-gradient(circle at 15% 15%, rgba(37, 99, 237, 0.04) 0%, transparent 65%);
            z-index: 0; pointer-events: none;
        }
        .hover-lift { transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.25s ease; }
        .hover-lift:hover { transform: translateY(-4px); box-shadow: 0 16px 24px -8px rgba(37, 99, 237, 0.08); }
        .gradient-border-glow { position: relative; border-radius: 1rem; }
        .gradient-border-glow::before {
            content: ''; position: absolute; inset: -1px; border-radius: 1rem;
            background: linear-gradient(135deg, #2563EB10, #14B8A610, transparent);
            z-index: -1; pointer-events: none;
        }
        .animate-fade-in {
            animation: fadeIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="bg-lightBg text-slateText font-sans antialiased min-h-screen flex relative overflow-x-hidden selection:bg-blue-50 selection:text-brandBlue">

    <div class="medical-canvas-underlay"></div>

    <aside class="w-[280px] bg-white border-r border-borderGray/90 flex flex-col py-8 px-6 fixed top-0 bottom-0 left-0 h-screen z-50 shadow-sm">
        <h2 class="text-xl font-extrabold tracking-tight text-slate-900 mb-10 pl-2 flex items-center gap-3 select-none">
            <div class="p-2.5 bg-brandBlue/10 rounded-xl text-brandBlue shadow-sm shadow-blue-600/5">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
            <span>MED<span class="text-brandBlue">CORE</span></span>
        </h2>
        
        <nav class="flex flex-col gap-1.5 flex-grow overflow-y-auto pr-1">
            <a href="index.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9"></rect><rect x="14" y="3" width="7" height="5"></rect><rect x="14" y="12" width="7" height="9"></rect><rect x="3" y="16" width="7" height="5"></rect></svg>
                Dashboard Hub
            </a>
            <a href="doctors.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg>
                Doctors Panel
            </a>
            <a href="patients.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                Patients Registry
            </a>
            <a href="appointments.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                Appointments Matrix
            </a>
            <a href="departments.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path></svg>
                Departments
            </a>
            <a href="feedback.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                Feedback Logs
            </a>
            <a href="services.php" class="flex items-center gap-3 py-3 px-4 bg-brandBlue text-white font-semibold text-[14px] rounded-xl shadow-md shadow-brandBlue/20">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg>
                Services Matrix
            </a>
            <a href="logout.php" class="group flex items-center gap-3 py-3 px-4 text-dangerRed hover:bg-red-50 font-bold text-[14px] rounded-xl mt-auto transition-all duration-150">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline></svg>
                Sign Out Engine
            </a>
        </nav>
    </aside>

    <main class="ml-[280px] p-6 lg:p-10 w-[calc(100%-280px)] min-h-screen flex flex-col relative z-10 min-w-0">
        
        <header class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8 pb-4 border-b border-borderGray/60">
            <div>
                <nav class="flex items-center gap-1.5 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    <span>MedCore</span> <span>&middot;</span> <span class="text-brandBlue">Ecosystem Services</span>
                </nav>
                <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">Services Dynamic Matrix</h1>
            </div>
            
            <div class="flex flex-wrap items-center gap-4 w-full md:w-auto">
                <a href="../services.php" target="_blank" class="text-xs bg-white hover:bg-slate-50 text-slate-800 font-bold px-4 py-2.5 rounded-xl border border-borderGray shadow-sm transition-all duration-150">
                    View Live Page ↗
                </a>
                
                <div class="flex items-center gap-3 bg-white border border-borderGray p-2 rounded-xl text-xs font-bold text-slate-700 shadow-sm">
                    <span id="liveChronometerNode" class="text-brandBlue font-mono">00:00:00 AM</span>
                    <span class="text-borderGray">|</span>
                    <span class="text-slate-500"><?php echo date('M d, Y'); ?></span>
                </div>
            </div>
        </header>

        <?php if (!empty($msg)): ?>
            <div id="toast-success-banner" class="bg-successGreen/10 border border-successGreen/30 text-successGreen px-5 py-4 rounded-xl text-sm font-medium mb-8 flex items-center justify-between shadow-sm animate-fade-in">
                <div class="flex items-center gap-2.5">
                    <div class="p-1 bg-successGreen text-white rounded-full">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    </div>
                    <span><?php echo $msg; ?></span>
                </div>
                <button onclick="document.getElementById('toast-success-banner').style.display='none'" class="text-successGreen/70 hover:text-successGreen font-bold">✕</button>
            </div>
        <?php endif; ?>

        <div class="bg-white border border-borderGray rounded-2xl p-6 lg:p-8 shadow-sm animate-fade-in mb-8 gradient-border-glow">
            <div class="flex items-center gap-2 pb-4 border-b border-slate-100 mb-6 select-none">
                <span class="w-1.5 h-4 bg-brandBlue rounded-full"></span>
                <h3 class="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    <?php echo $edit_mode ? 'Modify Selected Service Module Details' : 'Construct New Service Registry Component'; ?>
                </h3>
            </div>

            <form action="services.php" method="POST" enctype="multipart/form-data" class="flex flex-col gap-5">
                <input type="hidden" name="service_id" value="<?php echo $edit_data['id']; ?>">
                <input type="hidden" name="existing_image" value="<?php echo $edit_data['image_url']; ?>">

                <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
                    <div class="flex flex-col gap-1.5">
                        <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 pl-1">Service / Module Name</label>
                        <input type="text" name="name" required value="<?php echo htmlspecialchars($edit_data['name']); ?>" 
                               class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-800 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all">
                    </div>

                    <div class="flex flex-col gap-1.5">
                        <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 pl-1">Department Categorization Mapping</label>
                        <input type="text" name="department_name" value="<?php echo htmlspecialchars($edit_data['department_name']); ?>" placeholder="e.g. Cardiology" 
                               class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-800 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div class="flex flex-col gap-1.5">
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 text-center">Emoji Symbol</label>
                            <input type="text" name="icon" required value="<?php echo htmlspecialchars($edit_data['icon']); ?>" 
                                   class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-800 text-center outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all">
                        </div>
                        <div class="flex flex-col gap-1.5">
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 pl-1">Framework Status</label>
                            <select name="status" class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-700 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all cursor-pointer">
                                <option value="Active" <?php echo $edit_data['status']=='Active'?'selected':''; ?>>Active (Live)</option>
                                <option value="Inactive" <?php echo $edit_data['status']=='Inactive'?'selected':''; ?>>Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div class="flex flex-col gap-1.5">
                        <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 pl-1">Operational Short Description (Grid View Cards)</label>
                        <textarea name="short_description" required rows="2" 
                                  class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all resize-none"><?php echo htmlspecialchars($edit_data['short_description']); ?></textarea>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="flex flex-col gap-1.5">
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 pl-1">Available Operational Timings</label>
                            <input type="text" name="timings" value="<?php echo htmlspecialchars($edit_data['timings']); ?>" placeholder="e.g. 09:00 AM - 05:00 PM" 
                                   class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-800 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all">
                        </div>
                        <div class="flex flex-col gap-1.5">
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 pl-1">Showcase Image Asset Upload</label>
                            <input type="file" name="image" 
                                   class="w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:text-[10px] file:font-bold file:bg-blue-50 file:text-brandBlue hover:file:bg-blue-100 transition duration-150 cursor-pointer border border-dashed border-borderGray rounded-xl p-1 bg-slate-50/20">
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-5 pt-4 border-t border-slate-100">
                    <div class="flex flex-col gap-1.5">
                        <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 pl-1">Full Detailed Overview Narrative</label>
                        <textarea name="full_description" rows="4" placeholder="Detailed structural analysis description mapping vector parameters..." 
                                  class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all"><?php echo htmlspecialchars($edit_data['full_description']); ?></textarea>
                    </div>

                    <div class="flex flex-col gap-1.5">
                        <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 pl-1">How It Works Operations (Step Lines)</label>
                        <textarea name="how_it_works" rows="4" placeholder="1. Action Vector Step One&#10;2. Action Vector Step Two" 
                                  class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all"><?php echo htmlspecialchars($edit_data['how_it_works']); ?></textarea>
                    </div>

                    <div class="flex flex-col gap-1.5">
                        <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 pl-1">Clinical Key Benefits Matrix</label>
                        <textarea name="benefits" rows="4" placeholder="• Dynamic Performance Lift One&#10;• Operational Integrity Element Two" 
                                  class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all"><?php echo htmlspecialchars($edit_data['benefits']); ?></textarea>
                    </div>
                </div>

                <div class="flex justify-end gap-3 pt-4 border-t border-slate-100 mt-1">
                    <?php if($edit_mode): ?>
                        <a href="services.php" class="bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition duration-150">Cancel Revision</a>
                    <?php endif; ?>
                    <button type="submit" name="save_service" class="bg-brandBlue hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all duration-150 shadow-md shadow-brandBlue/10 cursor-pointer">
                        <?php echo $edit_mode ? 'Update Infrastructure Asset' : 'Compile Service to Registry'; ?>
                    </button>
                </div>
            </form>
        </div>

        <div class="w-full bg-white border border-borderGray rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between animate-fade-in">
            <div>
                <div class="p-5 border-b border-slate-100 bg-slate-50 select-none flex items-center justify-between">
                    <h3 class="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                        <span class="w-1.5 h-3.5 bg-brandTeal rounded-full"></span> Institutional System Architecture Ledgers
                    </h3>
                    <span class="text-[10px] font-bold text-slate-400 bg-white border border-slate-100 px-2 py-0.5 rounded-lg select-none">Live Service Layers</span>
                </div>
                
                <div class="overflow-x-auto w-full">
                    <table class="w-full border-collapse text-left text-xs">
                        <thead>
                            <tr class="bg-slate-50 border-b border-borderGray text-slate-400 font-bold text-[10px] uppercase tracking-wider select-none">
                                <th class="p-4 pl-6 w-32">Image Mapping</th>
                                <th class="p-4">Service Layer Title</th>
                                <th class="p-4">Department Name</th>
                                <th class="p-4">Status Flag</th>
                                <th class="p-4 text-right pr-6 w-[170px]">Action Layer</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 text-slate-700 font-medium">
                            <?php
                            $grid_query = "SELECT * FROM Services ORDER BY id DESC";
                            $grid_res = mysqli_query($conn, $grid_query);
                            
                            if($grid_res && mysqli_num_rows($grid_res) > 0) {
                                while($item = mysqli_fetch_assoc($grid_res)) {
                                    $tbl_img = (!empty($item['image_url']) && file_exists('../' . $item['image_url'])) ? '../' . $item['image_url'] : '../uploads/default.png';
                                    ?>
                                    <tr class="hover:bg-slate-50/40 transition-colors">
                                        <td class="p-4 pl-6">
                                            <div class="w-16 h-10 rounded-xl overflow-hidden bg-slate-50 border border-slate-200/50 flex items-center justify-center p-0.5 shadow-2xs">
                                                <img src="<?php echo htmlspecialchars($tbl_img); ?>" class="w-full h-full object-cover rounded-lg" alt="Asset reference">
                                            </div>
                                        </td>
                                        <td class="p-4 font-bold text-slate-900">
                                            <span class="mr-1.5 text-base inline-block"><?php echo htmlspecialchars($item['icon']); ?></span>
                                            <?php echo htmlspecialchars($item['name']); ?>
                                        </td>
                                        <td class="p-4 text-slate-500 font-mono text-[11px]">
                                            <?php echo htmlspecialchars($item['department_name'] ?? 'Unassigned'); ?>
                                        </td>
                                        <td class="p-4">
                                            <span class="bg-teal-50 text-brandTeal border border-teal-100 px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide">
                                                <?php echo htmlspecialchars($item['status']); ?>
                                            </span>
                                        </td>
                                        <td class="p-4 text-right pr-6">
                                            <div class="flex items-center justify-end gap-3 font-bold">
                                                <a href="services.php?edit=<?php echo $item['id']; ?>" class="text-brandBlue hover:text-blue-700 hover:underline transition duration-150">Edit</a>
                                                <span class="text-slate-200 select-none">|</span>
                                                <a href="services.php?delete=<?php echo $item['id']; ?>" 
                                                   onclick="return confirm('Purge this dynamic service node configuration securely from database?');" 
                                                   class="text-dangerRed hover:text-red-700 hover:underline transition duration-150">Purge</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                echo '<tr><td colspan="5" class="text-center text-slate-400 py-16 bg-white text-xs">No entries indexed inside the dataset engine.</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        setInterval(() => {
            const timeNode = document.getElementById('liveChronometerNode');
            if (timeNode) {
                timeNode.innerText = new Date().toLocaleTimeString();
            }
        }, 1000);
    });
    </script>
</body>
</html>