<?php
session_start();
ob_start();
include("../includes/conn.php");

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch general dashboard metrics
$doctors_count      = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM doctors"));
$patients_count     = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM patients"));
$appointments_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM appointment"));
$departments_count  = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM departments"));

// Get available years from the 'created_at' field for the dropdown filter
$years_query = mysqli_query($conn, "SELECT DISTINCT YEAR(created_at) as app_year FROM appointment ORDER BY app_year DESC");
$available_years = [];
while ($yr_row = mysqli_fetch_assoc($years_query)) {
    if (!empty($yr_row['app_year'])) {
        $available_years[] = $yr_row['app_year'];
    }
}
// Default to current year (2026) if database is empty
if (empty($available_years)) {
    $available_years[] = 2026;
}

/* ====================================================
   AJAX ENDPOINT: FETCH DATA FOR A SPECIFIC SELECTED YEAR
==================================================== */
if (isset($_POST['fetch_year'])) {
    $selected_year = intval($_POST['fetch_year']);
    $monthly_metrics_array = array_fill(0, 12, 0); // 12 elements for Jan-Dec

    $metrics_query = "SELECT MONTH(created_at) as app_month, COUNT(*) as month_total 
                      FROM appointment 
                      WHERE YEAR(created_at) = $selected_year 
                      GROUP BY MONTH(created_at)";
                      
    $metrics_result = mysqli_query($conn, $metrics_query);
    if ($metrics_result) {
        while ($row = mysqli_fetch_assoc($metrics_result)) {
            $month_index = intval($row['app_month']) - 1; // 1-based to 0-based
            if ($month_index >= 0 && $month_index < 12) {
                $monthly_metrics_array[$month_index] = intval($row['month_total']);
            }
        }
    }
    
    echo json_encode($monthly_metrics_array);
    exit();
}

// Default initial load data calculation (using the most recent available year)
$initial_selected_year = $available_years[0];
$default_monthly_metrics_array = array_fill(0, 12, 0);

$default_metrics_query = "SELECT MONTH(created_at) as app_month, COUNT(*) as month_total 
                          FROM appointment 
                          WHERE YEAR(created_at) = $initial_selected_year 
                          GROUP BY MONTH(created_at)";
                          
$default_metrics_result = mysqli_query($conn, $default_metrics_query);
if ($default_metrics_result) {
    while ($row = mysqli_fetch_assoc($default_metrics_result)) {
        $month_index = intval($row['app_month']) - 1;
        if ($month_index >= 0 && $month_index < 12) {
            $default_monthly_metrics_array[$month_index] = intval($row['month_total']);
        }
    }
}

// Diagnostic system query logs for new dynamic components using existing datasets
$recent_appointments = mysqli_query($conn, "SELECT * FROM appointment ORDER BY id DESC LIMIT 5");
$recent_patients = mysqli_query($conn, "SELECT * FROM patients ORDER BY id DESC LIMIT 5");
$recent_doctors = mysqli_query($conn, "SELECT * FROM doctors ORDER BY id DESC LIMIT 5");

// Summary stats queries
$stat_pending = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM appointment WHERE status='Pending'"));
$stat_completed = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM appointment WHERE status='Complete'"));
$stat_cancelled = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM appointment WHERE status='Cancelled'"));
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth h-full bg-[#F8FAFC]">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinical Care Core - Premium Operational Registry</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        lightBg: '#F8FAFC',       
                        cardWhite: '#FFFFFF',     
                        brandBlue: '#2563EB',     
                        brandSky: '#0EA5E9',
                        brandTeal: '#14B8A6', 
                        successGreen: '#22C55E',  
                        warningAmber: '#F59E0B', 
                        dangerRed: '#EF4444',     
                        slateText: '#1E293B',
                        borderGray: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'Plus Jakarta Sans', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;600;700&display=swap');
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #F1F5F9; }
        ::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 4px; }
        .medical-canvas-underlay {
            position: absolute; top: 0; left: 0; right: 0; height: 450px;
            background: radial-gradient(circle at 15% 15%, rgba(37, 99, 237, 0.04) 0%, transparent 65%);
            z-index: 0; pointer-events: none;
        }
        .hover-lift { transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.25s ease; }
        .hover-lift:hover { transform: translateY(-4px); box-shadow: 0 16px 24px -8px rgba(37, 99, 237, 0.08); }
        .gradient-border-glow { position: relative; border-radius: 1rem; }
        .gradient-border-glow::before {
            content: ''; position: absolute; inset: -1px; border-radius: 1rem;
            background: linear-gradient(135deg, #2563EB10, #0EA5E910, transparent);
            z-index: -1; pointer-events: none;
        }
        @media print {
            aside, header, form, .quick-actions-grid, .no-print { display: none !important; }
            main { margin-left: 0 !important; width: 100% !important; padding: 0 !important; }
            .print-full-card { border: none !important; shadow: none !important; }
        }
    </style>
</head>
<body class="bg-lightBg text-slateText font-sans antialiased min-h-screen flex relative overflow-x-hidden">

    <div class="medical-canvas-underlay"></div>

    <aside class="w-[280px] bg-white border-r border-borderGray/90 flex flex-col py-8 px-6 fixed top-0 bottom-0 left-0 h-screen z-50 shadow-sm">
        <h2 class="text-xl font-extrabold tracking-tight text-slate-900 mb-10 pl-2 flex items-center gap-3 select-none">
            <div class="p-2.5 bg-brandBlue/10 rounded-xl text-brandBlue shadow-sm shadow-blue-600/5">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
            <span>MED<span class="text-brandBlue">CORE</span></span>
        </h2>
        
        <nav class="flex flex-col gap-1.5 flex-grow overflow-y-auto pr-1">
            <a href="index.php" class="flex items-center gap-3 py-3 px-4 bg-brandBlue text-white font-semibold text-[14px] rounded-xl shadow-md shadow-brandBlue/20">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9"></rect><rect x="14" y="3" width="7" height="5"></rect><rect x="14" y="12" width="7" height="9"></rect><rect x="3" y="16" width="7" height="5"></rect></svg>
                Dashboard Hub
            </a>
            <a href="doctors.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg>
                Doctors Panel
            </a>
            <a href="patients.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                Patients Registry
            </a>
            <a href="appointments.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                Appointments
            </a>
            <a href="departments.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path></svg>
                Departments
            </a>
            <a href="feedback.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                Feedback
            </a>
            <a href="services.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon></svg>
                Services
            </a>
            <a href="logout.php" class="group flex items-center gap-3 py-3 px-4 text-dangerRed hover:bg-red-50 font-bold text-[14px] rounded-xl mt-auto transition-all duration-150">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline></svg>
                Sign Out Engine
            </a>
        </nav>
    </aside>

    <main class="ml-[280px] p-6 lg:p-10 w-[calc(100%-280px)] min-h-screen flex flex-col relative z-10 min-w-0">
        
        <header class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8 pb-4 border-b border-borderGray/60 class-no-print">
            <div>
                <nav class="flex items-center gap-1.5 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    <span>MedCore</span> <span>&middot;</span> <span class="text-brandBlue">Clinical Analytics</span>
                </nav>
                <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
                    Systems Control Registry
                </h1>
            </div>
            
            <div class="flex flex-wrap items-center gap-4 w-full md:w-auto">
                <div class="relative flex-grow md:flex-grow-0 min-w-[220px]">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    </span>
                    <input type="text" placeholder="Global system lookup..." class="w-full pl-9 pr-4 py-2 bg-white border border-borderGray rounded-xl text-xs outline-none focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all">
                </div>
                
                <div class="flex items-center gap-3 bg-white border border-borderGray p-2 rounded-xl text-xs font-bold text-slate-700 shadow-sm">
                    <span id="liveChronometerNode" class="text-brandBlue font-mono">00:00:00 AM</span>
                    <span class="text-borderGray">|</span>
                    <span class="text-slate-500"><?php echo date('M d, Y'); ?></span>
                </div>

                <div class="flex items-center gap-2 border-l pl-2 border-borderGray">
                    <button class="p-2 bg-white border border-borderGray text-slate-400 hover:text-brandBlue rounded-xl relative shadow-sm">
                        <span class="absolute top-1 right-1 w-2 h-2 bg-brandBlue rounded-full"></span>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                    </button>
                    <div class="w-8 h-8 bg-brandBlue text-white font-bold rounded-xl flex items-center justify-center text-xs shadow-md shadow-brandBlue/20">A</div>
                </div>
            </div>
        </header>

        <div class="mb-8 p-8 rounded-2xl bg-white border border-borderGray shadow-sm relative overflow-hidden flex flex-col gap-1 justify-center gradient-border-glow">
            <div class="absolute -right-12 -top-12 w-64 h-64 bg-brandBlue/5 rounded-full blur-3xl pointer-events-none"></div>
            <h4 class="text-[10px] font-bold text-brandBlue tracking-widest uppercase">System Analytics Infrastructure</h4>
            <h2 class="text-2xl font-black text-slate-900 tracking-tight">Clinical Infrastructure Node Overview</h2>
            <p class="text-slate-500 text-xs max-w-xl mt-1 leading-relaxed">
                Track dynamic operational metrics, audit registry data vectors, and trace real-time appointment pipelines instantaneously.
            </p>
            <div class="flex flex-wrap gap-2 mt-4 no-print">
                <button onclick="window.print()" class="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-sm">Print Dashboard</button>
                <a href="appointments.php" class="bg-brandBlue/10 hover:bg-brandBlue text-brandBlue hover:text-white font-bold text-xs px-4 py-2 rounded-xl transition-all">Appointments Registry Matrix</a>
            </div>
        </div>

        <section class="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Active Staff</p>
                        <h3 class="text-xl font-black text-slate-900 mt-1"><?php echo $doctors_count; ?> Physicians</h3>
                    </div>
                    <div class="p-3 bg-blue-50 rounded-xl text-brandBlue"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-brandBlue h-full rounded-full" style="width: 75%"></div></div>
            </div>
            
            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">System Ledger</p>
                        <h3 class="text-xl font-black text-slate-900 mt-1"><?php echo $patients_count; ?> Patients</h3>
                    </div>
                    <div class="p-3 bg-sky-50 rounded-xl text-brandSky"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-brandSky h-full rounded-full" style="width: 60%"></div></div>
            </div>

            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Bookings Node</p>
                        <h3 class="text-xl font-black text-slate-900 mt-1"><?php echo $appointments_count; ?> Slots</h3>
                    </div>
                    <div class="p-3 bg-teal-50 rounded-xl text-brandTeal"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="10" x2="21" y2="10"></line></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-brandTeal h-full rounded-full" style="width: 85%"></div></div>
            </div>

            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Medical Units</p>
                        <h3 class="text-xl font-black text-slate-900 mt-1"><?php echo $departments_count; ?> Depts</h3>
                    </div>
                    <div class="p-3 bg-amber-50 rounded-xl text-warningAmber"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-warningAmber h-full rounded-full" style="width: 45%"></div></div>
            </div>
        </section>

        <div class="w-full bg-white border border-borderGray rounded-2xl p-6 lg:p-8 shadow-sm mb-8 print-full-card">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-6 border-b border-slate-100 mb-6 select-none">
                <div class="flex items-center gap-2">
                    <span class="w-1.5 h-4 bg-brandBlue rounded-full"></span>
                    <h3 class="text-sm font-bold text-slate-900">System Booking Velocity & Period Distribution</h3>
                </div>
                
                <div class="flex items-center gap-2.5 no-print">
                    <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Matrix Timeline Vector:</label>
                    <div class="relative min-w-[140px]">
                        <select id="yearFilter" class="w-full pl-4 pr-10 py-2 bg-slate-50 border border-borderGray rounded-xl text-xs font-bold text-slate-800 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all cursor-pointer appearance-none">
                            <?php foreach ($available_years as $yr): ?>
                                <option value="<?php echo $yr; ?>"><?php echo $yr; ?> Fiscal</option>
                            <?php endforeach; ?>
                        </select>
                        <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </div>
                    </div>
                </div>
            </div>

            <div class="relative w-full min-h-[320px] flex items-center justify-center p-2">
                <canvas id="dashboardPerformanceChart" class="w-full transition-opacity duration-300 max-h-[380px]"></canvas>
            </div>
        </div>

        <div class="mb-8 quick-actions-grid no-print">
            <h3 class="text-xs font-bold text-slate-400 uppercase mb-4 tracking-wider flex items-center gap-2">
                <span class="w-1 h-3 bg-brandSky rounded-full"></span> Shortcuts Center Node
            </h3>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                <a href="doctors.php?action=add" class="bg-white border border-borderGray p-4 rounded-xl text-center shadow-sm hover-lift flex flex-col items-center justify-center gap-2 group">
                    <div class="p-2.5 bg-blue-50 rounded-lg text-brandBlue group-hover:bg-brandBlue group-hover:text-white transition-all"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg></div>
                    <span class="text-xs font-bold text-slate-800">Add Doctor</span>
                </a>
                <a href="patients.php?action=add" class="bg-white border border-borderGray p-4 rounded-xl text-center shadow-sm hover-lift flex flex-col items-center justify-center gap-2 group">
                    <div class="p-2.5 bg-sky-50 rounded-lg text-brandSky group-hover:bg-brandSky group-hover:text-white transition-all"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/></svg></div>
                    <span class="text-xs font-bold text-slate-800">Add Patient</span>
                </a>
                <a href="appointments.php" class="bg-white border border-borderGray p-4 rounded-xl text-center shadow-sm hover-lift flex flex-col items-center justify-center gap-2 group">
                    <div class="p-2.5 bg-teal-50 rounded-lg text-brandTeal group-hover:bg-brandTeal group-hover:text-white transition-all"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect></svg></div>
                    <span class="text-xs font-bold text-slate-800">Appointments</span>
                </a>
                <a href="departments.php" class="bg-white border border-borderGray p-4 rounded-xl text-center shadow-sm hover-lift flex flex-col items-center justify-center gap-2 group">
                    <div class="p-2.5 bg-amber-50 rounded-lg text-warningAmber group-hover:bg-warningAmber group-hover:text-white transition-all"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path></svg></div>
                    <span class="text-xs font-bold text-slate-800">Departments</span>
                </a>
                <a href="services.php" class="bg-white border border-borderGray p-4 rounded-xl text-center shadow-sm hover-lift flex flex-col items-center justify-center gap-2 group">
                    <div class="p-2.5 bg-rose-50 rounded-lg text-dangerRed group-hover:bg-dangerRed group-hover:text-white transition-all"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon></svg></div>
                    <span class="text-xs font-bold text-slate-800">Services</span>
                </a>
                <button onclick="window.print()" class="bg-white border border-borderGray p-4 rounded-xl text-center shadow-sm hover-lift flex flex-col items-center justify-center gap-2 group w-full">
                    <div class="p-2.5 bg-slate-50 rounded-lg text-slate-600 group-hover:bg-slate-900 group-hover:text-white transition-all"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/></svg></div>
                    <span class="text-xs font-bold text-slate-800">Reports Engine</span>
                </button>
            </div>
        </div>

        <div class="grid grid-cols-1 xl:grid-cols-3 gap-8">
            
            <div class="xl:col-span-2 bg-white border border-borderGray rounded-2xl shadow-sm overflow-hidden flex flex-col justify-between">
                <div>
                    <div class="p-5 border-b border-slate-100 flex items-center justify-between">
                        <h3 class="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                            <span class="w-1.5 h-3.5 bg-brandBlue rounded-full"></span> Recent Pipeline Slots
                        </h3>
                        <a href="appointments.php" class="text-brandBlue font-bold text-xs hover:underline no-print">View Matrix</a>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs border-collapse">
                            <thead>
                                <tr class="bg-slate-50 text-slate-400 font-bold border-b border-borderGray uppercase tracking-wider">
                                    <th class="p-4">Ticket</th>
                                    <th class="p-4">Patient</th>
                                    <th class="p-4">Physician ID</th>
                                    <th class="p-4">Department</th>
                                    <th class="p-4">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 text-slate-700 font-medium">
                                <?php if (mysqli_num_rows($recent_appointments) > 0): ?>
                                    <?php while($row = mysqli_fetch_assoc($recent_appointments)): ?>
                                        <tr class="hover:bg-slate-50/50 transition-colors">
                                            <td class="p-4 text-brandBlue font-bold">#<?php echo $row['id']; ?></td>
                                            <td class="p-4 font-bold text-slate-900"><?php echo htmlspecialchars($row['patient_name']); ?></td>
                                            <td class="p-4"><span class="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-[10px] font-bold">Doc-<?php echo $row['doctor_id']; ?></span></td>
                                            <td class="p-4 text-brandSky font-bold uppercase"><?php echo htmlspecialchars($row['department']); ?></td>
                                            <td class="p-4">
                                                <span class="px-2 py-0.5 rounded-full text-[9px] font-black border uppercase <?php echo ($row['status']=='Complete')?'bg-green-50 text-successGreen border-green-100':'bg-amber-50 text-warningAmber border-amber-100'; ?>">
                                                    <?php echo $row['status']; ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="5" class="p-8 text-center text-slate-400">No appointments logged inside clinical systems data rows.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="bg-white border border-borderGray rounded-2xl p-5 shadow-sm flex flex-col justify-between">
                <div>
                    <div class="pb-4 border-b border-slate-100 mb-4">
                        <h3 class="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                            <span class="w-1.5 h-3.5 bg-brandTeal rounded-full"></span> Status Allocation Node
                        </h3>
                    </div>
                    
                    <div class="flex flex-col gap-3.5">
                        <div class="flex items-center justify-between border-b pb-2">
                            <span class="text-xs font-medium text-slate-500">Pending Approvals</span>
                            <span class="bg-amber-50 border border-amber-200 text-warningAmber text-xs font-extrabold px-2.5 py-0.5 rounded-lg"><?php echo $stat_pending; ?></span>
                        </div>
                        <div class="flex items-center justify-between border-b pb-2">
                            <span class="text-xs font-medium text-slate-500">Completed Operations</span>
                            <span class="bg-green-50 border border-green-200 text-successGreen text-xs font-extrabold px-2.5 py-0.5 rounded-lg"><?php echo $stat_completed; ?></span>
                        </div>
                        <div class="flex items-center justify-between border-b pb-2">
                            <span class="text-xs font-medium text-slate-500">Purged/Cancelled Records</span>
                            <span class="bg-red-50 border border-red-200 text-dangerRed text-xs font-extrabold px-2.5 py-0.5 rounded-lg"><?php echo $stat_cancelled; ?></span>
                        </div>
                    </div>

                    <div class="mt-6">
                        <h4 class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Recent Registry Feeds</h4>
                        <div class="flex flex-col gap-3 text-xs">
                            <div class="flex items-start gap-2 border-l-2 border-brandBlue pl-2">
                                <div><p class="font-bold text-slate-900">Database Connection Secured</p><span class="text-[10px] text-slate-400">System Ledger Synced</span></div>
                            </div>
                            <div class="flex items-start gap-2 border-l-2 border-brandTeal pl-2">
                                <div><p class="font-bold text-slate-900">Fiscal Analytics Vector Active</p><span class="text-[10px] text-slate-400">Chart Pipeline Standing By</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        const ctx = document.getElementById('dashboardPerformanceChart').getContext('2d');
        
        // Initial backend compiled parameters matrix array
        const serverDefaultMetrics = <?php echo json_encode($default_monthly_metrics_array); ?>;

        const chartConfig = {
            type: 'line',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                datasets: [{
                    label: 'Calculated Active Bookings',
                    data: serverDefaultMetrics,
                    borderColor: '#2563EB', // brandBlue implementation
                    backgroundColor: 'rgba(37, 99, 237, 0.03)',
                    borderWidth: 3.5,
                    pointBackgroundColor: '#FFFFFF',
                    pointBorderColor: '#0EA5E9', 
                    pointBorderWidth: 2.5,
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    pointHoverBackgroundColor: '#2563EB',
                    pointHoverBorderColor: '#FFFFFF',
                    tension: 0.35,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { color: '#64748B', font: { family: 'Inter', weight: 600, size: 11 } }
                    },
                    y: {
                        grid: { color: '#F1F5F9' },
                        ticks: { color: '#64748B', font: { family: 'Inter', weight: 600, size: 11 }, precision: 0 },
                        beginAtZero: true
                    }
                }
            }
        };

        const operationalChartInstance = new Chart(ctx, chartConfig);

        // Async Data-Router Interface Endpoint Interaction Matrix
        document.getElementById('yearFilter').addEventListener('change', function () {
            document.getElementById('dashboardPerformanceChart').style.opacity = 0.4;
            
            const selectedYear = this.value;
            const formData = new FormData();
            formData.append('fetch_year', selectedYear);

            fetch('index.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(freshMetricsArray => {
                operationalChartInstance.data.datasets[0].data = freshMetricsArray;
                operationalChartInstance.update();
                document.getElementById('dashboardPerformanceChart').style.opacity = 1;
            })
            .catch(err => {
                console.error("Database structural response error: ", err);
                document.getElementById('dashboardPerformanceChart').style.opacity = 1;
            });
        });

        // Live Clock Element Logic
        setInterval(() => {
            const timeNode = document.getElementById('liveChronometerNode');
            if (timeNode) {
                timeNode.innerText = new Date().toLocaleTimeString();
            }
        }, 1000);
    });
    </script>
</body>
</html>