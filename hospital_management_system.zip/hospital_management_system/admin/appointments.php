<?php
session_start();
ob_start();
include("../includes/conn.php");

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$msg = "";

/* --- 1. UPDATE STATUS OPERATION --- */
if (isset($_GET['complete'])) {
    $id = intval($_GET['complete']);
    $update_query = "UPDATE appointment SET status='Complete' WHERE id=$id";
    
    if (mysqli_query($conn, $update_query)) {
        header("Location: appointments.php?success=1");
        exit();
    } else {
        $msg = "Error updating database ledger: " . mysqli_error($conn);
    }
}

/* --- 2. DELETE OPERATION --- */
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $delete_query = "DELETE FROM appointment WHERE id=$id";
    
    if (mysqli_query($conn, $delete_query)) {
        header("Location: appointments.php?success=2");
        exit();
    } else {
        $msg = "Error purging record: " . mysqli_error($conn);
    }
}

// Success feedback alerts router
if (isset($_GET['success'])) {
    if ($_GET['success'] == 1) $msg = "Appointment status updated to Complete successfully!";
    if ($_GET['success'] == 2) $msg = "Appointment record was permanently removed from the system registry.";
}

/* --- SANITIZED SYSTEM FILTERS CONFIGURATION --- */
$filter_dept = isset($_GET['filter_department']) ? mysqli_real_escape_string($conn, $_GET['filter_department']) : "";
$filter_doctor = isset($_GET['filter_doctor']) ? mysqli_real_escape_string($conn, $_GET['filter_doctor']) : "";
$filter_status = isset($_GET['filter_status']) ? mysqli_real_escape_string($conn, $_GET['filter_status']) : "";
$filter_date = isset($_GET['filter_date']) ? mysqli_real_escape_string($conn, $_GET['filter_date']) : "";
$search_term = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : "";

$current_year = date('Y');
$current_month = date('m');
$filter_month = isset($_GET['filter_month']) ? mysqli_real_escape_string($conn, $_GET['filter_month']) : $current_month;
$filter_year = isset($_GET['filter_year']) ? mysqli_real_escape_string($conn, $_GET['filter_year']) : $current_year;

/* --- INTERACTIVE AJAX DATE INSPECTOR ENDPOINT --- */
if (isset($_GET['get_appointments_by_date'])) {
    ob_end_clean();
    header('Content-Type: application/json');
    $target_date = mysqli_real_escape_string($conn, $_GET['get_appointments_by_date']);
    
    $ajax_query = "SELECT id, patient_name, department, doctor_id, timing, status FROM appointment WHERE appointment_date = '$target_date' ORDER BY timing ASC";
    $ajax_res = mysqli_query($conn, $ajax_query);
    
    $appointments = [];
    if ($ajax_res) {
        while ($row = mysqli_fetch_assoc($ajax_res)) {
            $appointments[] = $row;
        }
    }
    echo json_encode($appointments);
    exit();
}

/* --- COMPREHENSIVE REUSABLE SQL CONDITION BUILDER --- */
$where_clauses = array();
if (!empty($filter_dept)) $where_clauses[] = "department = '$filter_dept'";
if (!empty($filter_doctor)) $where_clauses[] = "doctor_id = '$filter_doctor'";
if (!empty($filter_status)) $where_clauses[] = "status = '$filter_status'";
if (!empty($filter_date)) $where_clauses[] = "appointment_date = '$filter_date'";
if (!empty($search_term)) {
    $where_clauses[] = "(patient_name LIKE '%$search_term%' OR id LIKE '%$search_term%' OR contact LIKE '%$search_term%' OR user_email LIKE '%$search_term%')";
}
$where_str = !empty($where_clauses) ? " WHERE " . implode(" AND ", $where_clauses) : "";

/* --- LIVE STATS COUNTER ENGINES --- */
function getCount($conn, $status = '') {
    $q = "SELECT COUNT(*) as total FROM appointment";
    if (!empty($status)) {
        $q .= " WHERE status = '$status'";
    }
    $res = mysqli_query($conn, $q);
    return ($res) ? mysqli_fetch_assoc($res)['total'] : 0;
}

$total_all = getCount($conn);
$total_pending = getCount($conn, 'Pending');
$total_completed = getCount($conn, 'Complete');
$total_cancelled = getCount($conn, 'Cancelled');
$total_approved = getCount($conn, 'Approved');
$total_rescheduled = getCount($conn, 'Rescheduled');

$today_date = date('Y-m-d');
$today_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM appointment WHERE appointment_date = '$today_date'");
$total_today = ($today_res) ? mysqli_fetch_assoc($today_res)['total'] : 0;

// Resolve Available System Fiscal Years dynamically
$available_years = [$current_year];
$yr_res = mysqli_query($conn, "SELECT DISTINCT YEAR(appointment_date) as yr FROM appointment ORDER BY yr DESC");
if ($yr_res && mysqli_num_rows($yr_res) > 0) {
    $available_years = [];
    while($yr_row = mysqli_fetch_assoc($yr_res)) {
        if (!empty($yr_row['yr'])) $available_years[] = $yr_row['yr'];
    }
}
if (empty($available_years)) { $available_years[] = $current_year; }

/* --- DYNAMIC CALENDAR ENGINE COMPILATION --- */
$days_in_month = cal_days_in_month(CAL_GREGORIAN, $filter_month, $filter_year);
$calendar_data = array_fill(1, $days_in_month, ['total' => 0, 'pending' => 0, 'completed' => 0]);

$cal_query = "SELECT DAY(appointment_date) as day_num, status, COUNT(*) as qty 
              FROM appointment 
              WHERE MONTH(appointment_date) = '$filter_month' AND YEAR(appointment_date) = '$filter_year' 
              GROUP BY DAY(appointment_date), status";
$cal_res = mysqli_query($conn, $cal_query);
if ($cal_res) {
    while ($r = mysqli_fetch_assoc($cal_res)) {
        $d = (int)$r['day_num'];
        if (isset($calendar_data[$d])) {
            $calendar_data[$d]['total'] += $r['qty'];
            if ($r['status'] === 'Pending') $calendar_data[$d]['pending'] += $r['qty'];
            if ($r['status'] === 'Complete') $calendar_data[$d]['completed'] += $r['qty'];
        }
    }
}

/* --- EXCEL/CSV DATASTREAM EXPORT EXECUTOR --- */
if (isset($_GET['export']) && ($_GET['export'] === 'excel' || $_GET['export'] === 'csv')) {
    ob_end_clean();
    $filename = "Clinical_Registry_Export_" . date('Y-m-d_H-i-s');
    
    if ($_GET['export'] === 'excel') {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $filename . '.xls"');
        echo "<table border='1' style='font-family:sans-serif;'>";
        echo "<tr style='background-color:#2563EB;color:#FFFFFF;font-weight:bold;'>";
        echo "<th>Appointment ID</th><th>Patient Name</th><th>Contact</th><th>Email</th><th>Doctor ID</th><th>Department</th><th>Date</th><th>Time Slot</th><th>Status</th>";
        echo "</tr>";
        $exp_res = mysqli_query($conn, "SELECT * FROM appointment $where_str ORDER BY id DESC");
        while ($row = mysqli_fetch_assoc($exp_res)) {
            echo "<tr><td>#".$row['id']."</td><td>".htmlspecialchars($row['patient_name'])."</td><td>".htmlspecialchars($row['contact'])."</td><td>".htmlspecialchars($row['user_email'])."</td><td>Doc-".htmlspecialchars($row['doctor_id'])."</td><td>".htmlspecialchars($row['department'])."</td><td>".htmlspecialchars($row['appointment_date'])."</td><td>".htmlspecialchars($row['timing'])."</td><td>".htmlspecialchars($row['status'])."</td></tr>";
        }
        echo "</table>";
    } else {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        $output = fopen('php://output', 'w');
        fputcsv($output, array('Appointment ID', 'Patient Name', 'Contact', 'Email', 'Doctor ID', 'Department', 'Date', 'Time Slot', 'Status'));
        $exp_res = mysqli_query($conn, "SELECT * FROM appointment $where_str ORDER BY id DESC");
        while ($row = mysqli_fetch_assoc($exp_res)) {
            fputcsv($output, array($row['id'], $row['patient_name'], $row['contact'], $row['user_email'], $row['doctor_id'], $row['department'], $row['appointment_date'], $row['timing'], $row['status']));
        }
        fclose($output);
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth h-full bg-[#F8FAFC]">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinical Care Hub - Premium Appointment Management System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        lightBg: '#F8FAFC',       
                        cardWhite: '#FFFFFF',     
                        brandBlue: '#2563EB',     
                        brandSky: '#0EA5E9',
                        brandTeal: '#14B8A6', 
                        successGreen: '#22C55E',  
                        warningAmber: '#F59E0B', 
                        dangerRed: '#EF4444',     
                        slateText: '#1E293B',
                        borderGray: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'Plus Jakarta Sans', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;600;700&display=swap');
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #F1F5F9; }
        ::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 4px; }
        .medical-canvas-underlay {
            position: absolute; top: 0; left: 0; right: 0; height: 450px;
            background: radial-gradient(circle at 15% 15%, rgba(37, 99, 237, 0.04) 0%, transparent 65%);
            z-index: 0; pointer-events: none;
        }
        .hover-lift { transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.25s ease; }
        .hover-lift:hover { transform: translateY(-4px); box-shadow: 0 16px 24px -8px rgba(37, 99, 237, 0.08); }
        .gradient-border-glow { position: relative; border-radius: 1rem; }
        .gradient-border-glow::before {
            content: ''; position: absolute; inset: -1px; border-radius: 1rem;
            background: linear-gradient(135deg, #2563EB10, #0EA5E910, transparent);
            z-index: -1; pointer-events: none;
        }
        @media print {
            aside, header, form, .no-print, .actions-bar-node { display: none !important; }
            main { margin-left: 0 !important; width: 100% !important; padding: 0 !important; }
            .print-receipt-area, .print-receipt-area * { visibility: visible; }
            .print-receipt-area { position: absolute; left: 0; top: 0; width: 100%; padding: 40px; }
        }
    </style>
</head>
<body class="bg-lightBg text-slateText font-sans antialiased min-h-screen flex relative overflow-x-hidden">

    <div class="medical-canvas-underlay"></div>

    <aside class="w-[280px] bg-white border-r border-borderGray/90 flex flex-col py-8 px-6 fixed top-0 bottom-0 left-0 h-screen z-50 shadow-sm">
        <h2 class="text-xl font-extrabold tracking-tight text-slate-900 mb-10 pl-2 flex items-center gap-3 select-none">
            <div class="p-2.5 bg-brandBlue/10 rounded-xl text-brandBlue shadow-sm shadow-blue-600/5">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
            <span>MED<span class="text-brandBlue">CORE</span></span>
        </h2>
        <nav class="flex flex-col gap-1.5 flex-grow overflow-y-auto pr-1">
            <a href="index.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9"></rect><rect x="14" y="3" width="7" height="5"></rect><rect x="14" y="12" width="7" height="9"></rect><rect x="3" y="16" width="7" height="5"></rect></svg>
                Dashboard Hub
            </a>
            <a href="doctors.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg>
                Doctors Panel
            </a>
            <a href="patients.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                Patients Registry
            </a>
            <a href="appointments.php" class="flex items-center gap-3 py-3 px-4 bg-brandBlue text-white font-semibold text-[14px] rounded-xl shadow-md shadow-brandBlue/20">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                Appointments Matrix
            </a>
            <a href="departments.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path></svg>
                Departments
            </a>
            <a href="feedback.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                Feedback Logs
            </a>
            <a href="services.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon></svg>
                Services
            </a>
            <a href="logout.php" class="group flex items-center gap-3 py-3 px-4 text-dangerRed hover:bg-red-50 font-bold text-[14px] rounded-xl mt-auto transition-all duration-150">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline></svg>
                Sign Out Engine
            </a>
        </nav>
    </aside>

    <main class="ml-[280px] p-6 lg:p-10 w-[calc(100%-280px)] min-h-screen flex flex-col relative z-10 min-w-0">
        
        <header class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8 pb-4 border-b border-borderGray/60 no-print">
            <div>
                <nav class="flex items-center gap-1.5 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    <span>MedCore</span> <span>&middot;</span> <span class="text-brandBlue">Registry Console</span>
                </nav>
                <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">Appointments Booking Core</h1>
            </div>
            
            <div class="flex flex-wrap items-center gap-4 w-full md:w-auto">
                <div class="relative flex-grow md:flex-grow-0 min-w-[220px]">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    </span>
                    <input type="text" placeholder="Global system lookup..." class="w-full pl-9 pr-4 py-2 bg-white border border-borderGray rounded-xl text-xs outline-none focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all">
                </div>
                
                <div class="flex items-center gap-3 bg-white border border-borderGray p-2 rounded-xl text-xs font-bold text-slate-700 shadow-sm">
                    <span id="liveChronometerNode" class="text-brandBlue font-mono">00:00:00 AM</span>
                    <span class="text-borderGray">|</span>
                    <span class="text-slate-500"><?php echo date('M d, Y'); ?></span>
                </div>

                <div class="flex items-center gap-2 border-l pl-2 border-borderGray">
                    <button class="p-2 bg-white border border-borderGray text-slate-400 hover:text-brandBlue rounded-xl relative shadow-sm">
                        <span class="absolute top-1 right-1 w-2 h-2 bg-brandBlue rounded-full"></span>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                    </button>
                    <div class="w-8 h-8 bg-brandBlue text-white font-bold rounded-xl flex items-center justify-center text-xs shadow-md shadow-brandBlue/20">A</div>
                </div>
            </div>
        </header>

        <?php if (!empty($msg)): ?>
            <div id="toast-success-banner" class="bg-successGreen/10 border border-successGreen/30 text-successGreen px-5 py-4 rounded-xl text-sm font-medium mb-8 flex items-center justify-between shadow-sm no-print animate-fade-in">
                <span><?php echo htmlspecialchars($msg); ?></span>
                <button onclick="document.getElementById('toast-success-banner').style.display='none'" class="text-successGreen/70 hover:text-successGreen font-bold">✕</button>
            </div>
        <?php endif; ?>

        <section class="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div><p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Registers</p><h3 class="text-xl font-black text-slate-900 mt-1"><?php echo $total_all; ?></h3></div>
                    <div class="p-3 bg-blue-50 rounded-xl text-brandBlue"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-brandBlue h-full rounded-full" style="width: 100%"></div></div>
            </div>
            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div><p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Today's Pipeline</p><h3 class="text-xl font-black text-slate-900 mt-1"><?php echo $total_today; ?></h3></div>
                    <div class="p-3 bg-sky-50 rounded-xl text-brandSky"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-brandSky h-full rounded-full" style="width: 55%"></div></div>
            </div>
            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div><p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Pending Active</p><h3 class="text-xl font-black text-warningAmber mt-1"><?php echo $total_pending; ?></h3></div>
                    <div class="p-3 bg-amber-50 rounded-xl text-warningAmber"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-warningAmber h-full rounded-full" style="width: 40%"></div></div>
            </div>
            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div><p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Completed Logs</p><h3 class="text-xl font-black text-successGreen mt-1"><?php echo $total_completed; ?></h3></div>
                    <div class="p-3 bg-green-50 rounded-xl text-successGreen"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-successGreen h-full rounded-full" style="width: 80%"></div></div>
            </div>
        </section>

        <section class="bg-white border border-borderGray p-6 rounded-2xl shadow-sm mb-8 flex flex-col print-full-card">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 border-b pb-4">
                <div class="flex items-center gap-2">
                    <span class="w-1.5 h-4 bg-brandBlue rounded-full"></span>
                    <div>
                        <h3 class="text-sm font-bold text-slate-900">Live Status Operational Calendar Tracking Node</h3>
                        <p class="text-[11px] text-slate-400 mt-0.5">Click any day grid cell to parse full localized allocation records dynamically.</p>
                    </div>
                </div>
                <form method="GET" class="flex items-center gap-2 no-print">
                    <div class="relative">
                        <select name="filter_month" class="pl-3 pr-8 py-2 bg-slate-50 border border-borderGray rounded-xl text-xs font-bold text-slate-800 outline-none appearance-none cursor-pointer">
                            <?php for($m=1; $m<=12; $m++): $m_val = sprintf('%02d', $m); ?>
                                <option value="<?php echo $m_val; ?>" <?php if($filter_month == $m_val) echo 'selected'; ?>><?php echo date('F', mktime(0,0,0,$m,1)); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="relative">
                        <select name="filter_year" class="pl-3 pr-8 py-2 bg-slate-50 border border-borderGray rounded-xl text-xs font-bold text-slate-800 outline-none appearance-none cursor-pointer">
                            <?php foreach ($available_years as $yr): ?>
                                <option value="<?php echo $yr; ?>" <?php if($filter_year == $yr) echo 'selected'; ?>><?php echo $yr; ?> Fiscal</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-sm">Sync</button>
                </form>
            </div>

            <div class="grid grid-cols-7 gap-2 text-center text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 bg-slate-50 py-2 rounded-xl select-none">
                <span>Sun</span><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span>
            </div>
            
            <div class="grid grid-cols-7 gap-2">
                <?php
                $first_day_ts = strtotime("$filter_year-$filter_month-01");
                $padding_offset = (int)date('w', $first_day_ts);
                for($i=0; $i<$padding_offset; $i++) {
                    echo "<div class='p-2 bg-slate-50/20 border border-transparent rounded-xl min-h-[75px]'></div>";
                }
                for($day=1; $day<=$days_in_month; $day++) {
                    $metrics = $calendar_data[$day];
                    $cell_date = "$filter_year-" . sprintf('%02d', $filter_month) . "-" . sprintf('%02d', $day);
                    $cell_bg = "bg-white border-borderGray hover:border-brandBlue/50 hover:shadow-md";
                    if($metrics['total'] > 0) $cell_bg = "bg-blue-50/70 border-brandBlue/30 text-slate-900 hover:bg-blue-100/60";
                    
                    echo "<div onclick=\"fetchDateRegistryDetails('$cell_date', '$day')\" class='p-3 border rounded-xl min-h-[75px] transition-all duration-150 cursor-pointer flex flex-col justify-between shadow-sm $cell_bg group'>";
                    echo "<span class='text-xs font-black opacity-80'>$day</span>";
                    if($metrics['total'] > 0) {
                        echo "<div class='flex flex-col gap-0.5 text-[9px] font-semibold mt-1'>";
                        echo "<span class='text-brandBlue font-extrabold flex items-center gap-1'><span class='w-1 h-1 bg-brandBlue rounded-full animate-pulse'></span>{$metrics['total']} Booked</span>";
                        echo "</div>";
                    }
                    echo "</div>";
                }
                ?>
            </div>
        </section>

        <div class="bg-white border border-borderGray p-5 rounded-2xl mb-6 shadow-sm flex flex-col gap-4 no-print gradient-border-glow">
            <form method="GET" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <div class="flex flex-col gap-1.5">
                    <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Department Node</label>
                    <select name="filter_department" class="px-3 py-2 bg-slate-50 border border-borderGray rounded-xl text-xs font-medium outline-none focus:bg-white focus:border-brandBlue transition-all">
                        <option value="">All Units</option>
                        <?php
                        $d_res = mysqli_query($conn, "SELECT name FROM departments ORDER BY name ASC");
                        while($r = mysqli_fetch_assoc($d_res)) {
                            $sel = ($filter_dept == $r['name']) ? 'selected' : '';
                            echo "<option value='".htmlspecialchars($r['name'])."' $sel>".htmlspecialchars($r['name'])."</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="flex flex-col gap-1.5">
                    <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Physician ID</label>
                    <input type="text" name="filter_doctor" placeholder="e.g. 12" value="<?php echo htmlspecialchars($filter_doctor); ?>" class="px-3 py-2 bg-slate-50 border border-borderGray rounded-xl text-xs font-medium outline-none focus:bg-white focus:border-brandBlue transition-all">
                </div>
                <div class="flex flex-col gap-1.5">
                    <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Target Status</label>
                    <select name="filter_status" class="px-3 py-2 bg-slate-50 border border-borderGray rounded-xl text-xs font-medium outline-none focus:bg-white focus:border-brandBlue transition-all">
                        <option value="">All Statuses</option>
                        <option value="Pending" <?php if($filter_status == 'Pending') echo 'selected'; ?>>Pending</option>
                        <option value="Complete" <?php if($filter_status == 'Complete') echo 'selected'; ?>>Complete</option>
                    </select>
                </div>
                <div class="flex flex-col gap-1.5">
                    <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Exact Chrono Date</label>
                    <input type="date" name="filter_date" value="<?php echo htmlspecialchars($filter_date); ?>" class="px-3 py-2 bg-slate-50 border border-borderGray rounded-xl text-xs font-medium outline-none focus:bg-white focus:border-brandBlue transition-all">
                </div>
                <div class="flex flex-col gap-1.5 sm:col-span-2">
                    <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Live Keyword Match</label>
                    <div class="flex gap-2">
                        <input type="text" name="search" placeholder="Patient name, email, contact..." value="<?php echo htmlspecialchars($search_term); ?>" class="px-3 py-2 bg-slate-50 border border-borderGray rounded-xl text-xs font-medium flex-grow outline-none focus:bg-white focus:border-brandBlue transition-all">
                        <button type="submit" class="bg-brandBlue text-white px-5 py-2 rounded-xl text-xs font-bold uppercase shadow-md shadow-brandBlue/10 hover:bg-blue-700 transition-all">Query</button>
                    </div>
                </div>
            </form>
            <div class="flex flex-wrap items-center justify-between border-t pt-4 gap-2 actions-bar-node">
                <div>
                    <?php if(!empty($filter_dept) || !empty($filter_doctor) || !empty($filter_status) || !empty($filter_date) || !empty($search_term)): ?>
                        <a href="appointments.php" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all">Clear Active Filters</a>
                    <?php endif; ?>
                </div>
                <div class="flex items-center gap-2">
                    <a href="appointments.php?export=excel<?php echo !empty($where_str)?'&'.http_build_query($_GET):''; ?>" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl font-bold text-xs uppercase flex items-center gap-1.5 shadow-sm transition-all">Excel Sheets</a>
                    <a href="appointments.php?export=csv<?php echo !empty($where_str)?'&'.http_build_query($_GET):''; ?>" class="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-xl font-bold text-xs uppercase shadow-sm transition-all">CSV Logs</a>
                </div>
            </div>
        </div>

        <div class="bg-white border border-borderGray rounded-2xl overflow-hidden shadow-sm flex-grow print-full-card">
            <div class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-left text-sm">
                    <thead>
                        <tr class="bg-slate-50 border-b border-borderGray text-slate-400 font-bold text-[11px] uppercase tracking-wider select-none sticky top-0 bg-white z-10">
                            <th class="px-6 py-4">Ticket ID</th>
                            <th class="px-6 py-4">Patient Name</th>
                            <th class="px-6 py-4">Assigned Doctor</th>
                            <th class="px-6 py-4">Department Node</th>
                            <th class="px-6 py-4">Chrono Slot Date</th>
                            <th class="px-6 py-4">Time Window</th>
                            <th class="px-6 py-4">Status</th>
                            <th class="px-6 py-4 text-right pr-8 w-[220px] no-print">Control Operations</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 text-slate-700 font-medium">
                        <?php
                        $main_query = "SELECT * FROM appointment $where_str ORDER BY id DESC";
                        $res = mysqli_query($conn, $main_query);
                        if (mysqli_num_rows($res) > 0) {
                            while ($row = mysqli_fetch_assoc($res)) {
                                $row_print_id = "print_ticket_" . $row['id'];
                        ?>
                        <tr id="<?php echo $row_print_id; ?>" class="hover:bg-slate-50/40 transition-colors">
                            <td class="px-6 py-4 text-brandBlue font-bold">#<?php echo $row['id']; ?></td>
                            <td class="px-6 py-4 text-slate-900 font-semibold"><?php echo htmlspecialchars($row['patient_name']); ?></td>
                            <td class="px-6 py-4"><span class="bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-lg text-xs font-medium"><?php echo htmlspecialchars($row['doctor_id']); ?></span></td>
                            <td class="px-6 py-4"><span class="bg-brandSky/10 text-brandSky px-2.5 py-0.5 rounded-lg text-xs font-bold uppercase"><?php echo htmlspecialchars($row['department']); ?></span></td>
                            <td class="px-6 py-4 text-slate-500 text-xs"><?php echo htmlspecialchars($row['appointment_date']); ?></td>
                            <td class="px-6 py-4 text-slate-500 text-xs"><?php echo htmlspecialchars($row['timing']); ?></td>
                            <td class="px-6 py-4">
                                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border uppercase <?php echo ($row['status'] == 'Complete') ? 'bg-green-50 border-green-200 text-successGreen' : 'bg-amber-50 border-amber-200 text-warningAmber'; ?>">
                                    <?php echo htmlspecialchars($row['status']); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 text-right pr-8 no-print">
                                <div class="flex items-center justify-end gap-3 text-xs font-bold">
                                    <button type="button" class="text-brandBlue hover:text-blue-700 hover:underline cursor-pointer transition-colors" onclick="downloadAppointmentPDF('<?php echo $row_print_id; ?>')">Export PDF</button>
                                    <span class="text-slate-200">|</span>
                                    <a href="appointments.php?delete=<?php echo $row['id']; ?>" class="text-dangerRed hover:text-red-700 hover:underline transition-colors" onclick="return confirm('Purge row permanently?');">Cancel</a>
                                </div>
                            </td>
                        </tr>
                        <?php 
                            }
                        } else {
                            echo "<tr><td colspan='8' class='text-center text-slate-400 py-16 bg-white text-xs'>No systems parameters located matching filter parameters.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <div id="calendarInspectionModal" class="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-[9999] hidden flex items-center justify-center p-4">
        <div class="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-borderGray overflow-hidden transform transition-all flex flex-col max-h-[85vh]">
            <div class="bg-slate-900 px-6 py-4 flex items-center justify-between border-b border-slate-800">
                <div>
                    <h3 class="text-white font-bold text-base">Date Operational Allocation Registry Logs</h3>
                    <p class="text-xs text-slate-400 mt-0.5" id="modalTargetDateStr">Target Scheduling Matrix Key:</p>
                </div>
                <button onclick="closeRegistryModal()" class="text-slate-400 hover:text-white transition-colors p-1.5 hover:bg-slate-800 rounded-lg text-sm font-bold">✕</button>
            </div>
            
            <div class="p-6 overflow-y-auto flex-grow bg-slate-50/50" id="modalRegistryContentContainer">
                </div>
            
            <div class="bg-white px-6 py-3.5 border-t border-borderGray flex items-center justify-end gap-2">
                <button onclick="closeRegistryModal()" class="px-4 py-2 border border-borderGray text-slate-700 font-bold rounded-xl text-xs bg-slate-50 hover:bg-slate-100 transition-all">Dismiss Node</button>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        // Live Clock Element Logic
        setInterval(() => {
            const timeNode = document.getElementById('liveChronometerNode');
            if (timeNode) {
                timeNode.innerText = new Date().toLocaleTimeString();
            }
        }, 1000);
    });

    function fetchDateRegistryDetails(dateStr, dayNum) {
        const modal = document.getElementById('calendarInspectionModal');
        const titleStr = document.getElementById('modalTargetDateStr');
        const container = document.getElementById('modalRegistryContentContainer');
        
        titleStr.innerText = `Inspecting Registered Logs for: ${dateStr}`;
        container.innerHTML = `<div class="py-12 flex flex-col items-center justify-center gap-2"><span class="text-xs text-slate-400 font-medium">Syncing live server records...</span></div>`;
        modal.classList.remove('hidden');

        fetch(`appointments.php?get_appointments_by_date=${dateStr}`)
            .then(response => response.json())
            .then(data => {
                if(data.length === 0) {
                    container.innerHTML = `
                        <div class="text-center py-12 bg-white rounded-2xl border border-dashed p-6">
                            <p class="text-xs font-semibold text-slate-400">No appointments active inside system database rows for this date.</p>
                        </div>`;
                    return;
                }
                
                let tableHtml = `
                    <div class="bg-white border border-borderGray rounded-xl overflow-hidden shadow-sm">
                        <table class="w-full text-left text-xs border-collapse">
                            <thead>
                                <tr class="bg-slate-100 border-b border-borderGray text-slate-500 font-bold uppercase tracking-wider">
                                    <th class="p-3">ID</th>
                                    <th class="p-3">Patient</th>
                                    <th class="p-3">Department</th>
                                    <th class="p-3">Doctor ID</th>
                                    <th class="p-3">Slot Time</th>
                                    <th class="p-3">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 text-slate-700 font-medium">`;
                
                data.forEach(item => {
                    tableHtml += `
                        <tr class="hover:bg-slate-50/70 transition-colors">
                            <td class="p-3 text-brandBlue font-bold">#${item.id}</td>
                            <td class="p-3 text-slate-900 font-bold">${item.patient_name}</td>
                            <td class="p-3"><span class="bg-sky-50 text-brandSky font-bold uppercase text-[10px] px-2 py-0.5 rounded border border-sky-100">${item.department}</span></td>
                            <td class="p-3"><span class="bg-slate-100 px-2 py-0.5 rounded font-semibold text-slate-600">Doc-${item.doctor_id}</span></td>
                            <td class="p-3 text-slate-500 font-medium">${item.timing}</td>
                            <td class="p-3"><span class="px-2 py-0.5 rounded border text-[9px] uppercase font-bold">${item.status}</span></td>
                        </tr>`;
                });
                
                tableHtml += `</tbody></table></div>`;
                container.innerHTML = tableHtml;
            })
            .catch(err => {
                container.innerHTML = `<div class="p-4 text-center text-dangerRed font-bold text-xs bg-red-50 rounded-xl border">Failure reading registry matrix logs from targeted framework.</div>`;
            });
    }

    function closeRegistryModal() {
        document.getElementById('calendarInspectionModal').classList.add('hidden');
    }

    // PDF Print Generation Engine
    function downloadAppointmentPDF(elementId) {
        const targetRow = document.getElementById(elementId);
        if (!targetRow) return;

        const container = document.createElement('div');
        container.className = 'print-receipt-area';
        container.innerHTML = `
            <div style="text-align:center; margin-bottom:30px; border-bottom:2px dashed #2563EB; padding-bottom:15px;">
                <h2 style="font-family:'Inter',sans-serif;font-weight:800;color:#2563EB;margin:0;font-size:24px;">MEDCORE CLINICAL NETWORKS</h2>
                <p style="margin:4px 0;font-size:13px;color:#1E293B;font-weight:600;">Official Certified Registry Entry Receipt Voucher</p>
                <p style="margin:0;font-size:11px;color:#64748B;">Generated: ${new Date().toLocaleString()}</p>
            </div>
            <table style="width:100%; border-collapse:collapse; margin-top:15px; font-family:'Inter',sans-serif;">
                <tr style="border-bottom:2px solid #1E293B;"><th style="text-align:left; padding:10px; font-size:12px; color:#475569; text-transform:uppercase;">Key</th><th style="text-align:left; padding:10px; font-size:12px; color:#475569; text-transform:uppercase;">Value</th></tr>
                <tr style="border-bottom:1px solid #E2E8F0;"><td style="padding:12px 10px;color:#64748B;font-size:13px;"><strong>Appointment Reference:</strong></td><td style="padding:12px 10px;font-weight:700;color:#2563EB;font-size:13px;">${targetRow.cells[0].innerText}</td></tr>
                <tr style="border-bottom:1px solid #E2E8F0;"><td style="padding:12px 10px;color:#64748B;font-size:13px;"><strong>Patient Name:</strong></td><td style="padding:12px 10px;font-weight:800;color:#1E293B;font-size:13px;">${targetRow.cells[1].innerText}</td></tr>
                <tr style="border-bottom:1px solid #E2E8F0;"><td style="padding:12px 10px;color:#64748B;font-size:13px;"><strong>Allocated Physician ID:</strong></td><td style="padding:12px 10px;color:#1E293B;font-weight:500;font-size:13px;">${targetRow.cells[2].innerText}</td></tr>
                <tr style="border-bottom:1px solid #E2E8F0;"><td style="padding:12px 10px;color:#64748B;font-size:13px;"><strong>Clinical Department Node:</strong></td><td style="padding:12px 10px;color:#2563EB;font-weight:700;font-size:13px;">${targetRow.cells[3].innerText}</td></tr>
                <tr style="border-bottom:1px solid #E2E8F0;"><td style="padding:12px 10px;color:#64748B;font-size:13px;"><strong>Calendar Date Vector:</strong></td><td style="padding:12px 10px;color:#1E293B;font-weight:500;font-size:13px;">${targetRow.cells[4].innerText}</td></tr>
                <tr style="border-bottom:1px solid #E2E8F0;"><td style="padding:12px 10px;color:#64748B;font-size:13px;"><strong>Assigned Time Duration:</strong></td><td style="padding:12px 10px;color:#1E293B;font-weight:500;font-size:13px;">${targetRow.cells[5].innerText}</td></tr>
                <tr style="border-bottom:1px solid #E2E8F0;"><td style="padding:12px 10px;color:#64748B;font-size:13px;"><strong>Verification Status:</strong></td><td style="padding:12px 10px;font-weight:700;color:#F59E0B;font-size:13px;">${targetRow.cells[6].innerText}</td></tr>
            </table>
            <div style="margin-top:50px; border-top:1px dashed #2563EB; padding-top:15px; font-size:11px; text-align:center; color:#64748B;">This is a system generated proof verification statement document.</div>
        `;
        document.body.appendChild(container);
        window.print();
        document.body.removeChild(container);
    }
    </script>
</body>
</html>