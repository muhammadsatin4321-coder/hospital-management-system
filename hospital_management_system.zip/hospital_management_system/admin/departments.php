<?php
session_start();
ob_start();
include("../includes/conn.php");

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$msg = "";
$edit_mode = false;
$edit_data = [];

/* --- 1. INSERT OPERATION WITH FILE UPLOAD --- */
if (isset($_POST['add'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $image_url = "uploads/default.png"; 

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "../uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $file_name = time() . "_" . basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $file_name;
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_url = "uploads/" . $file_name;
        }
    }

    $insert_query = "INSERT INTO departments (name, description, image_url) VALUES ('$name', '$description', '$image_url')";
    if (mysqli_query($conn, $insert_query)) {
        header("Location: departments.php?success=1");
        exit();
    } else {
        $msg = "Operational failure embedding parameters into system data layers: " . mysqli_error($conn);
    }
}

/* --- 2. POPULATE EDIT RECORD STATE TRIGGER --- */
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $id = intval($_GET['edit']);
    $edit_res = mysqli_query($conn, "SELECT * FROM departments WHERE id=$id");
    if (mysqli_num_rows($edit_res) > 0) {
        $edit_data = mysqli_fetch_assoc($edit_res);
    }
}

/* --- 3. EXECUTE STRUCTURAL UPDATE MATRIX --- */
if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    
    // Maintain preceding asset URL references by default
    $image_url = mysqli_real_escape_string($conn, $_POST['existing_image']);

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "../uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $file_name = time() . "_" . basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $file_name;
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_url = "uploads/" . $file_name;
        }
    }

    $update_query = "UPDATE departments SET name='$name', description='$description', image_url='$image_url' WHERE id=$id";
    if (mysqli_query($conn, $update_query)) {
        header("Location: departments.php?success=2");
        exit();
    } else {
        $msg = "Error updating database ledger details: " . mysqli_error($conn);
    }
}

/* --- 4. PURGE CONFIGURATION ROW EXECUTION --- */
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $delete_query = "DELETE FROM departments WHERE id=$id";
    if (mysqli_query($conn, $delete_query)) {
        header("Location: departments.php?success=3");
        exit();
    } else {
        $msg = "Error purging operational row: " . mysqli_error($conn);
    }
}

// Map success flags to system message nodes
if (isset($_GET['success'])) {
    if ($_GET['success'] == 1) $msg = "New clinical department node initialized successfully.";
    if ($_GET['success'] == 2) $msg = "Department configuration parameters updated successfully.";
    if ($_GET['success'] == 3) $msg = "Department record was permanently removed from the system registry.";
}

// Calculate counters for context metrics cards
$total_depts = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM departments"));
$total_docs  = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM doctors"));
$total_apps  = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM appointment"));
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth h-full bg-[#F8FAFC]">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinical Care Hub - Department Management Infrastructure</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        lightBg: '#F8FAFC',       
                        cardWhite: '#FFFFFF',     
                        brandBlue: '#2563EB',     
                        brandSky: '#0EA5E9',
                        brandTeal: '#14B8A6', 
                        successGreen: '#22C55E',  
                        warningAmber: '#F59E0B', 
                        dangerRed: '#EF4444',     
                        slateText: '#1E293B',
                        borderGray: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'Plus Jakarta Sans', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;600;700&display=swap');
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #F1F5F9; }
        ::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 4px; }
        .medical-canvas-underlay {
            position: absolute; top: 0; left: 0; right: 0; height: 450px;
            background: radial-gradient(circle at 15% 15%, rgba(37, 99, 237, 0.04) 0%, transparent 65%);
            z-index: 0; pointer-events: none;
        }
        .hover-lift { transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.25s ease; }
        .hover-lift:hover { transform: translateY(-4px); box-shadow: 0 16px 24px -8px rgba(37, 99, 237, 0.08); }
        .gradient-border-glow { position: relative; border-radius: 1rem; }
        .gradient-border-glow::before {
            content: ''; position: absolute; inset: -1px; border-radius: 1rem;
            background: linear-gradient(135deg, #2563EB10, #0EA5E910, transparent);
            z-index: -1; pointer-events: none;
        }
        @media print {
            aside, header, form, .no-print { display: none !important; }
            main { margin-left: 0 !important; width: 100% !important; padding: 0 !important; }
            .print-full-card { border: none !important; shadow: none !important; }
        }
    </style>
</head>
<body class="bg-lightBg text-slateText font-sans antialiased min-h-screen flex relative overflow-x-hidden">

    <div class="medical-canvas-underlay"></div>

    <aside class="w-[280px] bg-white border-r border-borderGray/90 flex flex-col py-8 px-6 fixed top-0 bottom-0 left-0 h-screen z-50 shadow-sm">
        <h2 class="text-xl font-extrabold tracking-tight text-slate-900 mb-10 pl-2 flex items-center gap-3 select-none">
            <div class="p-2.5 bg-brandBlue/10 rounded-xl text-brandBlue shadow-sm shadow-blue-600/5">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
            <span>MED<span class="text-brandBlue">CORE</span></span>
        </h2>
        
        <nav class="flex flex-col gap-1.5 flex-grow overflow-y-auto pr-1">
            <a href="index.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9"></rect><rect x="14" y="3" width="7" height="5"></rect><rect x="14" y="12" width="7" height="9"></rect><rect x="3" y="16" width="7" height="5"></rect></svg>
                Dashboard Hub
            </a>
            <a href="doctors.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg>
                Doctors Panel
            </a>
            <a href="patients.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                Patients Registry
            </a>
            <a href="appointments.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                Appointments Matrix
            </a>
            <a href="departments.php" class="flex items-center gap-3 py-3 px-4 bg-brandBlue text-white font-semibold text-[14px] rounded-xl shadow-md shadow-brandBlue/20">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path></svg>
                Departments
            </a>
            <a href="feedback.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                Feedback Logs
            </a>
            <a href="services.php" class="group flex items-center gap-3 py-3 px-4 text-slate-600 hover:bg-slate-50 hover:text-brandBlue font-medium text-[14px] rounded-xl transition-all duration-150">
                <svg class="text-slate-400 group-hover:text-brandBlue transition-colors" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon></svg>
                Services
            </a>
            <a href="logout.php" class="group flex items-center gap-3 py-3 px-4 text-dangerRed hover:bg-red-50 font-bold text-[14px] rounded-xl mt-auto transition-all duration-150">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline></svg>
                Sign Out Engine
            </a>
        </nav>
    </aside>

    <main class="ml-[280px] p-6 lg:p-10 w-[calc(100%-280px)] min-h-screen flex flex-col relative z-10 min-w-0">
        
        <header class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8 pb-4 border-b border-borderGray/60 no-print">
            <div>
                <nav class="flex items-center gap-1.5 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    <span>MedCore</span> <span>&middot;</span> <span class="text-brandBlue">Registry Control</span>
                </nav>
                <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">Departments Infrastructure Node</h1>
            </div>
            
            <div class="flex flex-wrap items-center gap-4 w-full md:w-auto">
                <div class="relative flex-grow md:flex-grow-0 min-w-[220px]">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    </span>
                    <input type="text" placeholder="Global system lookup..." class="w-full pl-9 pr-4 py-2 bg-white border border-borderGray rounded-xl text-xs outline-none focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all">
                </div>
                
                <div class="flex items-center gap-3 bg-white border border-borderGray p-2 rounded-xl text-xs font-bold text-slate-700 shadow-sm">
                    <span id="liveChronometerNode" class="text-brandBlue font-mono">00:00:00 AM</span>
                    <span class="text-borderGray">|</span>
                    <span class="text-slate-500"><?php echo date('M d, Y'); ?></span>
                </div>

                <div class="flex items-center gap-2 border-l pl-2 border-borderGray">
                    <button class="p-2 bg-white border border-borderGray text-slate-400 hover:text-brandBlue rounded-xl relative shadow-sm">
                        <span class="absolute top-1 right-1 w-2 h-2 bg-brandBlue rounded-full"></span>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                    </button>
                    <div class="w-8 h-8 bg-brandBlue text-white font-bold rounded-xl flex items-center justify-center text-xs shadow-md shadow-brandBlue/20">A</div>
                </div>
            </div>
        </header>

        <?php if (!empty($msg)): ?>
            <div id="toast-success-banner" class="bg-successGreen/10 border border-successGreen/30 text-successGreen px-5 py-4 rounded-xl text-sm font-medium mb-8 flex items-center justify-between shadow-sm no-print animate-fade-in">
                <span><?php echo htmlspecialchars($msg); ?></span>
                <button onclick="document.getElementById('toast-success-banner').style.display='none'" class="text-successGreen/70 hover:text-successGreen font-bold">✕</button>
            </div>
        <?php endif; ?>

        <section class="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Active Departments</p>
                        <h3 class="text-xl font-black text-slate-900 mt-1"><?php echo $total_depts; ?> Units</h3>
                    </div>
                    <div class="p-3 bg-blue-50 rounded-xl text-brandBlue"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-brandBlue h-full rounded-full" style="width: 70%"></div></div>
            </div>
            
            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Medical Officers</p>
                        <h3 class="text-xl font-black text-slate-900 mt-1"><?php echo $total_docs; ?> MDs</h3>
                    </div>
                    <div class="p-3 bg-sky-50 rounded-xl text-brandSky"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-brandSky h-full rounded-full" style="width: 85%"></div></div>
            </div>

            <div class="bg-white border border-borderGray p-5 rounded-2xl shadow-sm flex flex-col justify-between hover-lift">
                <div class="flex items-center justify-between gap-4">
                    <div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Slots Logged</p>
                        <h3 class="text-xl font-black text-slate-900 mt-1"><?php echo $total_apps; ?> Records</h3>
                    </div>
                    <div class="p-3 bg-teal-50 rounded-xl text-brandTeal"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="10" x2="21" y2="10"></line></svg></div>
                </div>
                <div class="mt-4 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div class="bg-brandTeal h-full rounded-full" style="width: 60%"></div></div>
            </div>
        </section>

        <div class="grid grid-cols-1 xl:grid-cols-3 gap-8 items-start">
            
            <div class="bg-white border border-borderGray rounded-2xl p-6 shadow-sm no-print gradient-border-glow">
                <div class="pb-4 border-b border-slate-100 mb-5 select-none">
                    <h3 class="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                        <span class="w-1.5 h-3.5 bg-brandBlue rounded-full"></span>
                        <?php echo $edit_mode ? 'Modify Unit Properties' : 'Initialize New Unit Node'; ?>
                    </h3>
                    <p class="text-[11px] text-slate-400 mt-0.5">Maintain system schema properties accurately.</p>
                </div>

                <form method="POST" enctype="multipart/form-data" class="flex flex-col gap-4">
                    <?php if ($edit_mode): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
                        <input type="hidden" name="existing_image" value="<?php echo htmlspecialchars($edit_data['image_url']); ?>">
                    <?php endif; ?>

                    <div class="flex flex-col gap-1.5">
                        <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Department Label Name</label>
                        <input type="text" name="name" required placeholder="e.g. Cardiology Cluster" value="<?php echo $edit_mode ? htmlspecialchars($edit_data['name']) : ''; ?>" class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-medium outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all">
                    </div>

                    <div class="flex flex-col gap-1.5">
                        <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Functional Description Log</label>
                        <textarea name="description" rows="4" required placeholder="Describe clinical specialization vectors..." class="w-full px-3.5 py-2.5 bg-slate-50 border border-borderGray rounded-xl text-xs font-medium outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all resize-none"><?php echo $edit_mode ? htmlspecialchars($edit_data['description']) : ''; ?></textarea>
                    </div>

                    <div class="flex flex-col gap-1.5">
                        <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Identity Graphic Graphic Asset (Image)</label>
                        <?php if ($edit_mode && !empty($edit_data['image_url'])): ?>
                            <div class="flex items-center gap-3 p-2 border border-slate-100 rounded-xl bg-slate-50 mb-1">
                                <img src="../<?php echo $edit_data['image_url']; ?>" alt="Preview" class="w-10 h-10 object-cover rounded-lg border">
                                <span class="text-[10px] font-semibold text-slate-400 truncate max-w-[160px]"><?php echo basename($edit_data['image_url']); ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="relative w-full border border-dashed border-borderGray hover:border-brandBlue/60 rounded-xl p-4 text-center cursor-pointer transition-colors bg-slate-50/50 group">
                            <input type="file" name="image" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" <?php echo $edit_mode ? '' : ''; ?>>
                            <svg class="mx-auto text-slate-400 mb-2 group-hover:text-brandBlue transition-colors" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                            <span class="text-[11px] font-bold text-slate-600 block">Upload System Graphic Asset</span>
                            <span class="text-[9px] text-slate-400 block mt-0.5">PNG, JPG, or JPEG format parameters</span>
                        </div>
                    </div>

                    <div class="flex gap-2 mt-2">
                        <?php if ($edit_mode): ?>
                            <button type="submit" name="update" class="flex-grow bg-brandBlue text-white font-bold text-xs uppercase py-3 px-4 rounded-xl shadow-md shadow-brandBlue/10 hover:bg-blue-700 transition-all">Commit Updates</button>
                            <a href="departments.php" class="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs uppercase py-3 px-4 rounded-xl text-center transition-all">Cancel</a>
                        <?php else: ?>
                            <button type="submit" name="add" class="w-full bg-brandBlue text-white font-bold text-xs uppercase py-3 px-4 rounded-xl shadow-md shadow-brandBlue/10 hover:bg-blue-700 transition-all">Register Department</button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="xl:col-span-2 bg-white border border-borderGray rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between print-full-card">
                <div>
                    <div class="p-5 border-b border-slate-100 flex items-center justify-between">
                        <h3 class="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                            <span class="w-1.5 h-3.5 bg-brandTeal rounded-full"></span> Live Infrastructure Matrices
                        </h3>
                        <span class="text-[10px] font-bold text-slate-400 bg-slate-50 border border-slate-100 px-2 py-0.5 rounded-lg select-none">Automated Feed Rows</span>
                    </div>
                    
                    <div class="overflow-x-auto w-full">
                        <table class="w-full text-left text-xs border-collapse">
                            <thead>
                                <tr class="bg-slate-50 border-b border-borderGray text-slate-400 font-bold text-[10px] uppercase tracking-wider select-none">
                                    <th class="p-4 pl-6 w-[80px]">Node ID</th>
                                    <th class="p-4 w-[140px]">Unit Identity</th>
                                    <th class="p-4">Functional Description Matrix</th>
                                    <th class="p-4 text-right pr-6 w-[150px] no-print">Control Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 text-slate-700 font-medium">
                                <?php
                                $select_query = "SELECT * FROM departments ORDER BY id DESC";
                                $res = mysqli_query($conn, $select_query);
                                if (mysqli_num_rows($res) > 0) {
                                    while ($row = mysqli_fetch_assoc($res)) {
                                ?>
                                <tr class="hover:bg-slate-50/40 transition-colors">
                                    <td class="p-4 pl-6 text-brandBlue font-bold">#<?php echo $row['id']; ?></td>
                                    <td class="p-4">
                                        <div class="flex items-center gap-3">
                                            <div class="w-9 h-9 rounded-xl border border-slate-200 overflow-hidden shadow-sm bg-slate-50 flex-shrink-0 select-none">
                                                <img src="../<?php echo htmlspecialchars($row['image_url']); ?>" alt="Dept Profile" class="w-full h-full object-cover">
                                            </div>
                                            <span class="font-bold text-slate-900 leading-tight block"><?php echo htmlspecialchars($row['name']); ?></span>
                                        </div>
                                    </td>
                                    <td class="p-4 text-slate-500 leading-relaxed max-w-xs truncate md:max-w-sm"><?php echo htmlspecialchars($row['description']); ?></td>
                                    <td class="p-4 text-right pr-6 no-print">
                                        <div class="flex items-center justify-end gap-3 font-bold">
                                            <a href="departments.php?edit=<?php echo $row['id']; ?>" class="text-brandBlue hover:text-blue-700 hover:underline transition duration-150 flex items-center gap-1">
                                                Edit
                                            </a>
                                            <span class="text-slate-200 select-none">|</span>
                                            <a href="departments.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Purge this operational department row configuration securely?');" class="text-dangerRed hover:text-red-700 hover:underline transition duration-150 flex items-center gap-1">
                                                Purge
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php 
                                    }
                                } else {
                                    echo "<tr><td colspan='4' class='text-center text-slate-400 py-16 bg-white text-xs'>No active department matrix layers logged inside your operational framework.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        // Chronometer Engine Clock Sync
        setInterval(() => {
            const timeNode = document.getElementById('liveChronometerNode');
            if (timeNode) {
                timeNode.innerText = new Date().toLocaleTimeString();
            }
        }, 1000);
    });
    </script>
</body>
</html>