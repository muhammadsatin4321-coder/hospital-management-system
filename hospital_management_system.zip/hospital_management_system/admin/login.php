<?php
session_start();
ob_start();
include("../includes/conn.php"); 

$error_msg = "";

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    // Prepared statement to securely handle user authentication
    $stmt = $conn->prepare("SELECT id, username, password FROM admin WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $db_username, $db_password);
        $stmt->fetch();

        // Password check verification vector
        if ($password == $db_password) {
            $_SESSION['admin_id'] = $id;
            $_SESSION['admin_username'] = $db_username;

            header("Location: index.php");
            exit();
        } else {
            $error_msg = "Invalid authentication password credentials.";
        }
    } else {
        $error_msg = "Administrative network identity profile not found.";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth h-full bg-[#F8FAFC]">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinical Care Hub - Secure Master Gateway Control</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        lightBg: '#F8FAFC',       
                        cardWhite: '#FFFFFF',     
                        brandBlue: '#2563EB',     
                        brandSky: '#0EA5E9',
                        brandTeal: '#14B8A6', 
                        successGreen: '#22C55E',  
                        warningAmber: '#F59E0B', 
                        dangerRed: '#EF4444',     
                        slateText: '#1E293B',
                        borderGray: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'Plus Jakarta Sans', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;600;700&display=swap');
        
        .medical-canvas-underlay {
            position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background: radial-gradient(circle at 50% 30%, rgba(37, 99, 237, 0.05) 0%, transparent 60%),
                        radial-gradient(circle at 80% 80%, rgba(20, 184, 166, 0.03) 0%, transparent 50%);
            z-index: 0; pointer-events: none;
        }
        .gradient-border-glow { position: relative; border-radius: 1.5rem; }
        .gradient-border-glow::before {
            content: ''; position: absolute; inset: -1px; border-radius: 1.5rem;
            background: linear-gradient(135deg, #2563EB15, #14B8A615, transparent);
            z-index: -1; pointer-events: none;
        }
        .animate-fade-in {
            animation: fadeIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="bg-lightBg text-slateText font-sans antialiased min-h-screen flex items-center justify-center relative overflow-hidden p-4">

    <div class="medical-canvas-underlay"></div>

    <div class="w-full max-w-[460px] bg-white border border-borderGray rounded-3xl p-8 md:p-10 shadow-xl shadow-slate-200/40 relative z-10 gradient-border-glow animate-fade-in">
        
        <div class="text-center mb-8 select-none">
            <div class="inline-flex p-3 bg-brandBlue/10 rounded-2xl text-brandBlue shadow-sm shadow-blue-600/5 mb-4">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
            <h2 class="text-2xl font-black tracking-tight text-slate-900">
                MED<span class="text-brandBlue">CORE</span> SYSTEMS
            </h2>
            <p class="text-xs text-slate-400 font-medium mt-1">Authorized Administration Console Access Gateway</p>
        </div>

        <?php if (!empty($error_msg)): ?>
            <div id="error-alert-banner" class="bg-dangerRed/10 border border-dangerRed/20 text-dangerRed px-4 py-3 rounded-xl text-xs font-semibold mb-6 flex items-center justify-between shadow-sm animate-fade-in">
                <div class="flex items-center gap-2">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                    <span><?php echo htmlspecialchars($error_msg); ?></span>
                </div>
                <button onclick="document.getElementById('error-alert-banner').style.display='none'" class="text-dangerRed/60 hover:text-dangerRed font-bold text-sm">✕</button>
            </div>
        <?php endif; ?>

        <form method="POST" action="" class="flex flex-col gap-5">
            
            <div class="flex flex-col gap-1.5">
                <label for="username" class="text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Network Identity Profile</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                    </span>
                    <input type="text" 
                           id="username" 
                           name="username" 
                           required 
                           placeholder="Enter admin system identity..."
                           class="w-full pl-10 pr-4 py-3 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all">
                </div>
            </div>

            <div class="flex flex-col gap-1.5">
                <label for="password" class="text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1">Security Password Matrix</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                    </span>
                    <input type="password" 
                           id="password" 
                           name="password" 
                           required 
                           placeholder="Enter secure master key..."
                           class="w-full pl-10 pr-4 py-3 bg-slate-50 border border-borderGray rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 outline-none focus:bg-white focus:border-brandBlue focus:ring-4 focus:ring-blue-500/5 transition-all">
                </div>
            </div>

            <button type="submit" 
                    name="login" 
                    class="w-full bg-brandBlue text-white font-bold py-3.5 px-4 rounded-xl text-xs uppercase tracking-wider shadow-md shadow-brandBlue/20 hover:bg-blue-700 transition-all duration-150 active:scale-[0.99] mt-3 cursor-pointer">
                Execute Access Authentication
            </button>
        </form>

        <div class="text-center mt-8 pt-6 border-t border-slate-100 select-none">
            <p class="text-[11px] font-medium text-slate-400">
                Protected system console area. Terminal logs trace all attempts.
            </p>
        </div>

    </div>
</body>
</html>