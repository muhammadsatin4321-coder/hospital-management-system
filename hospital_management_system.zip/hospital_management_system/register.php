<?php
session_start();
include("includes/conn.php");

$err = "";
$success = "";
$current_page = 'register.php';

if (isset($_POST['register'])) {

    $name     = mysqli_real_escape_string($conn, $_POST['name']);
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $phone    = mysqli_real_escape_string($conn, $_POST['phone']);
    $gender   = mysqli_real_escape_string($conn, $_POST['gender']);
    $address  = mysqli_real_escape_string($conn, $_POST['address']);
    $password = $_POST['password'];

    if (!empty($name) && !empty($email) && !empty($phone) && !empty($password)) {

        $check = mysqli_query($conn, "SELECT id FROM patients WHERE email='$email'");

        if (mysqli_num_rows($check) > 0) {

            $err = "This email profile configuration already exists inside the registry.";

        } else {

            $q = "INSERT INTO patients (name, email, password, phone, gender, address)
                  VALUES ('$name', '$email', '$password', '$phone', '$gender', '$address')";

            if (mysqli_query($conn, $q)) {

                $success = "Registration confirmed. You may now log into your dashboard.";

            } else {

                $err = "Internal query structural database execution failure.";
            }
        }

    } else {

        $err = "Please complete all mandatory registry parameters.";
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Secure Profile - Registration | MedNetwork</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: '#F8FAFC',
                        card: '#FFFFFF',
                        primary: '#2563EB',
                        secondary: '#0EA5E9',
                        accent: '#14B8A6',
                        success: '#22C55E',
                        warning: '#F59E0B',
                        danger: '#EF4444',
                        textMain: '#1E293B',
                        borderColor: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        heading: ['Poppins', 'sans-serif']
                    },
                    borderRadius: {
                        'premium': '20px'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F8FAFC;
        }

        .font-heading {
            font-family: 'Poppins', sans-serif;
        }

        .premium-transition { 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
        }
        
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }

        /* Medical Grid Overlay Micro-Pattern */
        .medical-pattern {
            background-image: radial-gradient(#2563eb 0.75px, transparent 0.75px), radial-gradient(#0ea5e9 0.75px, #F8FAFC 0.75px);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            opacity: 0.12;
        }

        /* Smooth Reveal Framework Components */
        .reveal-section {
            opacity: 0; 
            transform: translateY(20px); 
            will-change: transform, opacity;
            transition: opacity 0.8s cubic-bezier(0.25, 1, 0.5, 1), transform 0.8s cubic-bezier(0.25, 1, 0.5, 1);
        }
        .reveal-section.visible { 
            opacity: 1; 
            transform: translateY(0); 
        }

        .form-input-focus:focus {
            border-color: #2563EB;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
            background-color: #FFFFFF;
        }
    </style>
</head>
<body class="text-textMain antialiased min-h-screen flex flex-col pt-[120px] relative overflow-x-hidden">

    <div class="absolute inset-0 medical-pattern pointer-events-none z-0"></div>
    <div class="absolute top-[8%] right-[-5%] w-[450px] h-[450px] bg-secondary/10 rounded-full blur-[130px] pointer-events-none z-0"></div>
    <div class="absolute bottom-[12%] left-[-5%] w-[500px] h-[500px] bg-accent/10 rounded-full blur-[150px] pointer-events-none z-0"></div>

    <div class="bg-danger text-white fixed top-0 left-0 right-0 z-[60] h-[40px] flex items-center text-sm font-medium shadow-sm border-b border-white/10">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <div class="flex items-center gap-6">
                <a href="tel:+15559113940" class="flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91" /></svg>
                    <span class="tracking-wide">Emergency Response: <strong class="font-semibold">+92 3000000000</strong></span>
                </a>
            </div>
            <div class="text-xs tracking-widest uppercase font-semibold opacity-90 hidden md:flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-white animate-pulse"></span> Identity Provisioning Registry Module Active
            </div>
        </div>
    </div>

    <nav class="glass-nav fixed top-[40px] left-0 right-0 z-50 h-[80px] flex items-center border-b border-borderColor premium-transition shadow-sm" id="main-navbar">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-textMain group">
                <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 premium-transition">
                    <svg class="text-primary group-hover:scale-110 premium-transition" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                </div>
                <span class="tracking-tight">Med<span class="text-primary font-extrabold">Network</span></span>
            </a>
            
            <button class="md:hidden flex flex-col justify-between w-6 h-4 bg-transparent border-none cursor-pointer z-50 focus:outline-none" id="mobile-menu-btn" aria-label="Toggle navigation menu">
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar1"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition my-auto" id="bar2"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar3"></span>
            </button>
            
            <ul class="fixed md:static top-[120px] left-[-100%] md:left-0 w-full md:w-auto h-[calc(100vh-120px)] md:h-auto bg-card md:bg-transparent border-t border-borderColor md:border-none flex flex-col md:flex-row items-center pt-8 md:pt-0 gap-6 md:gap-8 premium-transition z-40" id="nav-links-menu">
                <li><a href="index.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Home</a></li>
                <li><a href="services.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Services</a></li>
                <li><a href="doctors.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Our Doctors</a></li>
                <li><a href="about.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">About Us</a></li>
                <li><a href="contact.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Contact</a></li>
                
                <li class="hidden md:block w-px h-5 bg-borderColor mx-1"></li>
                <li><a href="login.php" class="text-[15px] font-semibold text-textMain/80 hover:text-primary premium-transition py-2 block">Login</a></li>
                <li><a href="register.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-sm">Sign Up</a></li>
            </ul>
        </div>
    </nav>

    <main class="flex-grow w-full max-w-[1200px] mx-auto px-6 py-12 relative z-10 flex items-center justify-center reveal-section">
        <div class="w-full grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch max-w-5xl bg-card border border-borderColor rounded-premium shadow-xl overflow-hidden min-h-[620px]">
            
            <div class="lg:col-span-4 bg-textMain text-white p-8 md:p-10 flex flex-col justify-between relative overflow-hidden select-none">
                <div class="absolute inset-0 bg-gradient-to-b from-primary/10 to-transparent pointer-events-none z-0"></div>
                
                <div class="relative z-10">
                    <a href="index.php" class="flex items-center gap-2.5 font-heading text-xl font-bold text-white group inline-block">
                        <div class="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center">
                            <svg class="text-secondary" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                        </div>
                        <span class="tracking-tight">Med<span class="text-secondary font-extrabold">Network</span></span>
                    </a>
                </div>

                <div class="relative z-10 my-auto py-10 space-y-4" id="slider-frame">
                    <div class="space-y-3 premium-transition opacity-0 absolute pointer-events-none" data-slide-index="0">
                        <span class="text-[10px] tracking-widest uppercase font-bold text-secondary bg-white/5 border border-white/10 px-2.5 py-1 rounded-md">Unified Matrix</span>
                        <h3 class="font-heading text-xl font-bold tracking-tight text-white">Central Clinical Record</h3>
                        <p class="text-[12px] text-borderColor/70 leading-relaxed font-light">Registering establishes a secure data node across institutional database networks to sync diagnostic parameters asynchronously.</p>
                    </div>

                    <div class="space-y-3 premium-transition opacity-0 absolute pointer-events-none" data-slide-index="1">
                        <span class="text-[10px] tracking-widest uppercase font-bold text-accent bg-white/5 border border-white/10 px-2.5 py-1 rounded-md">24/7 Connectivity</span>
                        <h3 class="font-heading text-xl font-bold tracking-tight text-white">Instant Consultation Routing</h3>
                        <p class="text-[12px] text-borderColor/70 leading-relaxed font-light">Gain instant authorization mappings to queue open calendar slots with designated specialty clinical leaders.</p>
                    </div>

                    <div class="space-y-3 premium-transition opacity-0 absolute pointer-events-none" data-slide-index="2">
                        <span class="text-[10px] tracking-widest uppercase font-bold text-success bg-white/5 border border-white/10 px-2.5 py-1 rounded-md">System Standard</span>
                        <h3 class="font-heading text-xl font-bold tracking-tight text-white">Cryptographic Safety Logs</h3>
                        <p class="text-[12px] text-borderColor/70 leading-relaxed font-light">Your information inputs are stored inside structured relational matrix modules complying with network standards.</p>
                    </div>
                </div>

                <div class="relative z-10 flex gap-2" id="slider-pagination-dots">
                    <button class="h-1 rounded-full premium-transition bg-white/20 w-3 focus:outline-none" data-index="0" aria-label="Go to slide 1"></button>
                    <button class="h-1 rounded-full premium-transition bg-white/20 w-3 focus:outline-none" data-index="1" aria-label="Go to slide 2"></button>
                    <button class="h-1 rounded-full premium-transition bg-white/20 w-3 focus:outline-none" data-index="2" aria-label="Go to slide 3"></button>
                </div>
            </div>

            <div class="lg:col-span-8 p-8 md:p-12 flex flex-col justify-center bg-card">
                <div class="mb-6">
                    <h2 class="font-heading text-2xl md:text-3xl font-bold tracking-tight text-textMain mb-1">Create Patient Registry Profile</h2>
                    <p class="text-[14px] text-textMain/50 font-light">Please distribute accurate patient information inside the configuration inputs below.</p>
                </div>

                <?php if(!empty($err)): ?>
                    <div class="bg-danger/10 border border-danger/20 text-danger px-4 py-3 rounded-xl flex items-start gap-3 text-sm font-medium mb-5 transition duration-200">
                        <svg class="flex-shrink-0 mt-0.5" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        <span><?php echo htmlspecialchars($err); ?></span>
                    </div>
                <?php endif; ?>

                <?php if(!empty($success)): ?>
                    <div class="bg-success/10 border border-success/20 text-success px-4 py-3 rounded-xl flex items-start gap-3 text-sm font-medium mb-5 transition duration-200">
                        <svg class="flex-shrink-0 mt-0.5" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                        <span><?php echo htmlspecialchars($success); ?></span>
                    </div>
                <?php endif; ?>

                <form action="register.php" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    <div class="space-y-1">
                        <label for="name" class="text-xs uppercase font-bold tracking-wider text-textMain/60">Full Patient Name *</label>
                        <input type="text" name="name" id="name" required placeholder="name" class="w-full bg-background text-textMain border border-borderColor px-4 py-2.5 rounded-xl focus:outline-none form-input-focus premium-transition text-sm font-medium">
                    </div>

                    <div class="space-y-1">
                        <label for="email" class="text-xs uppercase font-bold tracking-wider text-textMain/60">E-mail Vector Node *</label>
                        <input type="email" name="email" id="email" required placeholder="name@mednetwork.org" class="w-full bg-background text-textMain border border-borderColor px-4 py-2.5 rounded-xl focus:outline-none form-input-focus premium-transition text-sm font-medium">
                    </div>

                    <div class="space-y-1">
                        <label for="phone" class="text-xs uppercase font-bold tracking-wider text-textMain/60">Secure Contact Number *</label>
                        <input type="tel" name="phone" id="phone" required placeholder="+92 3000000000" class="w-full bg-background text-textMain border border-borderColor px-4 py-2.5 rounded-xl focus:outline-none form-input-focus premium-transition text-sm font-medium">
                    </div>

                    <div class="space-y-1">
                        <label for="gender" class="text-xs uppercase font-bold tracking-wider text-textMain/60">Biological Sex Designation</label>
                                <select name="gender" class="w-full px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium">
                                    <option>Select Your Gender</option>
                                    <option>Male</option>
                                    <option>Female</option>
                                </select>
                    </div>

                    <div class="md:col-span-2 space-y-1">
                        <label for="password" class="text-xs uppercase font-bold tracking-wider text-textMain/60">Access Cryptographic Password *</label>
                        <input type="password" name="password" id="password" required placeholder="••••••••••••" class="w-full bg-background text-textMain border border-borderColor px-4 py-2.5 rounded-xl focus:outline-none form-input-focus premium-transition text-sm font-medium">
                    </div>

                    <div class="md:col-span-2 space-y-1">
                        <label for="address" class="text-xs uppercase font-bold tracking-wider text-textMain/60">Residential Address Mappings</label>
                        <textarea name="address" id="address" rows="2" placeholder="Suite, Street Address, City, State, ZIP Core" class="w-full bg-background text-textMain border border-borderColor px-4 py-2.5 rounded-xl focus:outline-none form-input-focus premium-transition text-sm font-medium resize-none"></textarea>
                    </div>

                    <div class="md:col-span-2 pt-2">
                        <button type="submit" name="register" class="w-full bg-gradient-to-r from-primary to-secondary hover:from-primary hover:to-primary text-white font-bold py-3 rounded-xl text-[14px] shadow-lg shadow-primary/20 hover:shadow-primary/30 transform hover:-translate-y-0.5 active:translate-y-0 premium-transition tracking-wide block text-center">
                            Deploy Account Provisioning Sequence
                        </button>
                    </div>

                </form>

                <div class="pt-5 mt-5 border-t border-borderColor/80 text-center text-sm font-light text-textMain/60">
                    Already operational inside the matrix? <a href="login.php" class="font-bold text-primary hover:text-secondary premium-transition">Authenticate Core Login</a>
                </div>
            </div>

        </div>
    </main>

    <footer class="bg-textMain text-white pt-16 pb-10 border-t border-textMain mt-auto relative z-10 shadow-inner">
        <div class="container mx-auto px-6 max-w-[1200px]">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-10 mb-12">
                <div class="md:col-span-2 space-y-4">
                    <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-white group inline-block">
                        <div class="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
                            <svg class="text-secondary" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                        </div>
                        <span class="tracking-tight">Med<span class="text-secondary font-extrabold">Network</span></span>
                    </a>
                    <p class="text-[14px] text-borderColor/70 max-w-sm leading-relaxed font-light">Providing high-quality clinical operations management tools and professional healthcare networking platforms globally.</p>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Platform</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="index.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Network Modules</a></li>
                        <li><a href="services.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Clinical Services</a></li>
                        <li><a href="doctors.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Doctor Portal</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Resources</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Developer API</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">System Status</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Support Center</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Emergency Contact</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li class="text-danger font-bold tracking-wide flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-danger animate-ping"></span> Hotline: +92 3000000000
                        </li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Terms & Conditions</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="pt-8 border-t border-white/10 text-center text-[13px] text-borderColor/40 tracking-wide">
                &copy; 2026 MedNetwork Systems Inc. All rights reserved. Secure clinical systems architecture verified.
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Mobile responsive layout drawer handler
            const menuBtn = document.getElementById("mobile-menu-btn");
            const navMenu = document.getElementById("nav-links-menu");
            const bar1 = document.getElementById("bar1");
            const bar2 = document.getElementById("bar2");
            const bar3 = document.getElementById("bar3");
            
            menuBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                navMenu.classList.toggle("left-0");
                navMenu.classList.toggle("left-[-100%]");
                
                bar1.classList.toggle("rotate-45");
                bar1.classList.toggle("translate-y-1.5");
                bar2.classList.toggle("opacity-0");
                bar3.classList.toggle("-rotate-45");
                bar3.classList.toggle("-translate-y-1.5");
            });

            document.addEventListener("click", function (e) {
                if (!menuBtn.contains(e.target) && !navMenu.contains(e.target)) {
                    navMenu.classList.add("left-[-100%]");
                    navMenu.classList.remove("left-0");
                    bar1.classList.remove("rotate-45", "translate-y-1.5");
                    bar2.classList.remove("opacity-0");
                    bar3.classList.remove("-rotate-45", "-translate-y-1.5");
                }
            });

            // Navigation Dynamic Scroll Scaling Controller
            const navbar = document.getElementById("main-navbar");
            window.addEventListener("scroll", function() {
                if (window.scrollY > 20) {
                    navbar.classList.remove("h-[80px]");
                    navbar.classList.add("h-[70px]", "shadow-md");
                } else {
                    navbar.classList.remove("h-[70px]", "shadow-md");
                    navbar.classList.add("h-[80px]", "shadow-sm");
                }
            }, { passive: true });

            // Slider Informational Frame Management logic
            const slides = document.querySelectorAll("[data-slide-index]");
            const dots = document.querySelectorAll("#slider-pagination-dots button");
            let currentSlide = 0;

            function goToSlide(index) {
                slides.forEach(slide => {
                    slide.classList.remove("opacity-100", "relative", "pointer-events-auto");
                    slide.classList.add("opacity-0", "absolute", "pointer-events-none");
                });
                slides[index].classList.remove("opacity-0", "absolute", "pointer-events-none");
                slides[index].classList.add("opacity-100", "relative", "pointer-events-auto");

                dots.forEach(dot => {
                    if(parseInt(dot.getAttribute("data-index")) === index) {
                        dot.classList.add("bg-primary", "w-6");
                        dot.classList.remove("bg-white/20", "w-3");
                    } else {
                        dot.classList.remove("bg-primary", "w-6");
                        dot.classList.add("bg-white/20", "w-3");
                    }
                });
                currentSlide = index;
            }

            goToSlide(0);

            dots.forEach(dot => {
                dot.addEventListener("click", function() {
                    goToSlide(parseInt(this.getAttribute("data-index")));
                });
            });

            // Automatic Info Text Transitions (Configured around 5.5s intervals)
            setInterval(() => {
                let next = (currentSlide + 1) % slides.length;
                goToSlide(next);
            }, 5500);

            // Staggered Scroll Animation Observer Frame
            const scrollSections = document.querySelectorAll(".reveal-section");
            const scrollObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if(entry.isIntersecting) {
                        entry.target.classList.add("visible");
                        scrollObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.05 });

            scrollSections.forEach(section => scrollObserver.observe(section));
        });
    </script>
</body>
</html>