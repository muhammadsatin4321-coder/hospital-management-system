<?php 
session_start();
include("includes/conn.php"); 
$current_page = 'index.php';
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinical Digital Network - Welcome | MedNetwork</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: '#F8FAFC',
                        card: '#FFFFFF',
                        primary: '#2563EB',
                        secondary: '#0EA5E9',
                        accent: '#14B8A6',
                        success: '#22C55E',
                        warning: '#F59E0B',
                        danger: '#EF4444',
                        textMain: '#1E293B',
                        borderColor: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        heading: ['Poppins', 'sans-serif']
                    },
                    borderRadius: {
                        'premium': '20px'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F8FAFC;
        }

        .font-heading {
            font-family: 'Poppins', sans-serif;
        }

        .premium-transition { 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
        }
        
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }

        /* Medical Pattern Grid Background Overlay */
        .medical-pattern {
            background-image: radial-gradient(#2563eb 0.75px, transparent 0.75px), radial-gradient(#0ea5e9 0.75px, #F8FAFC 0.75px);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            opacity: 0.15;
        }

        /* Scroll Reveal Systems */
        .reveal-section {
            opacity: 0; 
            transform: translateY(30px); 
            will-change: transform, opacity;
            transition: opacity 0.8s cubic-bezier(0.25, 1, 0.5, 1), transform 0.8s cubic-bezier(0.25, 1, 0.5, 1);
        }
        .reveal-section.visible { 
            opacity: 1; 
            transform: translateY(0); 
        }
    </style>
</head>
<body class="text-textMain antialiased min-h-screen flex flex-col pt-[120px] relative overflow-x-hidden">

    <div id="scroll-progress" class="fixed top-0 left-0 h-1 bg-gradient-to-r from-primary via-secondary to-accent z-[70] w-0 transition-all duration-100"></div>

    <div class="absolute inset-0 medical-pattern pointer-events-none z-0"></div>
    <div class="absolute top-[10%] left-[-5%] w-[450px] h-[450px] bg-secondary/10 rounded-full blur-[120px] pointer-events-none z-0"></div>
    <div class="absolute bottom-[20%] right-[-5%] w-[500px] h-[500px] bg-accent/10 rounded-full blur-[150px] pointer-events-none z-0"></div>

    <div class="bg-danger text-white fixed top-0 left-0 right-0 z-[60] h-[40px] flex items-center text-sm font-medium shadow-sm border-b border-white/10">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <div class="flex items-center gap-6">
                <a href="tel:+15559113940" class="flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91" /></svg>
                    <span class="tracking-wide">Emergency: <strong class="font-semibold">+92 3000000000</strong></span>
                </a>
                <a href="mailto:support@mednetwork.org" class="hidden sm:flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    <span class="opacity-90">support@mednetwork.org</span>
                </a>
            </div>
            <div class="text-xs tracking-widest uppercase font-semibold opacity-90 hidden md:flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-white animate-pulse"></span> Available 24/7 For Urgent Clinical Response
            </div>
        </div>
    </div>

    <nav class="glass-nav fixed top-[40px] left-0 right-0 z-50 h-[80px] flex items-center border-b border-borderColor premium-transition shadow-sm" id="main-navbar">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-textMain group">
                <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 premium-transition">
                    <svg class="text-primary group-hover:scale-110 premium-transition" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                </div>
                <span class="tracking-tight">Med<span class="text-primary font-extrabold">Network</span></span>
            </a>
            
            <button class="md:hidden flex flex-col justify-between w-6 h-4 bg-transparent border-none cursor-pointer z-50 focus:outline-none" id="mobile-menu-btn" aria-label="Toggle navigation menu">
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar1"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition my-auto" id="bar2"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar3"></span>
            </button>
            
            <ul class="fixed md:static top-[120px] left-[-100%] md:left-0 w-full md:w-auto h-[calc(100vh-120px)] md:h-auto bg-card md:bg-transparent border-t border-borderColor md:border-none flex flex-col md:flex-row items-center pt-8 md:pt-0 gap-6 md:gap-8 premium-transition z-40" id="nav-links-menu">
                <li><a href="index.php" class="text-[15px] font-semibold text-primary premium-transition relative py-2 block">Home</a></li>
                <li><a href="services.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Services</a></li>
                <li><a href="doctors.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Our Doctors</a></li>
                <li><a href="about.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">About Us</a></li>
                <li><a href="contact.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Contact</a></li>
                
                <li class="hidden md:block w-px h-5 bg-borderColor mx-1"></li>

                <?php if(isset($_SESSION['patient_email'])): ?>
                    <li class="mt-4 md:mt-0"><a href="appointment.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-lg shadow-primary/10 select-none">Book Appointment</a></li>
                    <li><a href="Patient/dashboard.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition py-2 block">My Account</a></li>
                    <li><a href="logout.php" class="text-[15px] text-danger hover:text-red-700 font-semibold premium-transition py-2 block">Logout</a></li>
                <?php else: ?>
                    <li class="mt-4 md:mt-0"><a href="login.php" class="text-[15px] font-semibold text-textMain/80 hover:text-primary premium-transition py-2 block">Login</a></li>
                    <li class="mt-2 md:mt-0"><a href="register.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-sm">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <header class="relative w-full bg-card overflow-hidden h-[540px] md:h-[600px] z-10 border-b border-borderColor reveal-section">
        <div class="w-full h-full relative" id="slider-frame">
            
            <div class="absolute inset-0 w-full h-full opacity-0 pointer-events-none premium-transition flex items-center" data-slide-index="0">
                <div class="absolute inset-0 bg-gradient-to-r from-card via-card/90 to-transparent z-10"></div>
                <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?q=80&w=1400&auto=format&fit=crop" class="absolute inset-0 w-full h-full object-cover" alt="Clinical Center View">
                <div class="container mx-auto px-6 max-w-[1200px] relative z-20 space-y-6">
                    <span class="inline-flex items-center gap-1.5 bg-primary/10 text-primary border border-primary/20 text-xs px-3.5 py-1.5 rounded-xl uppercase tracking-wider font-bold">Next-Gen Workspace Architecture</span>
                    <h2 class="font-heading text-4xl md:text-[52px] font-bold text-textMain leading-tight tracking-tight max-w-2xl">Complete Medical <br><span class="text-primary">Infrastructure Systems</span></h2>
                    <p class="text-textMain/70 text-[15px] md:text-[16px] max-w-xl font-light leading-relaxed">Systematically orchestrating specialized clinical laboratory pathways, patient records databases, and appointment mapping arrays inside one unified environment.</p>
                    <div class="pt-2"><a href="appointment.php" class="bg-gradient-to-r from-primary to-secondary text-white font-semibold px-7 py-3.5 rounded-xl shadow-lg shadow-primary/20 hover:shadow-primary/40 tracking-wide inline-block premium-transition transform hover:-translate-y-0.5">Initialize Session Suite</a></div>
                </div>
            </div>

            <div class="absolute inset-0 w-full h-full opacity-0 pointer-events-none premium-transition flex items-center" data-slide-index="1">
                <div class="absolute inset-0 bg-gradient-to-r from-card via-card/90 to-transparent z-10"></div>
                <img src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=1400&auto=format&fit=crop" class="absolute inset-0 w-full h-full object-cover" alt="Specialist Evaluation Panel">
                <div class="container mx-auto px-6 max-w-[1200px] relative z-20 space-y-6">
                    <span class="inline-flex items-center gap-1.5 bg-accent/10 text-accent border border-accent/20 text-xs px-3.5 py-1.5 rounded-xl uppercase tracking-wider font-bold">Active Practitioner Registry</span>
                    <h2 class="font-heading text-4xl md:text-[52px] font-bold text-textMain leading-tight tracking-tight max-w-2xl">Verified Clinical <br><span class="text-accent">Specialist Matrices</span></h2>
                    <p class="text-textMain/70 text-[15px] md:text-[16px] max-w-xl font-light leading-relaxed">Direct lines of communication mapped across multiple fields of clinical operation nodes for instantaneous time-slot reservations.</p>
                    <div class="pt-2"><a href="doctors.php" class="bg-textMain text-white font-semibold px-7 py-3.5 rounded-xl shadow-md hover:bg-textMain/90 tracking-wide inline-block premium-transition transform hover:-translate-y-0.5">Scan Practitioner Directory</a></div>
                </div>
            </div>

            <div class="absolute inset-0 w-full h-full opacity-0 pointer-events-none premium-transition flex items-center" data-slide-index="2">
                <div class="absolute inset-0 bg-gradient-to-r from-card via-card/90 to-transparent z-10"></div>
                <img src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=1400&auto=format&fit=crop" class="absolute inset-0 w-full h-full object-cover" alt="Automated Diagnostics Matrix">
                <div class="container mx-auto px-6 max-w-[1200px] relative z-20 space-y-6">
                    <span class="inline-flex items-center gap-1.5 bg-success/10 text-success border border-success/20 text-xs px-3.5 py-1.5 rounded-xl uppercase tracking-wider font-bold">Asynchronous Database Processing</span>
                    <h2 class="font-heading text-4xl md:text-[52px] font-bold text-textMain leading-tight tracking-tight max-w-2xl">Zero-Latency <br><span class="text-success">Operations Router</span></h2>
                    <p class="text-textMain/70 text-[15px] md:text-[16px] max-w-xl font-light leading-relaxed">Book appointments, download authenticated document logs, and configure personal diagnostic schedules dynamically.</p>
                    <div class="pt-2"><a href="about.php" class="bg-background border border-borderColor text-textMain font-semibold px-7 py-3.5 rounded-xl shadow-sm hover:bg-borderColor/5 tracking-wide inline-block premium-transition transform hover:-translate-y-0.5">Explore Architecture Specs</a></div>
                </div>
            </div>

        </div>

        <div class="absolute bottom-8 left-1/2 -translate-x-1/2 z-30 flex gap-3" id="slider-pagination-dots">
            <button class="h-1.5 rounded-full premium-transition bg-textMain/20 w-3 focus:outline-none" data-index="0" aria-label="Go to slide 1"></button>
            <button class="h-1.5 rounded-full premium-transition bg-textMain/20 w-3 focus:outline-none" data-index="1" aria-label="Go to slide 2"></button>
            <button class="h-1.5 rounded-full premium-transition bg-textMain/20 w-3 focus:outline-none" data-index="2" aria-label="Go to slide 3"></button>
        </div>
    </header>

    <main class="flex-grow">
        
        <section class="py-20 relative z-10 reveal-section">
            <div class="w-full max-w-[1200px] mx-auto px-6">
                
                <div class="text-center max-w-2xl mx-auto mb-16 space-y-3">
                    <div class="inline-flex items-center gap-2 bg-primary/10 text-primary font-bold text-xs px-3.5 py-1.5 rounded-xl uppercase tracking-wider border border-primary/20">Operational Modules</div>
                    <h2 class="font-heading text-3xl md:text-4xl font-bold text-textMain tracking-tight">Active Infrastructure Departments</h2>
                    <p class="text-textMain/60 font-light text-[15px] md:text-[16px] leading-relaxed">Select a live system core array node below to query designated staff rosters, structural charting configurations, and domain overviews.</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php 
                    $dept_q = "SELECT * FROM departments ORDER BY name ASC";
                    $dept_res = mysqli_query($conn, $dept_q);

                    if (mysqli_num_rows($dept_res) > 0):
                        while($dept = mysqli_fetch_assoc($dept_res)):
                    ?>
                        <div class="bg-card rounded-premium p-8 border border-borderColor hover:border-primary/30 premium-transition group flex flex-col justify-between items-start gap-6 shadow-sm hover:shadow-xl">
                            <div class="space-y-4 w-full">
                                <div class="w-12 h-12 rounded-xl bg-primary/5 border border-primary/10 text-primary flex items-center justify-center group-hover:scale-110 premium-transition">
                                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14h6v6H4zm10 0h6v6h-6zM4 4h6v6H4zm10 0h6v6h-6z"/></svg>
                                </div>
                                <h3 class="font-heading text-lg font-bold text-textMain tracking-tight group-hover:text-primary transition-colors duration-150">
                                    <?php echo htmlspecialchars($dept['name']); ?>
                                </h3>
                                <p class="text-textMain/60 text-sm font-light leading-relaxed line-clamp-3">
                                    <?php echo htmlspecialchars($dept['description']); ?>
                                </p>
                            </div>

                            <a href="department.php?id=<?php echo $dept['id']; ?>" class="text-[14px] font-bold text-secondary group-hover:text-primary flex items-center gap-1 mt-2 group-hover:translate-x-1 premium-transition">
                                Route into Matrix Node
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                            </a>
                        </div>
                    <?php 
                        endwhile;
                    else:
                    ?>
                        <div class="col-span-full text-center py-16 bg-card rounded-premium border border-dashed border-borderColor text-textMain/50 font-light text-sm">
                            No functional department network arrays found inside database records.
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </section>

    </main>

    <footer class="bg-textMain text-white pt-16 pb-10 border-t border-textMain mt-auto relative z-10 shadow-inner">
        <div class="container mx-auto px-6 max-w-[1200px]">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-10 mb-12">
                <div class="md:col-span-2 space-y-4">
                    <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-white group inline-block">
                        <div class="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
                            <svg class="text-secondary" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                        </div>
                        <span class="tracking-tight">Med<span class="text-secondary font-extrabold">Network</span></span>
                    </a>
                    <p class="text-[14px] text-borderColor/70 max-w-sm leading-relaxed font-light">Providing high-quality clinical operations management tools and professional healthcare networking platforms globally.</p>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Platform</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="index.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Network Modules</a></li>
                        <li><a href="services.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Clinical Services</a></li>
                        <li><a href="doctors.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Doctor Portal</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Resources</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Developer API</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">System Status</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Support Center</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Emergency Contact</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li class="text-danger font-bold tracking-wide flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-danger animate-ping"></span> Hotline: +92 3000000000
                        </li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Terms & Conditions</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="pt-8 border-t border-white/10 text-center text-[13px] text-borderColor/40 tracking-wide flex flex-col sm:flex-row justify-between items-center gap-4">
                <div>&copy; 2026 MedNetwork Systems Inc. All rights reserved.</div>
                <div class="flex items-center gap-2 text-borderColor/60 bg-white/5 px-3 py-1 rounded-full border border-white/5 text-xs">
                    <span class="w-1.5 h-1.5 bg-success rounded-full animate-pulse"></span> Secure Clinical Architecture Verified
                </div>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Scroll Progress Tracker logic
            const scrollProgress = document.getElementById("scroll-progress");
            window.addEventListener("scroll", () => {
                const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
                if (totalHeight > 0) {
                    const progress = (window.scrollY / totalHeight) * 100;
                    scrollProgress.style.width = `${progress}%`;
                }
            });

            // Mobile responsive menu drawer layout controller
            const menuBtn = document.getElementById("mobile-menu-btn");
            const navMenu = document.getElementById("nav-links-menu");
            const bar1 = document.getElementById("bar1");
            const bar2 = document.getElementById("bar2");
            const bar3 = document.getElementById("bar3");
            
            menuBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                navMenu.classList.toggle("left-0");
                navMenu.classList.toggle("left-[-100%]");
                
                bar1.classList.toggle("rotate-45");
                bar1.classList.toggle("translate-y-1.5");
                bar2.classList.toggle("opacity-0");
                bar3.classList.toggle("-rotate-45");
                bar3.classList.toggle("-translate-y-1.5");
            });

            document.addEventListener("click", function (e) {
                if (!menuBtn.contains(e.target) && !navMenu.contains(e.target)) {
                    navMenu.classList.add("left-[-100%]");
                    navMenu.classList.remove("left-0");
                    bar1.classList.remove("rotate-45", "translate-y-1.5");
                    bar2.classList.remove("opacity-0");
                    bar3.classList.remove("-rotate-45", "-translate-y-1.5");
                }
            });

            // Reactive Scroll Adjustments for Navigation Height
            const navbar = document.getElementById("main-navbar");
            window.addEventListener("scroll", function() {
                if (window.scrollY > 20) {
                    navbar.classList.remove("h-[80px]");
                    navbar.classList.add("h-[70px]", "shadow-md");
                } else {
                    navbar.classList.remove("h-[70px]", "shadow-md");
                    navbar.classList.add("h-[80px]", "shadow-sm");
                }
            }, { passive: true });

            // Slider Implementation logic
            const slides = document.querySelectorAll("[data-slide-index]");
            const dots = document.querySelectorAll("#slider-pagination-dots button");
            let currentSlide = 0;

            function goToSlide(index) {
                slides.forEach(slide => {
                    slide.classList.remove("opacity-100", "pointer-events-auto");
                    slide.classList.add("opacity-0", "pointer-events-none");
                });
                slides[index].classList.remove("opacity-0", "pointer-events-none");
                slides[index].classList.add("opacity-100", "pointer-events-auto");

                dots.forEach(dot => {
                    if(parseInt(dot.getAttribute("data-index")) === index) {
                        dot.classList.add("bg-primary", "w-8");
                        dot.classList.remove("bg-textMain/20", "w-3");
                    } else {
                        dot.classList.remove("bg-primary", "w-8");
                        dot.classList.add("bg-textMain/20", "w-3");
                    }
                });
                currentSlide = index;
            }

            goToSlide(0);

            dots.forEach(dot => {
                dot.addEventListener("click", function() {
                    goToSlide(parseInt(this.getAttribute("data-index")));
                });
            });

            // Automatic loop rotation configuration around 6s intervals
            setInterval(() => {
                let next = (currentSlide + 1) % slides.length;
                goToSlide(next);
            }, 6000);

            // Staggered Scroll Animation Observer Frame
            const scrollSections = document.querySelectorAll(".reveal-section");
            const scrollObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if(entry.isIntersecting) {
                        entry.target.classList.add("visible");
                        scrollObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.05 });

            scrollSections.forEach(section => scrollObserver.observe(section));
        });
    </script>
</body>
</html>