<?php
session_start();
ob_start();
include("includes/conn.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

/* USER FETCH WITH SAFE CHECKS */
$user_id = $_SESSION['user_id'];
$name = "";
$email = "";

$user_stmt = mysqli_prepare($conn, "SELECT email, name FROM patients WHERE id = ? LIMIT 1");
if ($user_stmt) {
    mysqli_stmt_bind_param($user_stmt, "i", $user_id);
    mysqli_stmt_execute($user_stmt);
    $user_res = mysqli_stmt_get_result($user_stmt);
    if ($user_row = mysqli_fetch_assoc($user_res)) {
        $email = $user_row['email'];
        $name  = $user_row['name'];
    }
    mysqli_stmt_close($user_stmt);
}

if (empty($email) && !isset($_POST['action']) && !isset($_GET['auto_pdf'])) {
    $session_error = "Patient configuration missing for Token ID: " . htmlspecialchars($user_id);
}

/* =========================
   SECURED AJAX SYSTEM
========================= */
if (isset($_POST['action']))  {
    if ($_POST['action'] == "doctor") {
        $dept = $_POST['department'];
        $stmt = mysqli_prepare($conn, "SELECT doctor_id, name FROM doctors WHERE department = ?");
        mysqli_stmt_bind_param($stmt, "s", $dept);
        mysqli_stmt_execute($stmt);
        $q = mysqli_stmt_get_result($stmt);

        echo "<option value=''>Select Assigned Physician</option>";
        while ($r = mysqli_fetch_assoc($q)) {
            echo "<option value='" . htmlspecialchars($r['doctor_id']) . "'>Dr. " . htmlspecialchars($r['name']) . "</option>";
        }
        mysqli_stmt_close($stmt);
        exit();
    }

    if ($_POST['action'] == "date") {
        $doc = $_POST['doctor'];
        $stmt = mysqli_prepare($conn, "SELECT DISTINCT date, day FROM doctor_schedule WHERE doctor_id = ?");
        mysqli_stmt_bind_param($stmt, "s", $doc); // FIXED: Changed "i" to "s"
        mysqli_stmt_execute($stmt);
        $q = mysqli_stmt_get_result($stmt);

        echo "<option value=''>Select Target Date</option>";
        while ($r = mysqli_fetch_assoc($q)) {
            echo "<option value='" . htmlspecialchars($r['date'] . "|" . $r['day']) . "'>" . htmlspecialchars($r['day'] . " - " . $r['date']) . "</option>";
        }
        mysqli_stmt_close($stmt);
        exit();
    }

    if ($_POST['action'] == "time") {
        $doc = $_POST['doctor'];
        $dt = $_POST['date'];

        $stmt = mysqli_prepare($conn, "SELECT time_slot FROM doctor_schedule WHERE doctor_id = ? AND date = ?");
        mysqli_stmt_bind_param($stmt, "ss", $doc, $dt); // FIXED: Changed "is" to "ss"
        mysqli_stmt_execute($stmt);
        $q = mysqli_stmt_get_result($stmt);

        echo "<option value=''>Select Appointment Time</option>";
        while ($r = mysqli_fetch_assoc($q)) {
            echo "<option value='" . htmlspecialchars($r['time_slot']) . "'>" . htmlspecialchars($r['time_slot']) . "</option>";
        }
        mysqli_stmt_close($stmt);
        exit();
    }
}

/* =========================
   BOOK APPOINTMENT
========================= */
$error_msg = "";

if (isset($_POST['book'])) {
    $name_input = $_POST['name'];
    $contact    = $_POST['contact'];
    $age        = intval($_POST['age']);
    $gender     = $_POST['gender'];
    $blood      = $_POST['blood_group'];
    $dept       = $_POST['department'];
    $doc_id     = $_POST['doctor']; // FIXED: Removed intval() since doctor_id is a string (e.g. DOC001)
    $time       = $_POST['time'];
    $symp       = $_POST['symptom'];

    if (!empty($_POST['date']) && strpos($_POST['date'], '|') !== false) {
        $date_parts = explode("|", $_POST['date']);
        $app_date   = $date_parts[0]; 
        $app_day    = $date_parts[1];
    } else {
        $error_msg = "Please establish a valid calendar date selection.";
    }

    if (empty($error_msg)) {
        $check_duplicate = mysqli_prepare($conn, "SELECT id FROM appointment WHERE doctor_id = ? AND appointment_date = ? AND timing = ? ");
        mysqli_stmt_bind_param($check_duplicate, "sss", $doc_id, $app_date, $time); // FIXED: Changed "iss" to "sss"
        mysqli_stmt_execute($check_duplicate);
        mysqli_stmt_store_result($check_duplicate);
        $dup_rows = mysqli_stmt_num_rows($check_duplicate);
        mysqli_stmt_close($check_duplicate);

        if ($dup_rows > 0) {
            $error_msg = "Selected timeframe is already assigned to another patient.";
        } else {
            $token_stmt = mysqli_prepare($conn, "SELECT COUNT(*) as total FROM appointment WHERE doctor_id = ? AND appointment_date = ?");
            mysqli_stmt_bind_param($token_stmt, "ss", $doc_id, $app_date); // FIXED: Changed "is" to "ss"
            mysqli_stmt_execute($token_stmt);
            $token_res = mysqli_stmt_get_result($token_stmt);
            $token_row = mysqli_fetch_assoc($token_res);
            $token = $token_row['total'] + 1; 
            mysqli_stmt_close($token_stmt);

            if ($token > 10) {
                $error_msg = "Daily capacity threshold achieved for this physician.";
            } else {
                $insert_stmt = mysqli_prepare($conn, "INSERT INTO appointment (patient_name, contact, user_email, department, doctor_id, day, appointment_date, timing, symptom, gender, age, blood_group) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($insert_stmt, "ssssssssssis", $name_input, $contact, $email, $dept, $doc_id, $app_day, $app_date, $time, $symp, $gender, $age, $blood); // FIXED: Changed 5th parameter type from "i" to "s" -> "ssssssssssis"

                if (mysqli_stmt_execute($insert_stmt)) {
                    $last_id = mysqli_insert_id($conn);
                    mysqli_stmt_close($insert_stmt);
                    
                    header("Location: appointment.php?success=1&aid=$last_id");
                    exit();
                } else {
                    $error_msg = "Critical database anomaly during entry registration.";
                    mysqli_stmt_close($insert_stmt);
                }
            }
        }
    }
}

/* ====================================================
   PREMIUM ARCHITECTURAL PDF DOWNLOAD SYSTEM (FPDF)
==================================================== */
if (isset($_GET['auto_pdf'])) {
    require("fpdf/fpdf.php");
    $id = intval($_GET['auto_pdf']);

    $stmt = mysqli_prepare($conn, "SELECT * FROM appointment WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if ($data) {
        $stmt = mysqli_prepare($conn, "SELECT name FROM doctors WHERE doctor_id = ?");
        mysqli_stmt_bind_param($stmt, "s", $data['doctor_id']); // FIXED: Changed "i" to "s"
        mysqli_stmt_execute($stmt);
        $doc = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);

        ob_end_clean();

        class StyledPDF extends FPDF {
            function Footer() {
                // Emptied footer text blocks as requested to clear the document bottom
            }
        }

        $pdf = new StyledPDF('P', 'mm', 'A4');
        $pdf->AddPage();
        $pdf->SetMargins(20, 20, 20);

        $brand_color = array(37, 99, 235);      // #2563EB Deep Medical Blue Accent
        $accent_color = array(20, 184, 166);     // #14B8A6 Teal Accent
        $text_dark = array(30, 41, 59);          // #1E293B Midnight Blue Text
        $bg_light = array(248, 250, 252);       // #F8FAFC Cool Gray Background
        $border_color = array(226, 232, 240);    // #E2E8F0

        $pdf->SetFillColor($brand_color[0], $brand_color[1], $brand_color[2]);
        $pdf->Rect(0, 0, 210, 45, 'F'); 

        $pdf->SetY(12);
        $pdf->SetFont('Arial', 'B', 18);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->Cell(0, 8, 'MEDNETWORK CLINICAL PORTAL', 0, 1, 'C');
        
        $pdf->SetFont('Arial', '', 10);
        $pdf->SetTextColor(255, 255, 255); 
        $pdf->Cell(0, 5, 'Verified Access Receipt & Sequence Token', 0, 1, 'C');

        $pdf->Ln(18);

        $pdf->SetFillColor($bg_light[0], $bg_light[1], $bg_light[2]);
        $pdf->SetDrawColor($brand_color[0], $brand_color[1], $brand_color[2]);
        $pdf->SetLineWidth(0.5);
        $pdf->Rect(55, 52, 100, 24, 'DF');

        $pdf->SetY(55);
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->SetTextColor($text_dark[0], $text_dark[1], $text_dark[2]);
        $pdf->Cell(0, 5, 'ASSIGNED RESERVATION TOKEN', 0, 1, 'C');

        $pdf->SetFont('Arial', 'B', 18);
        $pdf->SetTextColor($brand_color[0], $brand_color[1], $brand_color[2]);
        $formatted_token = "TOKEN - #" . str_pad($id, 4, "0", STR_PAD_LEFT);
        $pdf->Cell(0, 10, $formatted_token, 0, 1, 'C');

        $pdf->Ln(12);

        $pdf->SetFont('Arial', 'B', 12);
        $pdf->SetTextColor($text_dark[0], $text_dark[1], $text_dark[2]);
        $pdf->Cell(0, 6, 'Patient Profile & Chrono Parameters', 0, 1, 'L');
        
        $pdf->SetDrawColor($border_color[0], $border_color[1], $border_color[2]);
        $pdf->SetLineWidth(0.2);
        $pdf->Line(20, $pdf->GetY() + 2, 190, $pdf->GetY() + 2);
        $pdf->Ln(6);

        function renderRow($pdf, $label1, $value1, $label2, $value2, $border) {
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->SetTextColor(100, 116, 139);
            $pdf->Cell(40, 11, '  ' . $label1, 0, 0, 'L');
            
            $pdf->SetFont('Arial', '', 11);
            $pdf->SetTextColor(30, 41, 59);
            $pdf->Cell(45, 11, $value1, 0, 0, 'L');
            
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->SetTextColor(100, 116, 139);
            $pdf->Cell(40, 11, '  ' . $label2, 0, 0, 'L');
            
            $pdf->SetFont('Arial', '', 11);
            $pdf->SetTextColor(30, 41, 59);
            $pdf->Cell(45, 11, $value2, 0, 1, 'L');

            $pdf->SetDrawColor($border[0], $border[1], $border[2]);
            $pdf->Line(20, $pdf->GetY(), 190, $pdf->GetY());
        }

        renderRow($pdf, 'Patient Name:', $data['patient_name'], 'Contact No:', $data['contact'], $border_color);
        renderRow($pdf, 'Age / Gender:', $data['age'] . ' Yrs / ' . $data['gender'], 'Blood Group:', $data['blood_group'], $border_color);
        renderRow($pdf, 'Department:', $data['department'], 'Assigned Doctor:', 'Dr. ' . ($doc['name'] ?? 'Staff Expert'), $border_color);
        renderRow($pdf, 'Target Date:', $data['appointment_date'] . ' (' . $data['day'] . ')', 'Time Slot:', $data['timing'], $border_color);

        $pdf->Ln(10);

        if(!empty($data['symptom'])) {
            $pdf->SetFont('Arial', 'B', 11);
            $pdf->SetTextColor($brand_color[0], $brand_color[1], $brand_color[2]);
            $pdf->Cell(0, 6, 'Symptom Manifesto / Background Notes', 0, 1, 'L');
            $pdf->Ln(2);

            $pdf->SetFillColor(250, 250, 250);
            $pdf->SetDrawColor($border_color[0], $border_color[1], $border_color[2]);
            
            $pdf->SetFont('Arial', 'I', 10);
            $pdf->SetTextColor(71, 85, 105);
            
            $current_y = $pdf->GetY();
            $pdf->Rect(20, $current_y, 170, 22, 'DF');
            $pdf->SetY($current_y + 3);
            $pdf->SetX(24);
            $pdf->MultiCell(162, 5, $data['symptom'], 0, 'L');
        }

        $pdf->SetY(190);
        $pdf->SetDrawColor($text_dark[0], $text_dark[1], $text_dark[2]);
        $pdf->SetLineWidth(0.4);
        $pdf->Line(60, $pdf->GetY(), 150, $pdf->GetY());
        
        $pdf->Ln(2);
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->SetTextColor($text_dark[0], $text_dark[1], $text_dark[2]);
        $pdf->Cell(0, 5, 'SECURE CRYPTO-GRAPHIC SIGNATURE STAMP', 0, 1, 'C');
        
        $pdf->SetFont('Arial', '', 8);
        $pdf->SetTextColor(148, 163, 184);
        $pdf->Cell(0, 4, 'INTEGRITY VERIFICATION: ' . md5($data['id'].$data['appointment_date'].$data['patient_name']), 0, 1, 'C');

        $pdf->Output('D', "Clinical_Token_Receipt_$id.pdf");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinical Check-In Portal | MedNetwork</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: '#F8FAFC',
                        card: '#FFFFFF',
                        primary: '#2563EB',
                        secondary: '#0EA5E9',
                        accent: '#14B8A6',
                        success: '#22C55E',
                        warning: '#F59E0B',
                        danger: '#EF4444',
                        textMain: '#1E293B',
                        borderColor: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        heading: ['Poppins', 'sans-serif']
                    },
                    borderRadius: {
                        'premium': '20px'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F8FAFC;
        }

        .font-heading {
            font-family: 'Poppins', sans-serif;
        }

        .premium-transition { 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
        }
        
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }

        /* Medical Pattern Grid Background Overlay */
        .medical-pattern {
            background-image: radial-gradient(#2563eb 0.75px, transparent 0.75px), radial-gradient(#0ea5e9 0.75px, #F8FAFC 0.75px);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            opacity: 0.2;
        }

        /* Scroll Reveal Systems */
        .reveal-section {
            opacity: 0; 
            transform: translateY(30px); 
            will-change: transform, opacity;
            transition: opacity 0.8s cubic-bezier(0.25, 1, 0.5, 1), transform 0.8s cubic-bezier(0.25, 1, 0.5, 1);
        }
        .reveal-section.visible { 
            opacity: 1; 
            transform: translateY(0); 
        }

        .form-input-focus:focus {
            border-color: #2563EB;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
            background-color: #FFFFFF;
        }
    </style>
</head>
<body class="text-textMain antialiased min-h-screen flex flex-col pt-[120px] relative overflow-x-hidden">

    <div class="absolute inset-0 medical-pattern pointer-events-none z-0"></div>
    <div class="absolute top-[10%] left-[-5%] w-[450px] h-[450px] bg-secondary/10 rounded-full blur-[120px] pointer-events-none z-0"></div>
    <div class="absolute bottom-[10%] right-[-5%] w-[500px] h-[500px] bg-accent/10 rounded-full blur-[150px] pointer-events-none z-0"></div>

    <div class="bg-danger text-white fixed top-0 left-0 right-0 z-[60] h-[40px] flex items-center text-sm font-medium shadow-sm border-b border-white/10">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <div class="flex items-center gap-6">
                <a href="tel:0310203040" class="flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91" /></svg>
                    <span class="tracking-wide">Emergency Support: <strong class="font-semibold">0310203040</strong></span>
                </a>
                <a href="mailto:support@mednetwork.org" class="hidden sm:flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    <span class="opacity-90">support@mednetwork.org</span>
                </a>
            </div>
            <div class="text-xs tracking-widest uppercase font-semibold opacity-90 hidden md:block flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-white animate-pulse"></span> Available 24/7 Response Hotline
            </div>
        </div>
    </div>

    <nav class="glass-nav fixed top-[40px] left-0 right-0 z-50 h-[80px] flex items-center border-b border-borderColor premium-transition shadow-sm" id="main-navbar">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-textMain group">
                <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 premium-transition">
                    <svg class="text-primary group-hover:scale-110 premium-transition" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                </div>
                <span class="tracking-tight">Med<span class="text-primary font-extrabold">Network</span></span>
            </a>
            
            <button class="md:hidden flex flex-col justify-between w-6 h-4 bg-transparent border-none cursor-pointer z-50 focus:outline-none" id="mobile-menu-btn" aria-label="Toggle navigation menu">
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar1"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition my-auto" id="bar2"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar3"></span>
            </button>
            
            <ul class="fixed md:static top-[120px] left-[-100%] md:left-0 w-full md:w-auto h-[calc(100vh-120px)] md:h-auto bg-card md:bg-transparent border-t border-borderColor md:border-none flex flex-col md:flex-row items-center pt-8 md:pt-0 gap-6 md:gap-8 premium-transition z-40" id="nav-links-menu">
                <li><a href="index.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Home</a></li>
                <li><a href="services.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Services</a></li>
                <li><a href="doctors.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Our Doctors</a></li>
                <li><a href="about.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">About Us</a></li>
                <li><a href="contact.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Contact</a></li>
                
                <li class="hidden md:block w-px h-5 bg-borderColor mx-1"></li>

                <?php if(isset($_SESSION['patient_email'])): ?>
                    <li class="mt-4 md:mt-0"><a href="appointment.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-lg shadow-primary/10 select-none">Book Appointment</a></li>
                    <li><a href="Patient/dashboard.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition py-2 block">My Account</a></li>
                    <li><a href="logout.php" class="text-[15px] text-danger hover:text-red-700 font-semibold premium-transition py-2 block">Logout</a></li>
                <?php else: ?>
                    <li class="mt-4 md:mt-0"><a href="login.php" class="text-[15px] font-semibold text-textMain/80 hover:text-primary premium-transition py-2 block">Login</a></li>
                    <li class="mt-2 md:mt-0"><a href="register.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-sm">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <?php if (isset($_GET['success']) && isset($_GET['aid'])): ?>
        <div class="fixed inset-0 bg-textMain/40 backdrop-blur-md flex items-center justify-center z-[99999] opacity-100 transition-opacity duration-300" id="successModal">
            <div class="bg-card border border-borderColor w-11/12 max-w-md p-8 rounded-premium text-center shadow-2xl transform scale-100 transition-transform duration-300">
                <div class="w-16 h-16 bg-success/10 text-success text-3xl rounded-full flex items-center justify-center mx-auto mb-5 border border-success/20">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <h3 class="font-heading text-xl font-bold text-textMain mb-2">Check-In Confirmed</h3>
                <p class="text-textMain/70 text-[14px] leading-relaxed mb-6">Your specialized clinical schedule queue allocation sequence has been locked. Your digital verification receipt link is prepared below.</p>
                <a class="text-[14px] block bg-gradient-to-r from-primary to-secondary hover:shadow-lg hover:shadow-primary/20 text-white py-3.5 px-4 rounded-xl font-bold shadow-md premium-transition transform hover:-translate-y-0.5 active:translate-y-0 text-center" href="appointment.php?auto_pdf=<?php echo intval($_GET['aid']); ?>">Get Digital Ticket Pass</a>
                <button class="text-textMain/50 hover:text-primary text-xs font-semibold underline bg-transparent border-0 cursor-pointer mt-4" onclick="closeModal()">Dismiss View</button>
            </div>
        </div>
        <script>
            window.addEventListener('DOMContentLoaded', () => {
                setTimeout(() => {
                    window.location.href = "appointment.php?auto_pdf=<?php echo intval($_GET['aid']); ?>";
                }, 500);
            });
            function closeModal() {
                document.getElementById('successModal').classList.add('hidden');
                window.history.replaceState({}, document.title, "appointment.php");
            }
        </script>
    <?php endif; ?>

    <main class="w-full max-w-[1200px] mx-auto px-6 py-12 relative z-10 flex-grow reveal-section">
        <div class="bg-card border border-borderColor rounded-premium overflow-hidden shadow-sm grid grid-cols-1 lg:grid-cols-12">
            
            <div class="p-8 lg:p-12 lg:col-span-4 bg-background border-b lg:border-b-0 lg:border-r border-borderColor flex flex-col justify-between relative overflow-hidden">
                <div class="relative z-10">
                    <div class="inline-flex items-center gap-2 bg-primary/10 text-primary font-bold text-xs px-3.5 py-1.5 rounded-xl uppercase tracking-wider border border-primary/20 mb-6">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        Scheduler Node
                    </div>
                    <h1 class="font-heading text-3xl font-bold tracking-tight text-textMain mb-4 leading-tight">Clinical Entry<br>Voucher Pass</h1>
                    <p class="text-textMain/70 text-[14px] leading-relaxed">Submit the dynamic router configurations to securely block a direct verified appointment track link with our medical specialist faculty.</p>
                </div>
                
                <div class="mt-12 space-y-6 lg:space-y-8 relative z-10">
                    <div class="flex gap-4 items-start group">
                        <div class="bg-card text-primary border border-borderColor w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 shadow-sm group-hover:bg-primary group-hover:text-white premium-transition">1</div>
                        <div>
                            <h4 class="text-[15px] font-bold text-textMain tracking-tight">Identity Node</h4>
                            <p class="text-textMain/60 text-xs mt-0.5">Define patient demographics parameters cleanly.</p>
                        </div>
                    </div>
                    <div class="flex gap-4 items-start group">
                        <div class="bg-card text-primary border border-borderColor w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 shadow-sm group-hover:bg-primary group-hover:text-white premium-transition">2</div>
                        <div>
                            <h4 class="text-[15px] font-bold text-textMain tracking-tight">Physician Routing</h4>
                            <p class="text-textMain/60 text-xs mt-0.5">Select clinical departments and active doctors.</p>
                        </div>
                    </div>
                    <div class="flex gap-4 items-start group">
                        <div class="bg-card text-primary border border-borderColor w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 shadow-sm group-hover:bg-primary group-hover:text-white premium-transition">3</div>
                        <div>
                            <h4 class="text-[15px] font-bold text-textMain tracking-tight">Voucher Generation</h4>
                            <p class="text-textMain/60 text-xs mt-0.5">Lock verified digital sequence pass allocations.</p>
                        </div>
                    </div>
                </div>

                <div class="absolute -left-16 -bottom-16 text-primary/[0.02] pointer-events-none">
                    <svg width="240" height="240" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/></svg>
                </div>
            </div>

            <div class="p-8 lg:p-12 lg:col-span-8 bg-card">
                <?php if (!empty($error_msg)): ?>
                    <div class="bg-danger/5 border border-danger/20 text-danger px-5 py-4 rounded-xl text-[14px] font-medium mb-6 flex items-center gap-2">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        <span><?php echo htmlspecialchars($error_msg); ?></span>
                    </div>
                <?php endif; ?>

                <?php if (!empty($session_error)): ?>
                    <div class="bg-danger/5 border border-danger/20 text-danger px-5 py-4 rounded-xl text-[14px] font-medium mb-6 flex items-center gap-2">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        <span><?php echo $session_error; ?></span>
                    </div>
                <?php endif; ?>

                <form method="POST" class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="flex flex-col gap-2">
                            <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Full Patient Name Identity</label>
                            <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" required class="w-full px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium">
                        </div>

                        <div class="flex flex-col gap-2">
                            <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Linked Verification Account Email</label>
                            <input type="email" value="<?php echo htmlspecialchars($email); ?>" readonly class="w-full px-4 py-3 bg-background/60 border border-borderColor/60 text-textMain/50 rounded-xl text-[14px] outline-none cursor-not-allowed font-medium select-none" title="Linked directly to your security profile.">
                        </div>

                        <div class="flex flex-col gap-2">
                            <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Secure Contact Mobile Line</label>
                            <input type="text" name="contact" placeholder="e.g. +123456789" required class="w-full px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium">
                        </div>

                        <div class="flex flex-col gap-2">
                            <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Patient Age Metric (Years)</label>
                            <input type="number" name="age" min="1" max="120" placeholder="Years" required class="w-full px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium">
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <div class="flex flex-col gap-2">
                                <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Gender Option</label>
                                <select name="gender" class="w-full px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium">
                                    <option>Male</option>
                                    <option>Female</option>
                                </select>
                            </div>
                            <div class="flex flex-col gap-2">
                                <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Blood Matrix</label>
                                <select name="blood_group" class="w-full px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium">
                                    <option>A+</option><option>B+</option><option>O+</option><option>AB+</option>
                                    <option>A-</option><option>B-</option><option>O-</option><option>AB-</option>
                                </select>
                            </div>
                        </div>

                        <div class="flex flex-col gap-2">
                            <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Target Clinic Department</label>
                            <select name="department" id="department" required class="w-full px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium">
                                <option value="">Select Department</option>
                                <?php
                                $d = mysqli_query($conn, "SELECT DISTINCT department FROM doctors");
                                while ($r = mysqli_fetch_assoc($d)) {
                                    echo "<option value='" . htmlspecialchars($r['department']) . "'>" . htmlspecialchars($r['department']) . "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="flex flex-col gap-2">
                            <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Assigned Physician Faculty</label>
                            <select name="doctor" id="doctor" required class="w-full px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium">
                                <option value="">Awaiting Department</option>
                            </select>
                        </div>

                        <div class="flex flex-col gap-2">
                            <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Calendar Target Date</label>
                            <select name="date" id="date" required class="w-full px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium">
                                <option value="">Awaiting Physician</option>
                            </select>
                        </div>

                        <div class="flex flex-col gap-2">
                            <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Chrono Time Slot Block</label>
                            <select name="time" id="time" required class="w-full px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium">
                                <option value="">Awaiting Calendar Date</option>
                            </select>
                        </div>
                    </div>

                    <div class="flex flex-col gap-2">
                        <label class="text-xs font-bold uppercase tracking-wider text-textMain/60">Symptom Manifesto Parameters</label>
                        <textarea name="symptom" placeholder="Elaborate details on current medical condition or clinical notes..." class="w-full min-h-[110px] px-4 py-3 bg-background border border-borderColor rounded-xl text-[14px] outline-none form-input-focus transition duration-200 text-textMain font-medium"></textarea>
                    </div>

                    <button type="submit" name="book" class="text-[14px] w-full bg-gradient-to-r from-primary to-secondary text-white py-4 font-bold rounded-xl shadow-lg shadow-primary/20 transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0">EXECUTE ALLOCATED CHECK-IN</button>
                </form>
            </div>
        </div>
    </main>

    <footer class="bg-textMain text-white pt-16 pb-10 border-t border-textMain mt-auto relative z-10 shadow-inner">
        <div class="container mx-auto px-6 max-w-[1200px]">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-10 mb-12">
                <div class="md:col-span-2 space-y-4">
                    <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-white group inline-block">
                        <div class="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
                            <svg class="text-secondary" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                        </div>
                        <span class="tracking-tight">Med<span class="text-secondary font-extrabold">Network</span></span>
                    </a>
                    <p class="text-[14px] text-borderColor/70 max-w-sm leading-relaxed font-light">Providing high-quality clinical operations management tools and professional healthcare networking platforms globally.</p>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Platform</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="index.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Network Modules</a></li>
                        <li><a href="services.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Clinical Services</a></li>
                        <li><a href="doctors.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Doctor Portal</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Resources</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Developer API</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">System Status</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Support Center</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Emergency Contact</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li class="text-danger font-bold tracking-wide flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-danger animate-ping"></span> Hotline: 0310203040
                        </li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Terms & Conditions</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="pt-8 border-t border-white/10 text-center text-[13px] text-borderColor/40 tracking-wide">
                &copy; 2026 MedNetwork Systems Inc. All rights reserved. Secure clinical systems architecture verified.
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Mobile responsive menu drawer layout controller
            const menuBtn = document.getElementById("mobile-menu-btn");
            const navMenu = document.getElementById("nav-links-menu");
            const bar1 = document.getElementById("bar1");
            const bar2 = document.getElementById("bar2");
            const bar3 = document.getElementById("bar3");
            
            menuBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                navMenu.classList.toggle("left-0");
                navMenu.classList.toggle("left-[-100%]");
                
                bar1.classList.toggle("rotate-45");
                bar1.classList.toggle("translate-y-1.5");
                bar2.classList.toggle("opacity-0");
                bar3.classList.toggle("-rotate-45");
                bar3.classList.toggle("-translate-y-1.5");
            });
            
            document.addEventListener("click", function (e) {
                if (!menuBtn.contains(e.target) && !navMenu.contains(e.target)) {
                    navMenu.classList.add("left-[-100%]");
                    navMenu.classList.remove("left-0");
                    bar1.classList.remove("rotate-45", "translate-y-1.5");
                    bar2.classList.remove("opacity-0");
                    bar3.classList.remove("-rotate-45", "-translate-y-1.5");
                }
            });

            // Reactive Scroll Adjustments for Navigation Height
            const navbar = document.getElementById("main-navbar");
            window.addEventListener("scroll", function() {
                if (window.scrollY > 20) {
                    navbar.classList.remove("h-[80px]");
                    navbar.classList.add("h-[70px]", "shadow-md");
                } else {
                    navbar.classList.remove("h-[70px]", "shadow-md");
                    navbar.classList.add("h-[80px]", "shadow-sm");
                }
            }, { passive: true });

            // Staggered Scroll Animation Observer Frame
            const revealElement = document.querySelector(".reveal-section");
            if (revealElement) {
                const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if(entry.isIntersecting) {
                            entry.target.classList.add("visible");
                        }
                    });
                }, { threshold: 0.05 });
                observer.observe(revealElement);
            }
        });

        // Cascading Booking System Asynchronous Core via JQuery AJAX
        $(document).ready(function() {
            $("#department").change(function() {
                var dept = $(this).val();
                if (dept !== "") {
                    $.post("", {action: "doctor", department: dept}, function(data) {
                        $("#doctor").html(data);
                        $("#date").html("<option value=''>Awaiting Physician</option>");
                        $("#time").html("<option value=''>Awaiting Calendar Date</option>");
                    });
                }
            });

            $("#doctor").change(function() {
                var doc = $(this).val();
                if (doc !== "") {
                    $.post("", {action: "date", doctor: doc}, function(data) {
                        $("#date").html(data);
                        $("#time").html("<option value=''>Awaiting Calendar Date</option>");
                    });
                }
            });

            $("#date").change(function() {
                var rawDate = $(this).val();
                var doc = $("#doctor").val();
                if (rawDate !== "" && doc !== "") {
                    var dt = rawDate.split("|")[0];
                    $.post("", {action: "time", doctor: doc, date: dt}, function(data) {
                        $("#time").html(data);
                    });
                }
            });
        });
    </script>
</body>
</html>