<?php 
session_start();
include("includes/conn.php"); 
$current_page = 'about.php';
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Our Organization | MedNetwork</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: '#F8FAFC',
                        card: '#FFFFFF',
                        primary: '#2563EB',
                        secondary: '#0EA5E9',
                        accent: '#14B8A6',
                        success: '#22C55E',
                        warning: '#F59E0B',
                        danger: '#EF4444',
                        textMain: '#1E293B',
                        borderColor: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        heading: ['Poppins', 'sans-serif']
                    },
                    borderRadius: {
                        'premium': '20px'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F8FAFC;
        }

        .font-heading {
            font-family: 'Poppins', sans-serif;
        }

        .premium-transition { 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
        }
        
        /* Modern Glassmorphism Utilities */
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }

        /* Hero Image Layout Effects & Cinematic Zoom */
        .hero-overlay::before {
            content: ''; 
            position: absolute; 
            inset: 0; 
            z-index: 1;
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.75) 0%, rgba(14, 165, 233, 0.5) 100%);
        }
        
        @keyframes zoomCinematic { 
            from { transform: scale(1); } 
            to { transform: scale(1.08); } 
        }
        .zoom-bg-cinematic { 
            animation: zoomCinematic 12s ease-in-out infinite alternate; 
        }

        /* Premium Medical Subtle Floating Grid Pattern */
        .medical-pattern {
            background-image: radial-gradient(#2563eb 0.75px, transparent 0.75px), radial-gradient(#0ea5e9 0.75px, #F8FAFC 0.75px);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            opacity: 0.25;
        }

        /* Scroll Reveal System */
        .reveal-section {
            opacity: 0; 
            transform: translateY(30px); 
            will-change: transform, opacity;
            transition: opacity 0.8s cubic-bezier(0.25, 1, 0.5, 1), transform 0.8s cubic-bezier(0.25, 1, 0.5, 1);
        }
        .reveal-section.visible { 
            opacity: 1; 
            transform: translateY(0); 
        }

        /* Ripple Action Effect Prep */
        .btn-ripple {
            position: relative;
            overflow: hidden;
        }
    </style>
</head>
<body class="text-textMain antialiased min-h-screen flex flex-col pt-[120px] relative overflow-x-hidden">

    <div class="absolute inset-0 medical-pattern pointer-events-none z-0"></div>
    <div class="absolute top-[30%] left-[-10%] w-[450px] h-[450px] bg-secondary/10 rounded-full blur-[120px] pointer-events-none z-0"></div>
    <div class="absolute bottom-[20%] right-[-10%] w-[500px] h-[500px] bg-accent/10 rounded-full blur-[150px] pointer-events-none z-0"></div>

    <div class="bg-danger text-white fixed top-0 left-0 right-0 z-[60] h-[40px] flex items-center text-sm font-medium shadow-sm border-b border-white/10">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <div class="flex items-center gap-6">
                <a href="tel:0310203040" class="flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91" /></svg>
                    <span class="tracking-wide">Emergency Support: <strong class="font-semibold">0310203040</strong></span>
                </a>
                <a href="mailto:msarim@gmail.com" class="hidden sm:flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    <span class="opacity-90">msarim@gmail.com</span>
                </a>
            </div>
            <div class="text-xs tracking-widest uppercase font-semibold opacity-90 hidden md:block flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-white animate-pulse"></span> Available 24/7 Response Hotline
            </div>
        </div>
    </div>

    <nav class="glass-nav fixed top-[40px] left-0 right-0 z-50 h-[80px] flex items-center border-b border-borderColor premium-transition shadow-sm" id="main-navbar">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-textMain group">
                <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 premium-transition">
                    <svg class="text-primary group-hover:scale-110 premium-transition" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                </div>
                <span class="tracking-tight">Med<span class="text-primary font-extrabold">Network</span></span>
            </a>
            
            <button class="md:hidden flex flex-col justify-between w-6 h-4 bg-transparent border-none cursor-pointer z-50 focus:outline-none" id="mobile-menu-btn" aria-label="Toggle navigation menu">
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar1"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition my-auto" id="bar2"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar3"></span>
            </button>
            
            <ul class="fixed md:static top-[120px] left-[-100%] md:left-0 w-full md:w-auto h-[calc(100vh-120px)] md:h-auto bg-card md:bg-transparent border-t border-borderColor md:border-none flex flex-col md:flex-row items-center pt-8 md:pt-0 gap-6 md:gap-8 premium-transition z-40" id="nav-links-menu">
                <li><a href="index.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Home</a></li>
                <li><a href="services.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Services</a></li>
                <li><a href="doctors.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Our Doctors</a></li>
                <li><a href="about.php" class="text-[15px] font-semibold text-primary relative py-2 block after:absolute after:bottom-0 after:left-0 after:w-full after:h-0.5 after:bg-primary after:rounded-full">About Us</a></li>
                <li><a href="contact.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Contact</a></li>
                
                <li class="hidden md:block w-px h-5 bg-borderColor mx-1"></li>

                <?php if(isset($_SESSION['patient_email'])): ?>
                    <li class="mt-4 md:mt-0"><a href="appointment.php" class="btn-ripple text-[14px] bg-gradient-to-r from-primary to-secondary hover:shadow-lg hover:shadow-primary/20 hover:-translate-y-0.5 active:translate-y-0 text-white font-semibold px-5 py-2.5 rounded-xl premium-transition block text-center">Book Appointment</a></li>
                    <li><a href="Patient/dashboard.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition py-2 block">My Account</a></li>
                    <li><a href="logout.php" class="text-[15px] text-danger hover:text-red-700 font-semibold premium-transition py-2 block">Logout</a></li>
                <?php else: ?>
                    <li class="mt-4 md:mt-0"><a href="login.php" class="text-[15px] font-semibold text-textMain/80 hover:text-primary premium-transition py-2 block">Login</a></li>
                    <li class="mt-2 md:mt-0"><a href="register.php" class="btn-ripple text-[14px] bg-gradient-to-r from-primary to-secondary hover:shadow-lg hover:shadow-primary/20 hover:-translate-y-0.5 active:translate-y-0 text-white font-semibold px-5 py-2.5 rounded-xl premium-transition block text-center shadow-sm">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="relative w-full h-[540px] overflow-hidden bg-textMain flex flex-col justify-stretch z-10 shadow-md">
        <div class="flex w-[300%] h-full flex-grow transition-transform duration-700 cubic-bezier(0.4, 0, 0.2, 1)" id="slider-track">
            
            <div class="w-1/3 h-full relative hero-overlay flex items-center overflow-hidden">
                <div class="absolute inset-0 bg-cover bg-center zoom-bg-cinematic" style="background-image: url('https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?q=80&w=1920&h=650&auto=format&fit=crop');"></div>
                <div class="relative z-10 w-full max-w-[1200px] mx-auto px-6 text-left text-white">
                    <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-semibold tracking-wider uppercase mb-4 animate-fade-in">
                        <span class="w-1.5 h-1.5 rounded-full bg-accent"></span> Connected Healthcare Infrastructure
                    </span>
                    <h1 class="font-heading text-4xl md:text-[54px] font-bold text-white mb-5 leading-[1.15]">Advanced Connected<br>Healthcare Systems</h1>
                    <p class="text-[16px] md:text-[18px] mb-8 text-white/90 max-w-xl leading-relaxed font-light">Streamlining critical clinical operations, routing metrics, and clinical scheduling parameters across secure cloud network layouts flawlessly.</p>
                    <div class="flex flex-wrap gap-4">
                        <a href="register.php" class="btn-ripple text-[14px] bg-white hover:bg-white/90 text-primary font-bold px-8 py-3.5 rounded-xl shadow-lg hover:-translate-y-0.5 active:translate-y-0 premium-transition">Get Network Access</a>
                        <a href="appointment.php" class="btn-ripple text-[14px] bg-gradient-to-r from-danger to-red-500 hover:shadow-lg hover:shadow-danger/30 text-white font-bold px-8 py-3.5 rounded-xl shadow-md hover:-translate-y-0.5 active:translate-y-0 premium-transition">Emergency Routing</a>
                    </div>
                </div>
            </div>
            
            <div class="w-1/3 h-full relative hero-overlay flex items-center overflow-hidden">
                <div class="absolute inset-0 bg-cover bg-center zoom-bg-cinematic" style="background-image: url('https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?q=80&w=1920&h=650&auto=format&fit=crop');"></div>
                <div class="relative z-10 w-full max-w-[1200px] mx-auto px-6 text-left text-white">
                    <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-semibold tracking-wider uppercase mb-4">
                        <span class="w-1.5 h-1.5 rounded-full bg-accent"></span> Certified Specialists Faculty
                    </span>
                    <h1 class="font-heading text-4xl md:text-[54px] font-bold text-white mb-5 leading-[1.15]">Expert Specialized<br>Physicians Faculty</h1>
                    <p class="text-[16px] md:text-[18px] mb-8 text-white/90 max-w-xl leading-relaxed font-light">Instantly map diagnostic workflows directly to medical directors, tracking parameters safely through internal channels.</p>
                    <div>
                        <a href="doctors.php" class="btn-ripple text-[14px] bg-white hover:bg-white/90 text-primary font-bold px-8 py-3.5 rounded-xl shadow-lg hover:-translate-y-0.5 active:translate-y-0 premium-transition">Meet Our Faculty</a>
                    </div>
                </div>
            </div>
            
            <div class="w-1/3 h-full relative hero-overlay flex items-center overflow-hidden">
                <div class="absolute inset-0 bg-cover bg-center zoom-bg-cinematic" style="background-image: url('https://images.unsplash.com/photo-1584515901107-99b44a60c283?q=80&w=1920&h=650&auto=format&fit=crop');"></div>
                <div class="relative z-10 w-full max-w-[1200px] mx-auto px-6 text-left text-white">
                    <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-semibold tracking-wider uppercase mb-4">
                        <span class="w-1.5 h-1.5 rounded-full bg-accent"></span> Optimized Diagnostics Ecosystem
                    </span>
                    <h1 class="font-heading text-4xl md:text-[54px] font-bold text-white mb-5 leading-[1.15]">Patient Centric<br>Diagnostics Tracking</h1>
                    <p class="text-[16px] md:text-[18px] mb-8 text-white/90 max-w-xl leading-relaxed font-light">Log inside secure profiles to establish appointment requests, print verified records, and track updates on dashboard panels.</p>
                    <div>
                        <a href="appointment.php" class="btn-ripple text-[14px] bg-gradient-to-r from-secondary to-accent hover:shadow-lg text-white font-bold px-8 py-3.5 rounded-xl shadow-lg hover:-translate-y-0.5 active:translate-y-0 premium-transition">Book Consultation Now</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="absolute bottom-8 left-0 right-0 z-20 mx-auto max-w-[1200px] px-6 flex justify-start items-center gap-3">
            <div class="slider-dot h-2 bg-white rounded-full cursor-pointer premium-transition" data-index="0"></div>
            <div class="slider-dot h-2 bg-white rounded-full cursor-pointer premium-transition" data-index="1"></div>
            <div class="slider-dot h-2 bg-white rounded-full cursor-pointer premium-transition" data-index="2"></div>
        </div>
    </div>
       
    <section class="border-b border-borderColor bg-card/60 backdrop-blur-sm py-16 text-center relative z-10 reveal-section">
        <div class="w-full max-w-[1200px] mx-auto px-6">
            <h2 class="font-heading text-3xl md:text-[40px] font-bold text-textMain mb-4 tracking-tight">Pioneering Next-Gen Healthcare</h2>
            <div class="w-16 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mb-6 rounded-full"></div>
            <p class="text-[16px] md:text-[18px] text-textMain/70 font-medium max-w-3xl mx-auto leading-relaxed">Discover the core philosophies and structural architectural standards driving our medical network operations forward.</p>
        </div>
    </section>

    <main class="py-20 relative z-10 flex-grow reveal-section">
        <div class="w-full max-w-[1200px] mx-auto px-6">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
                
                <div class="lg:col-span-7 space-y-6">
                    <div class="inline-flex items-center gap-2 bg-primary/10 text-primary font-bold text-xs px-4 py-2 rounded-xl uppercase tracking-wider border border-primary/20 shadow-sm">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        Operational Charter
                    </div>
                    <h3 class="font-heading text-2xl md:text-[32px] font-bold text-textMain tracking-tight leading-snug">Our Dedicated Mission Objective</h3>
                    <p class="text-[16px] text-textMain/80 font-normal leading-relaxed">
                        We bridge the gap between complex laboratory analysis records and patient management frameworks. Our systems ensure every check-in parameter, clinical registration component, and security token remains transparent and highly resilient.
                    </p>
                    <p class="text-[16px] text-textMain/80 font-normal leading-relaxed bg-primary/5 p-5 rounded-premium border-l-4 border-primary">
                        Through integrated health software architectures, our networks ensure direct accountability over client accounts and real-time appointment request scheduling metrics.
                    </p>
                </div>
                
                <div class="lg:col-span-5 w-full">
                    <div class="w-full rounded-premium bg-card border border-borderColor flex flex-col items-start justify-center p-8 text-left select-none shadow-sm hover:shadow-xl hover:-translate-y-1.5 border-t-[5px] border-t-secondary hover:border-t-primary premium-transition group relative overflow-hidden">
                        <div class="absolute -right-6 -bottom-6 text-primary/[0.03] pointer-events-none group-hover:scale-110 premium-transition">
                            <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="12 2 2 7 12 12 22 7 12 2"/></svg>
                        </div>
                        <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white text-secondary premium-transition">
                            <svg class="premium-transition" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>
                        </div>
                        <h4 class="font-heading text-[22px] font-bold text-textMain tracking-tight mb-2">
                            Platform Blueprints
                        </h4>
                        <p class="text-[14px] text-textMain/70 font-medium leading-relaxed">Integrated medical dashboard data tracking systems map architectural information parameters securely.</p>
                    </div>
                </div>
                
            </div>
        </div>
    </main>

    <footer class="bg-textMain text-white pt-16 pb-10 border-t border-textMain mt-auto relative z-10 shadow-inner">
        <div class="container mx-auto px-6 max-w-[1200px]">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-10 mb-12">
                <div class="md:col-span-2 space-y-4">
                    <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-white group inline-block">
                        <div class="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
                            <svg class="text-secondary" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                        </div>
                        <span class="tracking-tight">Med<span class="text-secondary font-extrabold">Network</span></span>
                    </a>
                    <p class="text-[14px] text-borderColor/70 max-w-sm leading-relaxed font-light">Providing high-quality clinical operations management tools and professional healthcare networking platforms globally.</p>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Platform</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="index.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Network Modules</a></li>
                        <li><a href="services.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Clinical Services</a></li>
                        <li><a href="doctors.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Doctor Portal</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Resources</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Developer API</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">System Status</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Support Center</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Emergency Contact</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li class="text-danger font-bold tracking-wide flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-danger animate-ping"></span> Hotline: 0310203040
                        </li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Terms & Conditions</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="pt-8 border-t border-white/10 text-center text-[13px] text-borderColor/40 tracking-wide">
                &copy; 2026 MedNetwork Systems Inc. All rights reserved. Secure clinical systems architecture verified.
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Mobile responsive menu drawer layout controller
            const menuBtn = document.getElementById("mobile-menu-btn");
            const navMenu = document.getElementById("nav-links-menu");
            const bar1 = document.getElementById("bar1");
            const bar2 = document.getElementById("bar2");
            const bar3 = document.getElementById("bar3");
            
            menuBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                navMenu.classList.toggle("left-0");
                navMenu.classList.toggle("left-[-100%]");
                
                bar1.classList.toggle("rotate-45");
                bar1.classList.toggle("translate-y-1.5");
                bar2.classList.toggle("opacity-0");
                bar3.classList.toggle("-rotate-45");
                bar3.classList.toggle("-translate-y-1.5");
            });

            document.addEventListener("click", function (e) {
                if (!menuBtn.contains(e.target) && !navMenu.contains(e.target)) {
                    navMenu.classList.add("left-[-100%]");
                    navMenu.classList.remove("left-0");
                    bar1.classList.remove("rotate-45", "translate-y-1.5");
                    bar2.classList.remove("opacity-0");
                    bar3.classList.remove("-rotate-45", "-translate-y-1.5");
                }
            });

            // Reactive Scroll Adjustments for Navigation Height
            const navbar = document.getElementById("main-navbar");
            window.addEventListener("scroll", function() {
                if (window.scrollY > 20) {
                    navbar.classList.remove("h-[80px]");
                    navbar.classList.add("h-[70px]", "shadow-md");
                } else {
                    navbar.classList.remove("h-[70px]", "shadow-md");
                    navbar.classList.add("h-[80px]", "shadow-sm");
                }
            }, { passive: true });

            // Smooth Fluid Carousel Logic
            const track = document.getElementById("slider-track");
            const dots = Array.from(document.querySelectorAll(".slider-dot"));
            let currentSlide = 0;

            function goToSlide(index) {
                track.style.transform = `translateX(-${index * 33.33333}%)`;
                dots.forEach((dot, i) => {
                    if (i === index) {
                        dot.classList.add("bg-white", "w-8");
                        dot.classList.remove("bg-white/40", "w-2.5");
                    } else {
                        dot.classList.remove("bg-white", "w-8");
                        dot.classList.add("bg-white/40", "w-2.5");
                    }
                });
                currentSlide = index;
            }

            goToSlide(0);

            dots.forEach(dot => {
                dot.addEventListener("click", function() {
                    goToSlide(parseInt(this.getAttribute("data-index")));
                });
            });

            // Automatic Slider Transitions (Configured around 5.5s intervals)
            setInterval(() => {
                let next = (currentSlide + 1) % 3;
                goToSlide(next);
            }, 5500);

            // Staggered Scroll Animation Observer Frame
            const scrollSections = document.querySelectorAll(".reveal-section");
            const scrollObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if(entry.isIntersecting) {
                        entry.target.classList.add("visible");
                        scrollObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.05 });

            scrollSections.forEach(section => scrollObserver.observe(section));
        });
    </script>
</body>
</html>