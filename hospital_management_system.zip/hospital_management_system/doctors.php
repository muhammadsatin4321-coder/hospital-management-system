<?php 
session_start();
include("includes/conn.php"); 
$current_page = 'doctors.php';
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meet Our Medical Specialists | MedNetwork</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: '#F8FAFC',
                        card: '#FFFFFF',
                        primary: '#2563EB',
                        secondary: '#0EA5E9',
                        accent: '#14B8A6',
                        success: '#22C55E',
                        warning: '#F59E0B',
                        danger: '#EF4444',
                        textMain: '#1E293B',
                        borderColor: '#E2E8F0'
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        heading: ['Poppins', 'sans-serif']
                    },
                    borderRadius: {
                        'premium': '20px'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F8FAFC;
        }

        .font-heading {
            font-family: 'Poppins', sans-serif;
        }

        .premium-transition { 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
        }
        
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }

        /* Medical Grid Background Overlay Patterns */
        .medical-pattern {
            background-image: radial-gradient(#2563eb 0.75px, transparent 0.75px), radial-gradient(#0ea5e9 0.75px, #F8FAFC 0.75px);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            opacity: 0.15;
        }

        /* Smooth Premium Transitions and Scroll Reveals */
        .reveal-section {
            opacity: 0; 
            transform: translateY(30px); 
            will-change: transform, opacity;
            transition: opacity 0.8s cubic-bezier(0.25, 1, 0.5, 1), transform 0.8s cubic-bezier(0.25, 1, 0.5, 1);
        }
        .reveal-section.visible { 
            opacity: 1; 
            transform: translateY(0); 
        }

        .form-input-focus:focus {
            border-color: #2563EB;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
            background-color: #FFFFFF;
        }
    </style>
</head>
<body class="text-textMain antialiased min-h-screen flex flex-col pt-[120px] relative overflow-x-hidden">

    <div class="absolute inset-0 medical-pattern pointer-events-none z-0"></div>
    <div class="absolute top-[12%] right-[-5%] w-[450px] h-[450px] bg-secondary/10 rounded-full blur-[120px] pointer-events-none z-0"></div>
    <div class="absolute bottom-[25%] left-[-5%] w-[500px] h-[500px] bg-accent/10 rounded-full blur-[150px] pointer-events-none z-0"></div>

    <div class="bg-danger text-white fixed top-0 left-0 right-0 z-[60] h-[40px] flex items-center text-sm font-medium shadow-sm border-b border-white/10">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <div class="flex items-center gap-6">
                <a href="tel:+15559113940" class="flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91" /></svg>
                    <span class="tracking-wide">Emergency Support: <strong class="font-semibold">+92 3000000000</strong></span>
                </a>
                <a href="mailto:support@mednetwork.org" class="hidden sm:flex items-center gap-2 hover:text-white/80 premium-transition">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    <span class="opacity-90">support@mednetwork.org</span>
                </a>
            </div>
            <div class="text-xs tracking-widest uppercase font-semibold opacity-90 hidden md:flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-white animate-pulse"></span> Systems Operational Status Online
            </div>
        </div>
    </div>

    <nav class="glass-nav fixed top-[40px] left-0 right-0 z-50 h-[80px] flex items-center border-b border-borderColor premium-transition shadow-sm" id="main-navbar">
        <div class="container mx-auto px-6 max-w-[1200px] w-full flex justify-between items-center">
            <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-textMain group">
                <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 premium-transition">
                    <svg class="text-primary group-hover:scale-110 premium-transition" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                </div>
                <span class="tracking-tight">Med<span class="text-primary font-extrabold">Network</span></span>
            </a>
            
            <button class="md:hidden flex flex-col justify-between w-6 h-4 bg-transparent border-none cursor-pointer z-50 focus:outline-none" id="mobile-menu-btn" aria-label="Toggle navigation menu">
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar1"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition my-auto" id="bar2"></span>
                <span class="w-full h-0.5 bg-textMain rounded premium-transition origin-left" id="bar3"></span>
            </button>
            
            <ul class="fixed md:static top-[120px] left-[-100%] md:left-0 w-full md:w-auto h-[calc(100vh-120px)] md:h-auto bg-card md:bg-transparent border-t border-borderColor md:border-none flex flex-col md:flex-row items-center pt-8 md:pt-0 gap-6 md:gap-8 premium-transition z-40" id="nav-links-menu">
                <li><a href="index.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Home</a></li>
                <li><a href="services.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Services</a></li>
                <li><a href="doctors.php" class="text-[15px] font-semibold text-primary premium-transition relative py-2 block">Our Doctors</a></li>
                <li><a href="about.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">About Us</a></li>
                <li><a href="contact.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition relative py-2 block">Contact</a></li>
                
                <li class="hidden md:block w-px h-5 bg-borderColor mx-1"></li>

                <?php if(isset($_SESSION['patient_email'])): ?>
                    <li class="mt-4 md:mt-0"><a href="appointment.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-lg shadow-primary/10 select-none">Book Appointment</a></li>
                    <li><a href="Patient/dashboard.php" class="text-[15px] font-medium text-textMain/80 hover:text-primary premium-transition py-2 block">My Account</a></li>
                    <li><a href="logout.php" class="text-[15px] text-danger hover:text-red-700 font-semibold premium-transition py-2 block">Logout</a></li>
                <?php else: ?>
                    <li class="mt-4 md:mt-0"><a href="login.php" class="text-[15px] font-semibold text-textMain/80 hover:text-primary premium-transition py-2 block">Login</a></li>
                    <li class="mt-2 md:mt-0"><a href="register.php" class="text-[14px] bg-gradient-to-r from-primary to-secondary text-white font-semibold px-5 py-2.5 rounded-xl block text-center shadow-sm">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <header class="w-full bg-card border-b border-borderColor py-16 relative z-10 reveal-section">
        <div class="container mx-auto px-6 max-w-[1200px] text-center">
            <div class="inline-flex items-center gap-2 bg-primary/10 text-primary font-bold text-xs px-3.5 py-1.5 rounded-xl uppercase tracking-wider border border-primary/20 mb-4">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>
                Clinical Faculty Matrix
            </div>
            <h1 class="font-heading text-3xl md:text-5xl font-bold text-textMain mb-4 tracking-tight leading-tight">
                Our Medical Specialists
            </h1>
            <p class="text-[16px] text-textMain/75 max-w-2xl mx-auto leading-relaxed font-light">
                Connect with our elite team of certified clinical practitioners and authorized department leaders dedicated to exceptional medical care frameworks.
            </p>
        </div>
    </header>

    <section class="w-full bg-card py-6 border-b border-borderColor sticky top-[120px] md:top-[110px] z-30 transition-all duration-300">
        <div class="container mx-auto px-6 max-w-[1200px] w-full">
            <div class="bg-background p-4 rounded-2xl border border-borderColor grid grid-cols-1 md:grid-cols-2 gap-4 items-center shadow-inner">
                
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none text-textMain/40">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    </span>
                    <input type="text" id="search-input" placeholder="Search specialist by name or keyword..." class="w-full bg-card text-textMain pl-11 pr-4 py-3 rounded-xl border border-borderColor focus:outline-none form-input-focus text-[14px] premium-transition font-medium">
                </div>

                <div class="relative">
                    <select id="department-filter" class="w-full bg-card text-textMain px-4 py-3 rounded-xl border border-borderColor focus:outline-none form-input-focus text-[14px] premium-transition font-medium appearance-none cursor-pointer">
                        <option value="all">All Specialties & Departments</option>
                        <?php
                        $dept_list_query = "SELECT DISTINCT department FROM doctors WHERE department IS NOT NULL AND department != '' ORDER BY department ASC";
                        $dept_list_res = mysqli_query($conn, $dept_list_query);
                        if($dept_list_res) {
                            while($d_row = mysqli_fetch_assoc($dept_list_res)) {
                                echo '<option value="'.htmlspecialchars(strtolower(trim($d_row['department']))).'">'.htmlspecialchars($d_row['department']).'</option>';
                            }
                        }
                        ?>
                    </select>
                    <span class="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none text-xs text-textMain/50">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>
                    </span>
                </div>

            </div>
        </div>
    </section>

    <main class="flex-grow w-full py-12 relative z-10 reveal-section">
        <div class="container mx-auto px-6 max-w-[1200px] w-full">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="doctors-grid-cluster">
                <?php
                $query = "SELECT name, image, specialization, experience, department FROM doctors ORDER BY id DESC";
                $res = mysqli_query($conn, $query);
                if ($res && mysqli_num_rows($res) > 0) {
                    while($row = mysqli_fetch_assoc($res)) {
                        $avatar_src = !empty($row['image']) ? "uploads/".trim($row['image']) : "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=200&auto=format&fit=crop";
                        $dept_slug = htmlspecialchars(strtolower(trim($row['department'])));
                        ?>
                        <div class="doctor-card group bg-card border border-borderColor rounded-premium p-6 shadow-sm hover:shadow-xl hover:border-primary/20 transition-all duration-300 flex flex-col justify-between" data-department="<?php echo $dept_slug; ?>" data-name="<?php echo htmlspecialchars(strtolower($row['name'])); ?>">
                            <div>
                                <div class="flex items-center gap-5">
                                    <div class="w-[76px] h-[76px] rounded-full overflow-hidden border border-borderColor bg-background flex-shrink-0 shadow-inner">
                                        <img src="<?php echo htmlspecialchars($avatar_src); ?>" class="w-full h-full object-cover object-top group-hover:scale-105 premium-transition" alt="Physician">
                                    </div>
                                    <div class="space-y-1.5 flex-grow">
                                        <h3 class="text-[17px] font-bold text-textMain group-hover:text-primary premium-transition leading-tight font-heading">Dr. <?php echo htmlspecialchars($row['name']); ?></h3>
                                        <span class="inline-block bg-primary/5 text-primary border border-primary/10 font-semibold text-[11px] px-3 py-1 rounded-xl uppercase tracking-wider">
                                            <?php echo htmlspecialchars($row['department']); ?>
                                        </span>
                                    </div>
                                </div>
                                
                                <div class="mt-6 pt-5 border-t border-borderColor/80 space-y-3.5 text-[14px]">
                                    <div class="flex items-start gap-2">
                                        <span class="text-textMain/40 font-bold uppercase tracking-wider text-[11px] min-w-[110px] mt-0.5">Specialization</span> 
                                        <span class="text-textMain/80 font-medium"><?php echo htmlspecialchars($row['specialization']); ?></span>
                                    </div>
                                    <div class="flex items-start gap-2">
                                        <span class="text-textMain/40 font-bold uppercase tracking-wider text-[11px] min-w-[110px] mt-0.5">Experience</span> 
                                        <span class="text-textMain/80 font-medium"><?php echo htmlspecialchars($row['experience']); ?> Years Active</span>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-8">
                                <a href="appointment.php" class="w-full text-center block bg-background border border-borderColor hover:bg-primary hover:text-white px-5 py-3.5 rounded-xl font-bold text-textMain shadow-sm hover:shadow-md premium-transition transform active:translate-y-0 hover:-translate-y-0.5 text-[14px]">
                                    Request Consultation Node
                                </a>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    ?>
                    <div id="no-results-fallback" class="col-span-1 md:col-span-2 lg:col-span-3 text-center py-16 px-6 bg-card border border-borderColor rounded-premium">
                        <div class="w-16 h-16 bg-danger/10 text-danger rounded-2xl flex items-center justify-center mx-auto mb-4 border border-danger/20">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        </div>
                        <h3 class="text-lg font-bold text-textMain mb-2 font-heading">No Physicians Scheduled</h3>
                        <p class="text-textMain/60 text-[14px] max-w-sm mx-auto leading-relaxed">No medical specialists are currently scheduled available on the grid cluster framework directory.</p>
                    </div>
                    <?php
                }
                ?>
                
                <div id="js-empty-state" class="hidden col-span-1 md:col-span-2 lg:col-span-3 text-center py-16 px-6 bg-card border border-borderColor rounded-premium animate-fade-in">
                    <div class="w-16 h-16 bg-warning/10 text-warning rounded-2xl flex items-center justify-center mx-auto mb-4 border border-warning/20">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    </div>
                    <h3 class="text-lg font-bold text-textMain mb-2 font-heading">No Matching Records Found</h3>
                    <p class="text-textMain/60 text-[14px] max-w-sm mx-auto leading-relaxed">Adjust your interactive search parameters or select a different clinical sector from the registry filters.</p>
                </div>

            </div>
        </div>
    </main>

    <footer class="bg-textMain text-white pt-16 pb-10 border-t border-textMain mt-auto relative z-10 shadow-inner">
        <div class="container mx-auto px-6 max-w-[1200px]">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-10 mb-12">
                <div class="md:col-span-2 space-y-4">
                    <a href="index.php" class="flex items-center gap-2.5 font-heading text-2xl font-bold text-white group inline-block">
                        <div class="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
                            <svg class="text-secondary" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                        </div>
                        <span class="tracking-tight">Med<span class="text-secondary font-extrabold">Network</span></span>
                    </a>
                    <p class="text-[14px] text-borderColor/70 max-w-sm leading-relaxed font-light">Providing high-quality clinical operations management tools and professional healthcare networking platforms globally.</p>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Platform</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="index.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Network Modules</a></li>
                        <li><a href="services.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Clinical Services</a></li>
                        <li><a href="doctors.php" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Doctor Portal</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Resources</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Developer API</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">System Status</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Support Center</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-heading text-[14px] font-bold tracking-widest text-secondary uppercase mb-4">Emergency Contact</h4>
                    <ul class="space-y-3 text-[14px] text-borderColor/80 font-light">
                        <li class="text-danger font-bold tracking-wide flex items-center gap-1.5">
                            <span class="w-2 h-2 rounded-full bg-danger animate-ping"></span> Hotline: +92 3000000000
                        </li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Terms & Conditions</a></li>
                        <li><a href="#" class="hover:text-secondary hover:translate-x-1 inline-block premium-transition">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="pt-8 border-t border-white/10 text-center text-[13px] text-borderColor/40 tracking-wide">
                &copy; 2026 MedNetwork Systems Inc. All rights reserved. Secure clinical systems architecture verified.
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const menuBtn = document.getElementById("mobile-menu-btn");
            const navMenu = document.getElementById("nav-links-menu");
            const bar1 = document.getElementById("bar1");
            const bar2 = document.getElementById("bar2");
            const bar3 = document.getElementById("bar3");
            
            menuBtn.addEventListener("click", function (e) {
                e.stopPropagation();
                navMenu.classList.toggle("left-0");
                navMenu.classList.toggle("left-[-100%]");
                
                bar1.classList.toggle("rotate-45");
                bar1.classList.toggle("translate-y-1.5");
                bar2.classList.toggle("opacity-0");
                bar3.classList.toggle("-rotate-45");
                bar3.classList.toggle("-translate-y-1.5");
            });

            document.addEventListener("click", function (e) {
                if (!menuBtn.contains(e.target) && !navMenu.contains(e.target)) {
                    navMenu.classList.add("left-[-100%]");
                    navMenu.classList.remove("left-0");
                    bar1.classList.remove("rotate-45", "translate-y-1.5");
                    bar2.classList.remove("opacity-0");
                    bar3.classList.remove("-rotate-45", "-translate-y-1.5");
                }
            });

            const navbar = document.getElementById("main-navbar");
            window.addEventListener("scroll", function() {
                if (window.scrollY > 20) {
                    navbar.classList.remove("h-[80px]");
                    navbar.classList.add("h-[70px]", "shadow-md");
                } else {
                    navbar.classList.remove("h-[70px]", "shadow-md");
                    navbar.classList.add("h-[80px]", "shadow-sm");
                }
            }, { passive: true });

            const searchInput = document.getElementById("search-input");
            const departmentFilter = document.getElementById("department-filter");
            const doctorCards = document.querySelectorAll(".doctor-card");
            const emptyState = document.getElementById("js-empty-state");

            function filterRegistry() {
                const searchVal = searchInput.value.toLowerCase().trim();
                const selectedDept = departmentFilter.value;
                let visibleCount = 0;

                doctorCards.forEach(card => {
                    const cardName = card.getAttribute("data-name") || "";
                    const cardDept = card.getAttribute("data-department") || "";
                    
                    const matchesSearch = cardName.includes(searchVal) || cardDept.includes(searchVal);
                    const matchesDept = (selectedDept === "all" || cardDept === selectedDept);

                    if (matchesSearch && matchesDept) {
                        card.style.display = "flex";
                        visibleCount++;
                    } else {
                        card.style.display = "none";
                    }
                });

                if (visibleCount === 0 && doctorCards.length > 0) {
                    emptyState.classList.remove("hidden");
                } else {
                    emptyState.classList.add("hidden");
                }
            }

            searchInput.addEventListener("input", filterRegistry);
            departmentFilter.addEventListener("change", filterRegistry);

            const scrollSections = document.querySelectorAll(".reveal-section");
            const scrollObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if(entry.isIntersecting) {
                        entry.target.classList.add("visible");
                        scrollObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.05 });

            scrollSections.forEach(section => scrollObserver.observe(section));
        });
    </script>
</body>
</html>